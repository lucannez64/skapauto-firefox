// src/popup.ts
var translations = {
  fr: {
    appTitle: "Skap",
    clientFile: "Fichier Client",
    selectClientFile: "Sélectionner un fichier client",
    authenticate: "S'authentifier",
    getPasswords: "Récupérer les Mots de Passe",
    actions: "Actions",
    refreshPasswords: "Rafraîchir les mots de passe",
    classifyFields: "Classifier les champs sur cette page",
    classificationResults: "Résultats de classification",
    usernameFields: "Champs de nom d'utilisateur",
    passwordFields: "Champs de mot de passe",
    emailFields: "Champs d'email",
    unclassifiedFields: "Champs non classifiés",
    checkingSecureClient: "Vérification du client sécurisé...",
    activeSessionRecovered: "Session active récupérée",
    pleaseLoadClientFile: "Veuillez charger votre fichier client",
    clientLoadedSuccess: "Client chargé avec succès",
    fileType: "Type",
    fileSize: "Taille",
    unknown: "inconnu",
    copyPassword: "Copier",
    fillCredentials: "Remplir les champs",
    noPasswordsFound: "Aucun mot de passe trouvé",
    noPasswordsFoundDesc: "Aucun mot de passe n'a été trouvé pour ce site.",
    classificationComplete: "Classification terminée",
    usernameFieldsFound: "champ(s) de nom d'utilisateur trouvé(s)",
    passwordFieldsFound: "champ(s) de mot de passe trouvé(s)",
    emailFieldsFound: "champ(s) d'email trouvé(s)",
    unclassifiedFieldsFound: "champ(s) non classifié(s)",
    selectingClientFile: "Sélection du fichier client...",
    errorInjecting: "Erreur lors de l'injection du sélecteur de fichier:",
    unknownError: "Erreur inconnue",
    bytes: "octets",
    kb: "Ko",
    mb: "Mo",
    authenticating: "Authentification en cours...",
    authSuccess: "Authentification réussie",
    authFailure: "Échec de l'authentification:",
    retrievingPasswords: "Récupération des mots de passe...",
    passwordsRetrieved: "Mots de passe récupérés avec succès",
    passwordsRetrievalFailed: "Échec de la récupération des mots de passe:",
    noPasswordsAvailable: "Aucun mot de passe disponible",
    unknownSite: "Site inconnu",
    unknownUser: "Utilisateur inconnu",
    copied: "Copié!",
    passwordCopied: "Mot de passe copié dans le presse-papiers",
    errorCopying: "Erreur lors de la copie du mot de passe",
    fill: "Remplir"
  },
  en: {
    appTitle: "Skap",
    clientFile: "Client File",
    selectClientFile: "Select client file",
    authenticate: "Authenticate",
    getPasswords: "Get Passwords",
    actions: "Actions",
    refreshPasswords: "Refresh passwords",
    classifyFields: "Classify fields on this page",
    classificationResults: "Classification Results",
    usernameFields: "Username fields",
    passwordFields: "Password fields",
    emailFields: "Email fields",
    unclassifiedFields: "Unclassified fields",
    checkingSecureClient: "Checking secure client...",
    activeSessionRecovered: "Active session recovered",
    pleaseLoadClientFile: "Please load your client file",
    clientLoadedSuccess: "Client loaded successfully",
    fileType: "Type",
    fileSize: "Size",
    unknown: "unknown",
    copyPassword: "Copy",
    fillCredentials: "Fill credentials",
    noPasswordsFound: "No passwords found",
    noPasswordsFoundDesc: "No passwords were found for this site.",
    classificationComplete: "Classification complete",
    usernameFieldsFound: "username field(s) found",
    passwordFieldsFound: "password field(s) found",
    emailFieldsFound: "email field(s) found",
    unclassifiedFieldsFound: "unclassified field(s)",
    selectingClientFile: "Selecting client file...",
    errorInjecting: "Error injecting file selector:",
    unknownError: "Unknown error",
    bytes: "bytes",
    kb: "KB",
    mb: "MB",
    authenticating: "Authenticating...",
    authSuccess: "Authentication successful",
    authFailure: "Authentication failed:",
    retrievingPasswords: "Retrieving passwords...",
    passwordsRetrieved: "Passwords retrieved successfully",
    passwordsRetrievalFailed: "Failed to retrieve passwords:",
    noPasswordsAvailable: "No passwords available",
    unknownSite: "Unknown site",
    unknownUser: "Unknown user",
    copied: "Copied!",
    passwordCopied: "Password copied to clipboard",
    errorCopying: "Error copying password",
    fill: "Fill"
  }
};
var currentLanguage = "fr";
function t(key) {
  return translations[currentLanguage][key];
}
function updateTranslations() {
  const elements = document.querySelectorAll("[data-i18n]");
  const statusMessageKey = statusMessage.getAttribute("data-i18n");
  if (statusMessageKey && translations[currentLanguage][statusMessageKey]) {
    statusMessage.textContent = translations[currentLanguage][statusMessageKey];
  }
  elements.forEach((element) => {
    const key = element.getAttribute("data-i18n");
    if (key && translations[currentLanguage][key]) {
      element.textContent = translations[currentLanguage][key];
    }
  });
}
function setLanguage(lang) {
  currentLanguage = lang;
  const frBtn = document.getElementById("fr-btn");
  const enBtn = document.getElementById("en-btn");
  if (lang === "fr") {
    frBtn.classList.add("active");
    enBtn.classList.remove("active");
  } else {
    frBtn.classList.remove("active");
    enBtn.classList.add("active");
  }
  updateTranslations();
  browser.storage.local.set({ language: lang });
}
var authBtn = document.getElementById("auth-btn");
var getPasswordsBtn = document.getElementById("get-passwords-btn");
var statusMessage = document.getElementById("status-message");
var passwordList = document.getElementById("password-list");
var selectFileBtn = document.getElementById("select-file-btn");
var fileName = document.getElementById("file-name");
var frBtn = document.getElementById("fr-btn");
var enBtn = document.getElementById("en-btn");
var clientLoaded = false;
var authenticated = false;
authBtn.disabled = true;
getPasswordsBtn.disabled = true;
frBtn.addEventListener("click", () => setLanguage("fr"));
enBtn.addEventListener("click", () => setLanguage("en"));
browser.storage.local.get("language").then((result) => {
  if (result.language) {
    setLanguage(result.language);
  } else {
    const browserLang = navigator.language.split("-")[0];
    if (browserLang === "fr") {
      setLanguage("fr");
    } else {
      setLanguage("en");
    }
  }
});
function checkSecureClient() {
  showStatus(t("checkingSecureClient"), "info");
  browser.runtime.sendMessage({ action: "checkSecureClient" }).then((response) => {
    if (response && response.success) {
      clientLoaded = true;
      authenticated = true;
      authBtn.disabled = false;
      getPasswordsBtn.disabled = false;
      showStatus(t("activeSessionRecovered"), "success");
      checkSecurePasswords();
    } else {
      showStatus(t("pleaseLoadClientFile"), "info");
    }
  });
}
function checkSecurePasswords() {
  browser.runtime.sendMessage({ action: "checkSecurePasswords" }).then((response) => {
    if (response && response.success && response.passwords) {
      displayPasswords(response.passwords);
    }
  });
}
document.addEventListener("DOMContentLoaded", () => {
  checkSecureClient();
  updateTranslations();
});
browser.runtime.onMessage.addListener((message) => {
  if (message.action === "clientLoaded") {
    clientLoaded = true;
    authBtn.disabled = false;
    if (message.fileMetadata) {
      fileName.textContent = message.fileMetadata.name;
      fileName.style.display = "block";
      const fileInfo = document.createElement("div");
      fileInfo.className = "file-info";
      fileInfo.textContent = `${t("fileType")}: ${message.fileMetadata.type || t("unknown")}, ${t("fileSize")}: ${formatFileSize(message.fileMetadata.size)}`;
      const existingInfo = fileName.querySelector(".file-info");
      if (existingInfo) {
        fileName.removeChild(existingInfo);
      }
      fileName.appendChild(fileInfo);
    }
    showStatus(t("clientLoadedSuccess"), "success");
  }
});
selectFileBtn.addEventListener("click", async () => {
  try {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    if (!tabs[0].id) {
      throw new Error("Aucun onglet actif trouvé");
    }
    await browser.tabs.sendMessage(tabs[0].id, { action: "injectFile" });
    showStatus(t("selectingClientFile"), "info");
  } catch (error) {
    console.error(t("errorInjecting"), error);
    showStatus(`${t("errorInjecting")} ${error instanceof Error ? error.message : t("unknownError")}`, "error");
  }
});
function formatFileSize(bytes) {
  if (bytes < 1024) {
    return bytes + " " + t("bytes");
  } else if (bytes < 1024 * 1024) {
    return (bytes / 1024).toFixed(1) + " " + t("kb");
  } else {
    return (bytes / (1024 * 1024)).toFixed(1) + " " + t("mb");
  }
}
authBtn.addEventListener("click", () => {
  showStatus(t("authenticating"), "info");
  browser.runtime.sendMessage({ action: "authenticate" }).then((response) => {
    if (response && response.success) {
      authenticated = true;
      getPasswordsBtn.disabled = false;
      showStatus(t("authSuccess"), "success");
    } else {
      showStatus(`${t("authFailure")} ${response ? response.message : t("unknownError")}`, "error");
    }
  });
});
getPasswordsBtn.addEventListener("click", () => {
  showStatus(t("retrievingPasswords"), "info");
  browser.runtime.sendMessage({ action: "getPasswords" }).then((response) => {
    if (response && response.success) {
      showStatus(t("passwordsRetrieved"), "success");
      displayPasswords(response.passwords);
    } else {
      showStatus(`${t("passwordsRetrievalFailed")} ${response ? response.message : t("unknownError")}`, "error");
    }
  });
});
function showStatus(message, type) {
  let iconClass = "";
  switch (type) {
    case "success":
      iconClass = "fas fa-check-circle";
      break;
    case "error":
      iconClass = "fas fa-exclamation-circle";
      break;
    case "info":
    default:
      iconClass = "fas fa-info-circle";
      break;
  }
  const createStatusContent = () => {
    while (statusMessage.firstChild) {
      statusMessage.removeChild(statusMessage.firstChild);
    }
    const iconElement = document.createElement("i");
    iconElement.className = iconClass;
    statusMessage.appendChild(iconElement);
    statusMessage.appendChild(document.createTextNode(" " + message));
    statusMessage.className = `status ${type}`;
  };
  if (statusMessage.style.display === "flex") {
    statusMessage.style.opacity = "0";
    statusMessage.style.transform = "translateY(-10px)";
    setTimeout(() => {
      createStatusContent();
      statusMessage.style.display = "flex";
      statusMessage.style.opacity = "0";
      statusMessage.style.transform = "translateY(10px)";
      setTimeout(() => {
        statusMessage.style.transition = "opacity 0.3s ease, transform 0.3s ease";
        statusMessage.style.opacity = "1";
        statusMessage.style.transform = "translateY(0)";
      }, 10);
    }, 300);
  } else {
    createStatusContent();
    statusMessage.style.display = "flex";
    statusMessage.style.opacity = "0";
    statusMessage.style.transform = "translateY(10px)";
    setTimeout(() => {
      statusMessage.style.transition = "opacity 0.3s ease, transform 0.3s ease";
      statusMessage.style.opacity = "1";
      statusMessage.style.transform = "translateY(0)";
    }, 10);
  }
  if (type === "success") {
    setTimeout(() => {
      statusMessage.style.opacity = "0";
      statusMessage.style.transform = "translateY(-10px)";
      setTimeout(() => {
        statusMessage.style.display = "none";
      }, 300);
    }, 5000);
  }
}
function displayPasswords(passwords) {
  if (passwordList.style.display === "block") {
    passwordList.style.opacity = "0";
    passwordList.style.transform = "translateY(-10px)";
    setTimeout(() => {
      while (passwordList.firstChild) {
        passwordList.removeChild(passwordList.firstChild);
      }
      renderPasswordList(passwords);
    }, 300);
  } else {
    while (passwordList.firstChild) {
      passwordList.removeChild(passwordList.firstChild);
    }
    renderPasswordList(passwords);
  }
}
function renderPasswordList(passwords) {
  if (!passwords || passwords.length === 0) {
    const emptyState = document.createElement("div");
    emptyState.className = "empty-state";
    const icon = document.createElement("i");
    icon.className = "fas fa-key";
    emptyState.appendChild(icon);
    const message = document.createElement("p");
    message.textContent = t("noPasswordsAvailable");
    emptyState.appendChild(message);
    passwordList.appendChild(emptyState);
    passwordList.style.display = "block";
    passwordList.style.opacity = "0";
    passwordList.style.transform = "translateY(10px)";
    setTimeout(() => {
      passwordList.style.transition = "opacity 0.3s ease, transform 0.3s ease";
      passwordList.style.opacity = "1";
      passwordList.style.transform = "translateY(0)";
    }, 10);
    return;
  }
  passwords.sort((a, b) => {
    const urlA = a.url?.toLowerCase() || "";
    const urlB = b.url?.toLowerCase() || "";
    return urlA.localeCompare(urlB);
  });
  passwords.forEach((password, index) => {
    const passwordItem = document.createElement("div");
    passwordItem.className = "password-item";
    passwordItem.style.opacity = "0";
    passwordItem.style.transform = "translateY(10px)";
    const faviconUrl = getFaviconUrl(password.url || "");
    const site = document.createElement("div");
    site.className = "site";
    const favicon = document.createElement("img");
    favicon.src = faviconUrl;
    favicon.width = 16;
    favicon.height = 16;
    favicon.style.marginRight = "10px";
    favicon.onerror = handleImageError;
    site.appendChild(favicon);
    const siteName = document.createTextNode(password.url || t("unknownSite"));
    site.appendChild(siteName);
    passwordItem.appendChild(site);
    const username = document.createElement("div");
    username.className = "username";
    const userIcon = document.createElement("i");
    userIcon.className = "fas fa-user";
    username.appendChild(userIcon);
    const usernameText = document.createTextNode(password.username || t("unknownUser"));
    username.appendChild(usernameText);
    passwordItem.appendChild(username);
    const actions = document.createElement("div");
    actions.className = "actions";
    const copyBtn = document.createElement("button");
    copyBtn.className = "copy-btn";
    const copyIcon = document.createElement("i");
    copyIcon.className = "fas fa-copy";
    copyBtn.appendChild(copyIcon);
    copyBtn.appendChild(document.createTextNode(" " + t("copyPassword")));
    copyBtn.addEventListener("click", () => {
      navigator.clipboard.writeText(password.password || "").then(() => {
        copyBtn.style.animation = "pulse 0.3s ease";
        const originalContent = copyBtn.cloneNode(true);
        while (copyBtn.firstChild) {
          copyBtn.removeChild(copyBtn.firstChild);
        }
        const checkIcon = document.createElement("i");
        checkIcon.className = "fas fa-check";
        copyBtn.appendChild(checkIcon);
        copyBtn.appendChild(document.createTextNode(" " + t("copied")));
        setTimeout(() => {
          copyBtn.style.animation = "";
          while (copyBtn.firstChild) {
            copyBtn.removeChild(copyBtn.firstChild);
          }
          Array.from(originalContent.childNodes).forEach((node) => {
            copyBtn.appendChild(node.cloneNode(true));
          });
        }, 2000);
        showStatus(t("passwordCopied"), "success");
      }).catch((err) => {
        console.error(t("errorCopying"), err);
        showStatus(t("errorCopying"), "error");
      });
    });
    actions.appendChild(copyBtn);
    passwordItem.appendChild(actions);
    passwordList.appendChild(passwordItem);
    setTimeout(() => {
      passwordItem.style.transition = "opacity 0.3s ease, transform 0.3s ease";
      passwordItem.style.opacity = "1";
      passwordItem.style.transform = "translateY(0)";
    }, 50 + index * 50);
  });
  passwordList.style.display = "block";
  passwordList.style.opacity = "0";
  passwordList.style.transform = "translateY(10px)";
  setTimeout(() => {
    passwordList.style.transition = "opacity 0.3s ease, transform 0.3s ease";
    passwordList.style.opacity = "1";
    passwordList.style.transform = "translateY(0)";
  }, 10);
}
function getFaviconUrl(domain) {
  let cleanDomain = domain;
  if (cleanDomain.includes("://")) {
    cleanDomain = cleanDomain.split("://")[1];
  }
  if (cleanDomain.includes("/")) {
    cleanDomain = cleanDomain.split("/")[0];
  }
  return `https://www.google.com/s2/favicons?domain=${cleanDomain}&sz=32`;
}
function handleImageError(ev) {
  this.style.display = "none";
  const site = this.parentElement;
  if (site) {
    const defaultIcon = document.createElement("i");
    defaultIcon.className = "fas fa-globe";
    defaultIcon.style.marginRight = "10px";
    defaultIcon.style.color = "var(--primary-color)";
    site.insertBefore(defaultIcon, site.firstChild);
  }
}
async function classifyFields() {
  try {
    const classifyBtn = document.getElementById("classifyFieldsBtn");
    const originalContent = classifyBtn.cloneNode(true);
    while (classifyBtn.firstChild) {
      classifyBtn.removeChild(classifyBtn.firstChild);
    }
    const spinnerIcon = document.createElement("i");
    spinnerIcon.className = "fas fa-spinner fa-spin";
    classifyBtn.appendChild(spinnerIcon);
    classifyBtn.appendChild(document.createTextNode(" Classification en cours..."));
    classifyBtn.disabled = true;
    classifyBtn.style.animation = "pulse 1s infinite";
    const resultsElement = document.getElementById("classificationResults");
    if (!resultsElement.classList.contains("hidden")) {
      resultsElement.style.opacity = "0";
      resultsElement.style.transform = "translateY(-10px)";
      await new Promise((resolve) => setTimeout(resolve, 300));
      resultsElement.classList.add("hidden");
    }
    const response = await new Promise((resolve, reject) => {
      browser.runtime.sendMessage({ action: "classifyFields" }).then((response2) => {
        if (browser.runtime.lastError) {
          reject(new Error(browser.runtime.lastError.message));
        } else {
          resolve(response2);
        }
      });
    });
    if (!response || !response.success) {
      throw new Error(response?.message || "Échec de la classification des champs");
    }
    classifyBtn.style.animation = "";
    const fields = response.fields;
    document.getElementById("usernameCount").textContent = fields.username.length.toString();
    document.getElementById("passwordCount").textContent = fields.password.length.toString();
    document.getElementById("emailCount").textContent = fields.email.length.toString();
    document.getElementById("unknownCount").textContent = fields.unknown.length.toString();
    resultsElement.classList.remove("hidden");
    resultsElement.style.opacity = "0";
    resultsElement.style.transform = "translateY(10px)";
    setTimeout(() => {
      resultsElement.style.transition = "opacity 0.3s ease, transform 0.3s ease";
      resultsElement.style.opacity = "1";
      resultsElement.style.transform = "translateY(0)";
    }, 10);
    showStatus(`Classification terminée: ${fields.username.length + fields.password.length + fields.email.length} champs identifiés`, "success");
    while (classifyBtn.firstChild) {
      classifyBtn.removeChild(classifyBtn.firstChild);
    }
    Array.from(originalContent.childNodes).forEach((node) => {
      classifyBtn.appendChild(node.cloneNode(true));
    });
    classifyBtn.disabled = false;
    classifyBtn.style.animation = "pulse 0.3s ease";
    setTimeout(() => {
      classifyBtn.style.animation = "";
    }, 300);
  } catch (error) {
    console.error("Erreur lors de la classification des champs:", error);
    showStatus(`Erreur: ${error instanceof Error ? error.message : String(error)}`, "error");
    const classifyBtn = document.getElementById("classifyFieldsBtn");
    while (classifyBtn.firstChild) {
      classifyBtn.removeChild(classifyBtn.firstChild);
    }
    const icon = document.createElement("i");
    icon.className = "fas fa-tags";
    classifyBtn.appendChild(icon);
    classifyBtn.appendChild(document.createTextNode(" Classifier les champs sur cette page"));
    classifyBtn.disabled = false;
    classifyBtn.style.animation = "";
  }
}
async function refreshPasswords() {
  try {
    const refreshBtn = document.getElementById("refreshBtn");
    const originalContent = refreshBtn.cloneNode(true);
    while (refreshBtn.firstChild) {
      refreshBtn.removeChild(refreshBtn.firstChild);
    }
    const spinnerIcon = document.createElement("i");
    spinnerIcon.className = "fas fa-spinner fa-spin";
    refreshBtn.appendChild(spinnerIcon);
    refreshBtn.appendChild(document.createTextNode(" Rafraîchissement..."));
    refreshBtn.disabled = true;
    refreshBtn.style.animation = "pulse 1s infinite";
    const response = await new Promise((resolve, reject) => {
      browser.runtime.sendMessage({ action: "refreshPasswords" }).then((response2) => {
        if (browser.runtime.lastError) {
          reject(new Error(browser.runtime.lastError.message));
        } else {
          resolve(response2);
        }
      });
    });
    refreshBtn.style.animation = "";
    if (!response || !response.success) {
      throw new Error(response?.message || "Échec du rafraîchissement des mots de passe");
    }
    if (response.passwords) {
      displayPasswords(response.passwords);
      showStatus(`${response.passwords.length} mot(s) de passe récupéré(s)`, "success");
    } else {
      showStatus("Aucun mot de passe disponible", "info");
    }
    while (refreshBtn.firstChild) {
      refreshBtn.removeChild(refreshBtn.firstChild);
    }
    Array.from(originalContent.childNodes).forEach((node) => {
      refreshBtn.appendChild(node.cloneNode(true));
    });
    refreshBtn.disabled = false;
    refreshBtn.style.animation = "pulse 0.3s ease";
    setTimeout(() => {
      refreshBtn.style.animation = "";
    }, 300);
  } catch (error) {
    console.error("Erreur lors du rafraîchissement des mots de passe:", error);
    showStatus(`Erreur: ${error instanceof Error ? error.message : String(error)}`, "error");
    const refreshBtn = document.getElementById("refreshBtn");
    while (refreshBtn.firstChild) {
      refreshBtn.removeChild(refreshBtn.firstChild);
    }
    const syncIcon = document.createElement("i");
    syncIcon.className = "fas fa-sync-alt";
    refreshBtn.appendChild(syncIcon);
    refreshBtn.appendChild(document.createTextNode(" Rafraîchir les mots de passe"));
    refreshBtn.disabled = false;
    refreshBtn.style.animation = "";
  }
}
document.addEventListener("DOMContentLoaded", () => {
  authBtn.addEventListener("click", () => {
    browser.runtime.sendMessage({ action: "authenticate" }).then((response) => {
      if (response && response.success) {
        authenticated = true;
        getPasswordsBtn.disabled = false;
        showStatus("Authentification réussie", "success");
      } else {
        showStatus("Échec de l'authentification", "error");
      }
    });
  });
  getPasswordsBtn.addEventListener("click", () => {
    browser.runtime.sendMessage({ action: "getPasswords" }).then((response) => {
      if (response && response.success && response.passwords) {
        displayPasswords(response.passwords);
        showStatus(`${response.passwords.length} mot(s) de passe récupéré(s)`, "success");
      } else {
        showStatus("Échec de la récupération des mots de passe", "error");
      }
    });
  });
  const classifyBtn = document.getElementById("classifyFieldsBtn");
  if (classifyBtn) {
    classifyBtn.addEventListener("click", classifyFields);
  }
  const refreshBtn = document.getElementById("refreshBtn");
  if (refreshBtn) {
    refreshBtn.addEventListener("click", refreshPasswords);
  }
});
