var __create = Object.create;
var __getProtoOf = Object.getPrototypeOf;
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __toESM = (mod, isNodeMode, target) => {
  target = mod != null ? __create(__getProtoOf(mod)) : {};
  const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
  for (let key of __getOwnPropNames(mod))
    if (!__hasOwnProp.call(to, key))
      __defProp(to, key, {
        get: () => mod[key],
        enumerable: true
      });
  return to;
};
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);

// node_modules/uuid-tool/dist/index.js
var require_dist = __commonJS((exports, module) => {
  (function(t, e) {
    if (typeof exports == "object" && typeof module == "object")
      module.exports = e();
    else if (typeof define == "function" && define.amd)
      define([], e);
    else {
      var r = e();
      for (var n in r)
        (typeof exports == "object" ? exports : t)[n] = r[n];
    }
  })(exports, function() {
    return function(t) {
      var e = {};
      function r(n) {
        if (e[n])
          return e[n].exports;
        var o = e[n] = { i: n, l: false, exports: {} };
        return t[n].call(o.exports, o, o.exports, r), o.l = true, o.exports;
      }
      return r.m = t, r.c = e, r.d = function(t2, e2, n) {
        r.o(t2, e2) || Object.defineProperty(t2, e2, { enumerable: true, get: n });
      }, r.r = function(t2) {
        typeof Symbol != "undefined" && Symbol.toStringTag && Object.defineProperty(t2, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(t2, "__esModule", { value: true });
      }, r.t = function(t2, e2) {
        if (1 & e2 && (t2 = r(t2)), 8 & e2)
          return t2;
        if (4 & e2 && typeof t2 == "object" && t2 && t2.__esModule)
          return t2;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", { enumerable: true, value: t2 }), 2 & e2 && typeof t2 != "string")
          for (var o in t2)
            r.d(n, o, function(e3) {
              return t2[e3];
            }.bind(null, o));
        return n;
      }, r.n = function(t2) {
        var e2 = t2 && t2.__esModule ? function() {
          return t2.default;
        } : function() {
          return t2;
        };
        return r.d(e2, "a", e2), e2;
      }, r.o = function(t2, e2) {
        return Object.prototype.hasOwnProperty.call(t2, e2);
      }, r.p = "", r(r.s = 0);
    }([function(t, e, r) {
      r.r(e), r.d(e, "UuidTool", function() {
        return i;
      }), r.d(e, "Uuid", function() {
        return o;
      });
      var n = { uuid: /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i }, o = function() {
        function t2(t3) {
          this.id = "", typeof t3 == "string" ? this.fromString(t3) : Array.isArray(t3) ? this.fromBytes(t3) : this.generate();
        }
        return t2.fromJson = function(e2) {
          if (typeof e2 == "string" && (e2 = JSON.parse(e2)), !e2 || !e2.id)
            throw new TypeError("The input cannot be converted to Uuid.");
          return new t2(e2.id);
        }, t2.prototype.generate = function() {
          var t3 = new Array(16).fill(0).map(function() {
            return 256 * Math.random() & 255;
          });
          return t3[6] = 79 & (64 | t3[6]), this.fromBytes(t3), this;
        }, t2.prototype.fromBytes = function(t3) {
          return this.id = t3.map(function(t4) {
            return ("00" + t4.toString(16)).slice(-2);
          }).join("").replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, "$1-$2-$3-$4-$5"), this.id = this.toString(), this;
        }, t2.prototype.toBytes = function() {
          return (this.id.replace(/-/g, "").match(/.{2}/g) || []).map(function(t3) {
            return parseInt(t3, 16);
          });
        }, t2.prototype.fromString = function(t3) {
          return this.id = t3.trim(), this.id = this.toString(), this;
        }, t2.prototype.toString = function() {
          switch (t2.stringExportFormat) {
            default:
            case "lowercase":
              return this.id.toLowerCase();
            case "uppercase":
              return this.id.toUpperCase();
          }
        }, t2.prototype.isValid = function() {
          return typeof this.id == "string" && this.id.length === 36 && n.uuid.test(this.id);
        }, t2.prototype.equals = function(e2) {
          return typeof e2 == "string" && (e2 = new t2(e2)), this.toString() === e2.toString();
        }, t2.stringExportFormat = "lowercase", t2;
      }(), i = function() {
        function t2() {
        }
        return t2.toBytes = function(t3) {
          return new o().fromString(t3).toBytes();
        }, t2.toString = function(t3) {
          return new o().fromBytes(t3).toString();
        }, t2.newUuid = function() {
          return new o().toString();
        }, t2.isUuid = function(t3) {
          return new o().fromString(t3).isValid();
        }, t2.compare = function(t3, e2) {
          return new o(t3).equals(new o(e2));
        }, t2;
      }();
    }]);
  });
});

// node_modules/@noble/hashes/_assert.js
var require__assert = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.anumber = anumber;
  exports.abytes = abytes;
  exports.ahash = ahash;
  exports.aexists = aexists;
  exports.aoutput = aoutput;
  function anumber(n) {
    if (!Number.isSafeInteger(n) || n < 0)
      throw new Error("positive integer expected, got " + n);
  }
  function isBytes(a) {
    return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
  }
  function abytes(b, ...lengths) {
    if (!isBytes(b))
      throw new Error("Uint8Array expected");
    if (lengths.length > 0 && !lengths.includes(b.length))
      throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b.length);
  }
  function ahash(h) {
    if (typeof h !== "function" || typeof h.create !== "function")
      throw new Error("Hash should be wrapped by utils.wrapConstructor");
    anumber(h.outputLen);
    anumber(h.blockLen);
  }
  function aexists(instance, checkFinished = true) {
    if (instance.destroyed)
      throw new Error("Hash instance has been destroyed");
    if (checkFinished && instance.finished)
      throw new Error("Hash#digest() has already been called");
  }
  function aoutput(out, instance) {
    abytes(out);
    const min = instance.outputLen;
    if (out.length < min) {
      throw new Error("digestInto() expects output buffer of length at least " + min);
    }
  }
});

// node_modules/@noble/hashes/crypto.js
var require_crypto = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.crypto = undefined;
  exports.crypto = typeof globalThis === "object" && "crypto" in globalThis ? globalThis.crypto : undefined;
});

// node_modules/@noble/hashes/utils.js
var require_utils = __commonJS((exports) => {
  /*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.Hash = exports.nextTick = exports.byteSwapIfBE = exports.isLE = undefined;
  exports.isBytes = isBytes;
  exports.u8 = u8;
  exports.u32 = u32;
  exports.createView = createView;
  exports.rotr = rotr;
  exports.rotl = rotl;
  exports.byteSwap = byteSwap;
  exports.byteSwap32 = byteSwap32;
  exports.bytesToHex = bytesToHex;
  exports.hexToBytes = hexToBytes;
  exports.asyncLoop = asyncLoop;
  exports.utf8ToBytes = utf8ToBytes;
  exports.toBytes = toBytes;
  exports.concatBytes = concatBytes;
  exports.checkOpts = checkOpts;
  exports.wrapConstructor = wrapConstructor;
  exports.wrapConstructorWithOpts = wrapConstructorWithOpts;
  exports.wrapXOFConstructorWithOpts = wrapXOFConstructorWithOpts;
  exports.randomBytes = randomBytes;
  var crypto_1 = require_crypto();
  var _assert_js_1 = require__assert();
  function isBytes(a) {
    return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
  }
  function u8(arr) {
    return new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
  }
  function u32(arr) {
    return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
  }
  function createView(arr) {
    return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
  }
  function rotr(word, shift) {
    return word << 32 - shift | word >>> shift;
  }
  function rotl(word, shift) {
    return word << shift | word >>> 32 - shift >>> 0;
  }
  exports.isLE = (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
  function byteSwap(word) {
    return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
  }
  exports.byteSwapIfBE = exports.isLE ? (n) => n : (n) => byteSwap(n);
  function byteSwap32(arr) {
    for (let i = 0;i < arr.length; i++) {
      arr[i] = byteSwap(arr[i]);
    }
  }
  var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
  function bytesToHex(bytes) {
    (0, _assert_js_1.abytes)(bytes);
    let hex = "";
    for (let i = 0;i < bytes.length; i++) {
      hex += hexes[bytes[i]];
    }
    return hex;
  }
  var asciis = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 };
  function asciiToBase16(ch) {
    if (ch >= asciis._0 && ch <= asciis._9)
      return ch - asciis._0;
    if (ch >= asciis.A && ch <= asciis.F)
      return ch - (asciis.A - 10);
    if (ch >= asciis.a && ch <= asciis.f)
      return ch - (asciis.a - 10);
    return;
  }
  function hexToBytes(hex) {
    if (typeof hex !== "string")
      throw new Error("hex string expected, got " + typeof hex);
    const hl = hex.length;
    const al = hl / 2;
    if (hl % 2)
      throw new Error("hex string expected, got unpadded hex of length " + hl);
    const array = new Uint8Array(al);
    for (let ai = 0, hi = 0;ai < al; ai++, hi += 2) {
      const n1 = asciiToBase16(hex.charCodeAt(hi));
      const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
      if (n1 === undefined || n2 === undefined) {
        const char = hex[hi] + hex[hi + 1];
        throw new Error('hex string expected, got non-hex character "' + char + '" at index ' + hi);
      }
      array[ai] = n1 * 16 + n2;
    }
    return array;
  }
  var nextTick = async () => {
  };
  exports.nextTick = nextTick;
  async function asyncLoop(iters, tick, cb) {
    let ts = Date.now();
    for (let i = 0;i < iters; i++) {
      cb(i);
      const diff = Date.now() - ts;
      if (diff >= 0 && diff < tick)
        continue;
      await (0, exports.nextTick)();
      ts += diff;
    }
  }
  function utf8ToBytes(str) {
    if (typeof str !== "string")
      throw new Error("utf8ToBytes expected string, got " + typeof str);
    return new Uint8Array(new TextEncoder().encode(str));
  }
  function toBytes(data) {
    if (typeof data === "string")
      data = utf8ToBytes(data);
    (0, _assert_js_1.abytes)(data);
    return data;
  }
  function concatBytes(...arrays) {
    let sum = 0;
    for (let i = 0;i < arrays.length; i++) {
      const a = arrays[i];
      (0, _assert_js_1.abytes)(a);
      sum += a.length;
    }
    const res = new Uint8Array(sum);
    for (let i = 0, pad = 0;i < arrays.length; i++) {
      const a = arrays[i];
      res.set(a, pad);
      pad += a.length;
    }
    return res;
  }

  class Hash {
    clone() {
      return this._cloneInto();
    }
  }
  exports.Hash = Hash;
  function checkOpts(defaults, opts) {
    if (opts !== undefined && {}.toString.call(opts) !== "[object Object]")
      throw new Error("Options should be object or undefined");
    const merged = Object.assign(defaults, opts);
    return merged;
  }
  function wrapConstructor(hashCons) {
    const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
    const tmp = hashCons();
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = () => hashCons();
    return hashC;
  }
  function wrapConstructorWithOpts(hashCons) {
    const hashC = (msg, opts) => hashCons(opts).update(toBytes(msg)).digest();
    const tmp = hashCons({});
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = (opts) => hashCons(opts);
    return hashC;
  }
  function wrapXOFConstructorWithOpts(hashCons) {
    const hashC = (msg, opts) => hashCons(opts).update(toBytes(msg)).digest();
    const tmp = hashCons({});
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = (opts) => hashCons(opts);
    return hashC;
  }
  function randomBytes(bytesLength = 32) {
    if (crypto_1.crypto && typeof crypto_1.crypto.getRandomValues === "function") {
      return crypto_1.crypto.getRandomValues(new Uint8Array(bytesLength));
    }
    if (crypto_1.crypto && typeof crypto_1.crypto.randomBytes === "function") {
      return crypto_1.crypto.randomBytes(bytesLength);
    }
    throw new Error("crypto.getRandomValues must be defined");
  }
});

// node_modules/@noble/hashes/_blake.js
var require__blake = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.BLAKE = exports.SIGMA = undefined;
  var _assert_js_1 = require__assert();
  var utils_js_1 = require_utils();
  exports.SIGMA = new Uint8Array([
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    14,
    10,
    4,
    8,
    9,
    15,
    13,
    6,
    1,
    12,
    0,
    2,
    11,
    7,
    5,
    3,
    11,
    8,
    12,
    0,
    5,
    2,
    15,
    13,
    10,
    14,
    3,
    6,
    7,
    1,
    9,
    4,
    7,
    9,
    3,
    1,
    13,
    12,
    11,
    14,
    2,
    6,
    5,
    10,
    4,
    0,
    15,
    8,
    9,
    0,
    5,
    7,
    2,
    4,
    10,
    15,
    14,
    1,
    11,
    12,
    6,
    8,
    3,
    13,
    2,
    12,
    6,
    10,
    0,
    11,
    8,
    3,
    4,
    13,
    7,
    5,
    15,
    14,
    1,
    9,
    12,
    5,
    1,
    15,
    14,
    13,
    4,
    10,
    0,
    7,
    6,
    3,
    9,
    2,
    8,
    11,
    13,
    11,
    7,
    14,
    12,
    1,
    3,
    9,
    5,
    0,
    15,
    4,
    8,
    6,
    2,
    10,
    6,
    15,
    14,
    9,
    11,
    3,
    0,
    8,
    12,
    2,
    13,
    7,
    1,
    4,
    10,
    5,
    10,
    2,
    8,
    4,
    7,
    6,
    1,
    5,
    15,
    11,
    9,
    14,
    3,
    12,
    13,
    0,
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    14,
    10,
    4,
    8,
    9,
    15,
    13,
    6,
    1,
    12,
    0,
    2,
    11,
    7,
    5,
    3,
    11,
    8,
    12,
    0,
    5,
    2,
    15,
    13,
    10,
    14,
    3,
    6,
    7,
    1,
    9,
    4,
    7,
    9,
    3,
    1,
    13,
    12,
    11,
    14,
    2,
    6,
    5,
    10,
    4,
    0,
    15,
    8,
    9,
    0,
    5,
    7,
    2,
    4,
    10,
    15,
    14,
    1,
    11,
    12,
    6,
    8,
    3,
    13,
    2,
    12,
    6,
    10,
    0,
    11,
    8,
    3,
    4,
    13,
    7,
    5,
    15,
    14,
    1,
    9
  ]);

  class BLAKE extends utils_js_1.Hash {
    constructor(blockLen, outputLen, opts = {}, keyLen, saltLen, persLen) {
      super();
      this.blockLen = blockLen;
      this.outputLen = outputLen;
      this.length = 0;
      this.pos = 0;
      this.finished = false;
      this.destroyed = false;
      (0, _assert_js_1.anumber)(blockLen);
      (0, _assert_js_1.anumber)(outputLen);
      (0, _assert_js_1.anumber)(keyLen);
      if (outputLen < 0 || outputLen > keyLen)
        throw new Error("outputLen bigger than keyLen");
      if (opts.key !== undefined && (opts.key.length < 1 || opts.key.length > keyLen))
        throw new Error("key length must be undefined or 1.." + keyLen);
      if (opts.salt !== undefined && opts.salt.length !== saltLen)
        throw new Error("salt must be undefined or " + saltLen);
      if (opts.personalization !== undefined && opts.personalization.length !== persLen)
        throw new Error("personalization must be undefined or " + persLen);
      this.buffer = new Uint8Array(blockLen);
      this.buffer32 = (0, utils_js_1.u32)(this.buffer);
    }
    update(data) {
      (0, _assert_js_1.aexists)(this);
      const { blockLen, buffer, buffer32 } = this;
      data = (0, utils_js_1.toBytes)(data);
      const len = data.length;
      const offset = data.byteOffset;
      const buf = data.buffer;
      for (let pos = 0;pos < len; ) {
        if (this.pos === blockLen) {
          if (!utils_js_1.isLE)
            (0, utils_js_1.byteSwap32)(buffer32);
          this.compress(buffer32, 0, false);
          if (!utils_js_1.isLE)
            (0, utils_js_1.byteSwap32)(buffer32);
          this.pos = 0;
        }
        const take = Math.min(blockLen - this.pos, len - pos);
        const dataOffset = offset + pos;
        if (take === blockLen && !(dataOffset % 4) && pos + take < len) {
          const data32 = new Uint32Array(buf, dataOffset, Math.floor((len - pos) / 4));
          if (!utils_js_1.isLE)
            (0, utils_js_1.byteSwap32)(data32);
          for (let pos32 = 0;pos + blockLen < len; pos32 += buffer32.length, pos += blockLen) {
            this.length += blockLen;
            this.compress(data32, pos32, false);
          }
          if (!utils_js_1.isLE)
            (0, utils_js_1.byteSwap32)(data32);
          continue;
        }
        buffer.set(data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        this.length += take;
        pos += take;
      }
      return this;
    }
    digestInto(out) {
      (0, _assert_js_1.aexists)(this);
      (0, _assert_js_1.aoutput)(out, this);
      const { pos, buffer32 } = this;
      this.finished = true;
      this.buffer.subarray(pos).fill(0);
      if (!utils_js_1.isLE)
        (0, utils_js_1.byteSwap32)(buffer32);
      this.compress(buffer32, 0, true);
      if (!utils_js_1.isLE)
        (0, utils_js_1.byteSwap32)(buffer32);
      const out32 = (0, utils_js_1.u32)(out);
      this.get().forEach((v, i) => out32[i] = (0, utils_js_1.byteSwapIfBE)(v));
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
    _cloneInto(to) {
      const { buffer, length, finished, destroyed, outputLen, pos } = this;
      to || (to = new this.constructor({ dkLen: outputLen }));
      to.set(...this.get());
      to.length = length;
      to.finished = finished;
      to.destroyed = destroyed;
      to.outputLen = outputLen;
      to.buffer.set(buffer);
      to.pos = pos;
      return to;
    }
  }
  exports.BLAKE = BLAKE;
});

// node_modules/@noble/hashes/_u64.js
var require__u64 = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.add5L = exports.add5H = exports.add4H = exports.add4L = exports.add3H = exports.add3L = exports.rotlBL = exports.rotlBH = exports.rotlSL = exports.rotlSH = exports.rotr32L = exports.rotr32H = exports.rotrBL = exports.rotrBH = exports.rotrSL = exports.rotrSH = exports.shrSL = exports.shrSH = exports.toBig = undefined;
  exports.fromBig = fromBig;
  exports.split = split;
  exports.add = add;
  var U32_MASK64 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
  var _32n = /* @__PURE__ */ BigInt(32);
  function fromBig(n, le = false) {
    if (le)
      return { h: Number(n & U32_MASK64), l: Number(n >> _32n & U32_MASK64) };
    return { h: Number(n >> _32n & U32_MASK64) | 0, l: Number(n & U32_MASK64) | 0 };
  }
  function split(lst, le = false) {
    let Ah = new Uint32Array(lst.length);
    let Al = new Uint32Array(lst.length);
    for (let i = 0;i < lst.length; i++) {
      const { h, l } = fromBig(lst[i], le);
      [Ah[i], Al[i]] = [h, l];
    }
    return [Ah, Al];
  }
  var toBig = (h, l) => BigInt(h >>> 0) << _32n | BigInt(l >>> 0);
  exports.toBig = toBig;
  var shrSH = (h, _l, s) => h >>> s;
  exports.shrSH = shrSH;
  var shrSL = (h, l, s) => h << 32 - s | l >>> s;
  exports.shrSL = shrSL;
  var rotrSH = (h, l, s) => h >>> s | l << 32 - s;
  exports.rotrSH = rotrSH;
  var rotrSL = (h, l, s) => h << 32 - s | l >>> s;
  exports.rotrSL = rotrSL;
  var rotrBH = (h, l, s) => h << 64 - s | l >>> s - 32;
  exports.rotrBH = rotrBH;
  var rotrBL = (h, l, s) => h >>> s - 32 | l << 64 - s;
  exports.rotrBL = rotrBL;
  var rotr32H = (_h, l) => l;
  exports.rotr32H = rotr32H;
  var rotr32L = (h, _l) => h;
  exports.rotr32L = rotr32L;
  var rotlSH = (h, l, s) => h << s | l >>> 32 - s;
  exports.rotlSH = rotlSH;
  var rotlSL = (h, l, s) => l << s | h >>> 32 - s;
  exports.rotlSL = rotlSL;
  var rotlBH = (h, l, s) => l << s - 32 | h >>> 64 - s;
  exports.rotlBH = rotlBH;
  var rotlBL = (h, l, s) => h << s - 32 | l >>> 64 - s;
  exports.rotlBL = rotlBL;
  function add(Ah, Al, Bh, Bl) {
    const l = (Al >>> 0) + (Bl >>> 0);
    return { h: Ah + Bh + (l / 2 ** 32 | 0) | 0, l: l | 0 };
  }
  var add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
  exports.add3L = add3L;
  var add3H = (low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0;
  exports.add3H = add3H;
  var add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0);
  exports.add4L = add4L;
  var add4H = (low, Ah, Bh, Ch, Dh) => Ah + Bh + Ch + Dh + (low / 2 ** 32 | 0) | 0;
  exports.add4H = add4H;
  var add5L = (Al, Bl, Cl, Dl, El) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0) + (El >>> 0);
  exports.add5L = add5L;
  var add5H = (low, Ah, Bh, Ch, Dh, Eh) => Ah + Bh + Ch + Dh + Eh + (low / 2 ** 32 | 0) | 0;
  exports.add5H = add5H;
  var u64 = {
    fromBig,
    split,
    toBig,
    shrSH,
    shrSL,
    rotrSH,
    rotrSL,
    rotrBH,
    rotrBL,
    rotr32H,
    rotr32L,
    rotlSH,
    rotlSL,
    rotlBH,
    rotlBL,
    add,
    add3L,
    add3H,
    add4L,
    add4H,
    add5H,
    add5L
  };
  exports.default = u64;
});

// node_modules/@noble/hashes/blake2s.js
var require_blake2s = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.blake2s = exports.BLAKE2s = exports.B2S_IV = undefined;
  exports.G1s = G1s;
  exports.G2s = G2s;
  exports.compress = compress;
  var _blake_js_1 = require__blake();
  var _u64_js_1 = require__u64();
  var utils_js_1 = require_utils();
  exports.B2S_IV = new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);
  function G1s(a, b, c, d, x) {
    a = a + b + x | 0;
    d = (0, utils_js_1.rotr)(d ^ a, 16);
    c = c + d | 0;
    b = (0, utils_js_1.rotr)(b ^ c, 12);
    return { a, b, c, d };
  }
  function G2s(a, b, c, d, x) {
    a = a + b + x | 0;
    d = (0, utils_js_1.rotr)(d ^ a, 8);
    c = c + d | 0;
    b = (0, utils_js_1.rotr)(b ^ c, 7);
    return { a, b, c, d };
  }
  function compress(s, offset, msg, rounds, v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15) {
    let j = 0;
    for (let i = 0;i < rounds; i++) {
      ({ a: v0, b: v4, c: v8, d: v12 } = G1s(v0, v4, v8, v12, msg[offset + s[j++]]));
      ({ a: v0, b: v4, c: v8, d: v12 } = G2s(v0, v4, v8, v12, msg[offset + s[j++]]));
      ({ a: v1, b: v5, c: v9, d: v13 } = G1s(v1, v5, v9, v13, msg[offset + s[j++]]));
      ({ a: v1, b: v5, c: v9, d: v13 } = G2s(v1, v5, v9, v13, msg[offset + s[j++]]));
      ({ a: v2, b: v6, c: v10, d: v14 } = G1s(v2, v6, v10, v14, msg[offset + s[j++]]));
      ({ a: v2, b: v6, c: v10, d: v14 } = G2s(v2, v6, v10, v14, msg[offset + s[j++]]));
      ({ a: v3, b: v7, c: v11, d: v15 } = G1s(v3, v7, v11, v15, msg[offset + s[j++]]));
      ({ a: v3, b: v7, c: v11, d: v15 } = G2s(v3, v7, v11, v15, msg[offset + s[j++]]));
      ({ a: v0, b: v5, c: v10, d: v15 } = G1s(v0, v5, v10, v15, msg[offset + s[j++]]));
      ({ a: v0, b: v5, c: v10, d: v15 } = G2s(v0, v5, v10, v15, msg[offset + s[j++]]));
      ({ a: v1, b: v6, c: v11, d: v12 } = G1s(v1, v6, v11, v12, msg[offset + s[j++]]));
      ({ a: v1, b: v6, c: v11, d: v12 } = G2s(v1, v6, v11, v12, msg[offset + s[j++]]));
      ({ a: v2, b: v7, c: v8, d: v13 } = G1s(v2, v7, v8, v13, msg[offset + s[j++]]));
      ({ a: v2, b: v7, c: v8, d: v13 } = G2s(v2, v7, v8, v13, msg[offset + s[j++]]));
      ({ a: v3, b: v4, c: v9, d: v14 } = G1s(v3, v4, v9, v14, msg[offset + s[j++]]));
      ({ a: v3, b: v4, c: v9, d: v14 } = G2s(v3, v4, v9, v14, msg[offset + s[j++]]));
    }
    return { v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15 };
  }

  class BLAKE2s extends _blake_js_1.BLAKE {
    constructor(opts = {}) {
      super(64, opts.dkLen === undefined ? 32 : opts.dkLen, opts, 32, 8, 8);
      this.v0 = exports.B2S_IV[0] | 0;
      this.v1 = exports.B2S_IV[1] | 0;
      this.v2 = exports.B2S_IV[2] | 0;
      this.v3 = exports.B2S_IV[3] | 0;
      this.v4 = exports.B2S_IV[4] | 0;
      this.v5 = exports.B2S_IV[5] | 0;
      this.v6 = exports.B2S_IV[6] | 0;
      this.v7 = exports.B2S_IV[7] | 0;
      const keyLength = opts.key ? opts.key.length : 0;
      this.v0 ^= this.outputLen | keyLength << 8 | 1 << 16 | 1 << 24;
      if (opts.salt) {
        const salt = (0, utils_js_1.u32)((0, utils_js_1.toBytes)(opts.salt));
        this.v4 ^= (0, utils_js_1.byteSwapIfBE)(salt[0]);
        this.v5 ^= (0, utils_js_1.byteSwapIfBE)(salt[1]);
      }
      if (opts.personalization) {
        const pers = (0, utils_js_1.u32)((0, utils_js_1.toBytes)(opts.personalization));
        this.v6 ^= (0, utils_js_1.byteSwapIfBE)(pers[0]);
        this.v7 ^= (0, utils_js_1.byteSwapIfBE)(pers[1]);
      }
      if (opts.key) {
        const tmp = new Uint8Array(this.blockLen);
        tmp.set((0, utils_js_1.toBytes)(opts.key));
        this.update(tmp);
      }
    }
    get() {
      const { v0, v1, v2, v3, v4, v5, v6, v7 } = this;
      return [v0, v1, v2, v3, v4, v5, v6, v7];
    }
    set(v0, v1, v2, v3, v4, v5, v6, v7) {
      this.v0 = v0 | 0;
      this.v1 = v1 | 0;
      this.v2 = v2 | 0;
      this.v3 = v3 | 0;
      this.v4 = v4 | 0;
      this.v5 = v5 | 0;
      this.v6 = v6 | 0;
      this.v7 = v7 | 0;
    }
    compress(msg, offset, isLast) {
      const { h, l } = (0, _u64_js_1.fromBig)(BigInt(this.length));
      const { v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15 } = compress(_blake_js_1.SIGMA, offset, msg, 10, this.v0, this.v1, this.v2, this.v3, this.v4, this.v5, this.v6, this.v7, exports.B2S_IV[0], exports.B2S_IV[1], exports.B2S_IV[2], exports.B2S_IV[3], l ^ exports.B2S_IV[4], h ^ exports.B2S_IV[5], isLast ? ~exports.B2S_IV[6] : exports.B2S_IV[6], exports.B2S_IV[7]);
      this.v0 ^= v0 ^ v8;
      this.v1 ^= v1 ^ v9;
      this.v2 ^= v2 ^ v10;
      this.v3 ^= v3 ^ v11;
      this.v4 ^= v4 ^ v12;
      this.v5 ^= v5 ^ v13;
      this.v6 ^= v6 ^ v14;
      this.v7 ^= v7 ^ v15;
    }
    destroy() {
      this.destroyed = true;
      this.buffer32.fill(0);
      this.set(0, 0, 0, 0, 0, 0, 0, 0);
    }
  }
  exports.BLAKE2s = BLAKE2s;
  exports.blake2s = (0, utils_js_1.wrapConstructorWithOpts)((opts) => new BLAKE2s(opts));
});

// node_modules/@noble/hashes/blake3.js
var require_blake3 = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.blake3 = exports.BLAKE3 = undefined;
  var _assert_js_1 = require__assert();
  var _blake_js_1 = require__blake();
  var _u64_js_1 = require__u64();
  var blake2s_js_1 = require_blake2s();
  var utils_js_1 = require_utils();
  var SIGMA = /* @__PURE__ */ (() => {
    const Id = Array.from({ length: 16 }, (_, i) => i);
    const permute = (arr) => [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8].map((i) => arr[i]);
    const res = [];
    for (let i = 0, v = Id;i < 7; i++, v = permute(v))
      res.push(...v);
    return Uint8Array.from(res);
  })();

  class BLAKE3 extends _blake_js_1.BLAKE {
    constructor(opts = {}, flags = 0) {
      super(64, opts.dkLen === undefined ? 32 : opts.dkLen, {}, Number.MAX_SAFE_INTEGER, 0, 0);
      this.flags = 0 | 0;
      this.chunkPos = 0;
      this.chunksDone = 0;
      this.stack = [];
      this.posOut = 0;
      this.bufferOut32 = new Uint32Array(16);
      this.chunkOut = 0;
      this.enableXOF = true;
      this.outputLen = opts.dkLen === undefined ? 32 : opts.dkLen;
      (0, _assert_js_1.anumber)(this.outputLen);
      if (opts.key !== undefined && opts.context !== undefined)
        throw new Error("Blake3: only key or context can be specified at same time");
      else if (opts.key !== undefined) {
        const key = (0, utils_js_1.toBytes)(opts.key).slice();
        if (key.length !== 32)
          throw new Error("Blake3: key should be 32 byte");
        this.IV = (0, utils_js_1.u32)(key);
        if (!utils_js_1.isLE)
          (0, utils_js_1.byteSwap32)(this.IV);
        this.flags = flags | 16;
      } else if (opts.context !== undefined) {
        const context_key = new BLAKE3({ dkLen: 32 }, 32).update(opts.context).digest();
        this.IV = (0, utils_js_1.u32)(context_key);
        if (!utils_js_1.isLE)
          (0, utils_js_1.byteSwap32)(this.IV);
        this.flags = flags | 64;
      } else {
        this.IV = blake2s_js_1.B2S_IV.slice();
        this.flags = flags;
      }
      this.state = this.IV.slice();
      this.bufferOut = (0, utils_js_1.u8)(this.bufferOut32);
    }
    get() {
      return [];
    }
    set() {
    }
    b2Compress(counter, flags, buf, bufPos = 0) {
      const { state: s, pos } = this;
      const { h, l } = (0, _u64_js_1.fromBig)(BigInt(counter), true);
      const { v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15 } = (0, blake2s_js_1.compress)(SIGMA, bufPos, buf, 7, s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], blake2s_js_1.B2S_IV[0], blake2s_js_1.B2S_IV[1], blake2s_js_1.B2S_IV[2], blake2s_js_1.B2S_IV[3], h, l, pos, flags);
      s[0] = v0 ^ v8;
      s[1] = v1 ^ v9;
      s[2] = v2 ^ v10;
      s[3] = v3 ^ v11;
      s[4] = v4 ^ v12;
      s[5] = v5 ^ v13;
      s[6] = v6 ^ v14;
      s[7] = v7 ^ v15;
    }
    compress(buf, bufPos = 0, isLast = false) {
      let flags = this.flags;
      if (!this.chunkPos)
        flags |= 1;
      if (this.chunkPos === 15 || isLast)
        flags |= 2;
      if (!isLast)
        this.pos = this.blockLen;
      this.b2Compress(this.chunksDone, flags, buf, bufPos);
      this.chunkPos += 1;
      if (this.chunkPos === 16 || isLast) {
        let chunk = this.state;
        this.state = this.IV.slice();
        for (let last, chunks = this.chunksDone + 1;isLast || !(chunks & 1); chunks >>= 1) {
          if (!(last = this.stack.pop()))
            break;
          this.buffer32.set(last, 0);
          this.buffer32.set(chunk, 8);
          this.pos = this.blockLen;
          this.b2Compress(0, this.flags | 4, this.buffer32, 0);
          chunk = this.state;
          this.state = this.IV.slice();
        }
        this.chunksDone++;
        this.chunkPos = 0;
        this.stack.push(chunk);
      }
      this.pos = 0;
    }
    _cloneInto(to) {
      to = super._cloneInto(to);
      const { IV, flags, state, chunkPos, posOut, chunkOut, stack, chunksDone } = this;
      to.state.set(state.slice());
      to.stack = stack.map((i) => Uint32Array.from(i));
      to.IV.set(IV);
      to.flags = flags;
      to.chunkPos = chunkPos;
      to.chunksDone = chunksDone;
      to.posOut = posOut;
      to.chunkOut = chunkOut;
      to.enableXOF = this.enableXOF;
      to.bufferOut32.set(this.bufferOut32);
      return to;
    }
    destroy() {
      this.destroyed = true;
      this.state.fill(0);
      this.buffer32.fill(0);
      this.IV.fill(0);
      this.bufferOut32.fill(0);
      for (let i of this.stack)
        i.fill(0);
    }
    b2CompressOut() {
      const { state: s, pos, flags, buffer32, bufferOut32: out32 } = this;
      const { h, l } = (0, _u64_js_1.fromBig)(BigInt(this.chunkOut++));
      if (!utils_js_1.isLE)
        (0, utils_js_1.byteSwap32)(buffer32);
      const { v0, v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15 } = (0, blake2s_js_1.compress)(SIGMA, 0, buffer32, 7, s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], blake2s_js_1.B2S_IV[0], blake2s_js_1.B2S_IV[1], blake2s_js_1.B2S_IV[2], blake2s_js_1.B2S_IV[3], l, h, pos, flags);
      out32[0] = v0 ^ v8;
      out32[1] = v1 ^ v9;
      out32[2] = v2 ^ v10;
      out32[3] = v3 ^ v11;
      out32[4] = v4 ^ v12;
      out32[5] = v5 ^ v13;
      out32[6] = v6 ^ v14;
      out32[7] = v7 ^ v15;
      out32[8] = s[0] ^ v8;
      out32[9] = s[1] ^ v9;
      out32[10] = s[2] ^ v10;
      out32[11] = s[3] ^ v11;
      out32[12] = s[4] ^ v12;
      out32[13] = s[5] ^ v13;
      out32[14] = s[6] ^ v14;
      out32[15] = s[7] ^ v15;
      if (!utils_js_1.isLE) {
        (0, utils_js_1.byteSwap32)(buffer32);
        (0, utils_js_1.byteSwap32)(out32);
      }
      this.posOut = 0;
    }
    finish() {
      if (this.finished)
        return;
      this.finished = true;
      this.buffer.fill(0, this.pos);
      let flags = this.flags | 8;
      if (this.stack.length) {
        flags |= 4;
        if (!utils_js_1.isLE)
          (0, utils_js_1.byteSwap32)(this.buffer32);
        this.compress(this.buffer32, 0, true);
        if (!utils_js_1.isLE)
          (0, utils_js_1.byteSwap32)(this.buffer32);
        this.chunksDone = 0;
        this.pos = this.blockLen;
      } else {
        flags |= (!this.chunkPos ? 1 : 0) | 2;
      }
      this.flags = flags;
      this.b2CompressOut();
    }
    writeInto(out) {
      (0, _assert_js_1.aexists)(this, false);
      (0, _assert_js_1.abytes)(out);
      this.finish();
      const { blockLen, bufferOut } = this;
      for (let pos = 0, len = out.length;pos < len; ) {
        if (this.posOut >= blockLen)
          this.b2CompressOut();
        const take = Math.min(blockLen - this.posOut, len - pos);
        out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
        this.posOut += take;
        pos += take;
      }
      return out;
    }
    xofInto(out) {
      if (!this.enableXOF)
        throw new Error("XOF is not possible after digest call");
      return this.writeInto(out);
    }
    xof(bytes) {
      (0, _assert_js_1.anumber)(bytes);
      return this.xofInto(new Uint8Array(bytes));
    }
    digestInto(out) {
      (0, _assert_js_1.aoutput)(out, this);
      if (this.finished)
        throw new Error("digest() was already called");
      this.enableXOF = false;
      this.writeInto(out);
      this.destroy();
      return out;
    }
    digest() {
      return this.digestInto(new Uint8Array(this.outputLen));
    }
  }
  exports.BLAKE3 = BLAKE3;
  exports.blake3 = (0, utils_js_1.wrapXOFConstructorWithOpts)((opts) => new BLAKE3(opts));
});

// node_modules/@noble/ciphers/_assert.js
var require__assert2 = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.abool = abool;
  exports.abytes = abytes;
  exports.aexists = aexists;
  exports.ahash = ahash;
  exports.anumber = anumber;
  exports.aoutput = aoutput;
  exports.isBytes = isBytes;
  function anumber(n) {
    if (!Number.isSafeInteger(n) || n < 0)
      throw new Error("positive integer expected, got " + n);
  }
  function isBytes(a) {
    return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
  }
  function abytes(b, ...lengths) {
    if (!isBytes(b))
      throw new Error("Uint8Array expected");
    if (lengths.length > 0 && !lengths.includes(b.length))
      throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b.length);
  }
  function ahash(h) {
    if (typeof h !== "function" || typeof h.create !== "function")
      throw new Error("Hash should be wrapped by utils.wrapConstructor");
    anumber(h.outputLen);
    anumber(h.blockLen);
  }
  function aexists(instance, checkFinished = true) {
    if (instance.destroyed)
      throw new Error("Hash instance has been destroyed");
    if (checkFinished && instance.finished)
      throw new Error("Hash#digest() has already been called");
  }
  function aoutput(out, instance) {
    abytes(out);
    const min = instance.outputLen;
    if (out.length < min) {
      throw new Error("digestInto() expects output buffer of length at least " + min);
    }
  }
  function abool(b) {
    if (typeof b !== "boolean")
      throw new Error(`boolean expected, not ${b}`);
  }
});

// node_modules/@noble/ciphers/utils.js
var require_utils2 = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.wrapCipher = exports.Hash = exports.nextTick = exports.isLE = exports.createView = exports.u32 = exports.u8 = undefined;
  exports.bytesToHex = bytesToHex;
  exports.hexToBytes = hexToBytes;
  exports.hexToNumber = hexToNumber;
  exports.bytesToNumberBE = bytesToNumberBE;
  exports.numberToBytesBE = numberToBytesBE;
  exports.utf8ToBytes = utf8ToBytes;
  exports.bytesToUtf8 = bytesToUtf8;
  exports.toBytes = toBytes;
  exports.overlapBytes = overlapBytes;
  exports.complexOverlapBytes = complexOverlapBytes;
  exports.concatBytes = concatBytes;
  exports.checkOpts = checkOpts;
  exports.equalBytes = equalBytes;
  exports.getOutput = getOutput;
  exports.setBigUint64 = setBigUint64;
  exports.u64Lengths = u64Lengths;
  exports.isAligned32 = isAligned32;
  exports.copyBytes = copyBytes;
  exports.clean = clean;
  /*! noble-ciphers - MIT License (c) 2023 Paul Miller (paulmillr.com) */
  var _assert_js_1 = require__assert2();
  var u8 = (arr) => new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
  exports.u8 = u8;
  var u32 = (arr) => new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
  exports.u32 = u32;
  var createView = (arr) => new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
  exports.createView = createView;
  exports.isLE = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
  if (!exports.isLE)
    throw new Error("Non little-endian hardware is not supported");
  var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
  function bytesToHex(bytes) {
    (0, _assert_js_1.abytes)(bytes);
    let hex = "";
    for (let i = 0;i < bytes.length; i++) {
      hex += hexes[bytes[i]];
    }
    return hex;
  }
  var asciis = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 };
  function asciiToBase16(ch) {
    if (ch >= asciis._0 && ch <= asciis._9)
      return ch - asciis._0;
    if (ch >= asciis.A && ch <= asciis.F)
      return ch - (asciis.A - 10);
    if (ch >= asciis.a && ch <= asciis.f)
      return ch - (asciis.a - 10);
    return;
  }
  function hexToBytes(hex) {
    if (typeof hex !== "string")
      throw new Error("hex string expected, got " + typeof hex);
    const hl = hex.length;
    const al = hl / 2;
    if (hl % 2)
      throw new Error("hex string expected, got unpadded hex of length " + hl);
    const array = new Uint8Array(al);
    for (let ai = 0, hi = 0;ai < al; ai++, hi += 2) {
      const n1 = asciiToBase16(hex.charCodeAt(hi));
      const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
      if (n1 === undefined || n2 === undefined) {
        const char = hex[hi] + hex[hi + 1];
        throw new Error('hex string expected, got non-hex character "' + char + '" at index ' + hi);
      }
      array[ai] = n1 * 16 + n2;
    }
    return array;
  }
  function hexToNumber(hex) {
    if (typeof hex !== "string")
      throw new Error("hex string expected, got " + typeof hex);
    return BigInt(hex === "" ? "0" : "0x" + hex);
  }
  function bytesToNumberBE(bytes) {
    return hexToNumber(bytesToHex(bytes));
  }
  function numberToBytesBE(n, len) {
    return hexToBytes(n.toString(16).padStart(len * 2, "0"));
  }
  var nextTick = async () => {
  };
  exports.nextTick = nextTick;
  function utf8ToBytes(str) {
    if (typeof str !== "string")
      throw new Error("string expected");
    return new Uint8Array(new TextEncoder().encode(str));
  }
  function bytesToUtf8(bytes) {
    return new TextDecoder().decode(bytes);
  }
  function toBytes(data) {
    if (typeof data === "string")
      data = utf8ToBytes(data);
    else if ((0, _assert_js_1.isBytes)(data))
      data = copyBytes(data);
    else
      throw new Error("Uint8Array expected, got " + typeof data);
    return data;
  }
  function overlapBytes(a, b) {
    return a.buffer === b.buffer && a.byteOffset < b.byteOffset + b.byteLength && b.byteOffset < a.byteOffset + a.byteLength;
  }
  function complexOverlapBytes(input, output) {
    if (overlapBytes(input, output) && input.byteOffset < output.byteOffset)
      throw new Error("complex overlap of input and output is not supported");
  }
  function concatBytes(...arrays) {
    let sum = 0;
    for (let i = 0;i < arrays.length; i++) {
      const a = arrays[i];
      (0, _assert_js_1.abytes)(a);
      sum += a.length;
    }
    const res = new Uint8Array(sum);
    for (let i = 0, pad = 0;i < arrays.length; i++) {
      const a = arrays[i];
      res.set(a, pad);
      pad += a.length;
    }
    return res;
  }
  function checkOpts(defaults, opts) {
    if (opts == null || typeof opts !== "object")
      throw new Error("options must be defined");
    const merged = Object.assign(defaults, opts);
    return merged;
  }
  function equalBytes(a, b) {
    if (a.length !== b.length)
      return false;
    let diff = 0;
    for (let i = 0;i < a.length; i++)
      diff |= a[i] ^ b[i];
    return diff === 0;
  }

  class Hash {
  }
  exports.Hash = Hash;
  var wrapCipher = (params, constructor) => {
    function wrappedCipher(key, ...args) {
      (0, _assert_js_1.abytes)(key);
      if (params.nonceLength !== undefined) {
        const nonce = args[0];
        if (!nonce)
          throw new Error("nonce / iv required");
        if (params.varSizeNonce)
          (0, _assert_js_1.abytes)(nonce);
        else
          (0, _assert_js_1.abytes)(nonce, params.nonceLength);
      }
      const tagl = params.tagLength;
      if (tagl && args[1] !== undefined) {
        (0, _assert_js_1.abytes)(args[1]);
      }
      const cipher = constructor(key, ...args);
      const checkOutput = (fnLength, output) => {
        if (output !== undefined) {
          if (fnLength !== 2)
            throw new Error("cipher output not supported");
          (0, _assert_js_1.abytes)(output);
        }
      };
      let called = false;
      const wrCipher = {
        encrypt(data, output) {
          if (called)
            throw new Error("cannot encrypt() twice with same key + nonce");
          called = true;
          (0, _assert_js_1.abytes)(data);
          checkOutput(cipher.encrypt.length, output);
          return cipher.encrypt(data, output);
        },
        decrypt(data, output) {
          (0, _assert_js_1.abytes)(data);
          if (tagl && data.length < tagl)
            throw new Error("invalid ciphertext length: smaller than tagLength=" + tagl);
          checkOutput(cipher.decrypt.length, output);
          return cipher.decrypt(data, output);
        }
      };
      return wrCipher;
    }
    Object.assign(wrappedCipher, params);
    return wrappedCipher;
  };
  exports.wrapCipher = wrapCipher;
  function getOutput(expectedLength, out, onlyAligned = true) {
    if (out === undefined)
      return new Uint8Array(expectedLength);
    if (out.length !== expectedLength)
      throw new Error("invalid output length, expected " + expectedLength + ", got: " + out.length);
    if (onlyAligned && !isAligned32(out))
      throw new Error("invalid output, must be aligned");
    return out;
  }
  function setBigUint64(view, byteOffset, value, isLE) {
    if (typeof view.setBigUint64 === "function")
      return view.setBigUint64(byteOffset, value, isLE);
    const _32n = BigInt(32);
    const _u32_max = BigInt(4294967295);
    const wh = Number(value >> _32n & _u32_max);
    const wl = Number(value & _u32_max);
    const h = isLE ? 4 : 0;
    const l = isLE ? 0 : 4;
    view.setUint32(byteOffset + h, wh, isLE);
    view.setUint32(byteOffset + l, wl, isLE);
  }
  function u64Lengths(ciphertext, AAD) {
    const num = new Uint8Array(16);
    const view = (0, exports.createView)(num);
    setBigUint64(view, 0, BigInt(AAD ? AAD.length : 0), true);
    setBigUint64(view, 8, BigInt(ciphertext.length), true);
    return num;
  }
  function isAligned32(bytes) {
    return bytes.byteOffset % 4 === 0;
  }
  function copyBytes(bytes) {
    return Uint8Array.from(bytes);
  }
  function clean(...arrays) {
    for (let i = 0;i < arrays.length; i++) {
      arrays[i].fill(0);
    }
  }
});

// node_modules/@noble/ciphers/_arx.js
var require__arx = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.rotl = rotl;
  exports.createCipher = createCipher;
  var _assert_js_1 = require__assert2();
  var utils_js_1 = require_utils2();
  var _utf8ToBytes = (str) => Uint8Array.from(str.split("").map((c) => c.charCodeAt(0)));
  var sigma16 = _utf8ToBytes("expand 16-byte k");
  var sigma32 = _utf8ToBytes("expand 32-byte k");
  var sigma16_32 = (0, utils_js_1.u32)(sigma16);
  var sigma32_32 = (0, utils_js_1.u32)(sigma32);
  function rotl(a, b) {
    return a << b | a >>> 32 - b;
  }
  function isAligned32(b) {
    return b.byteOffset % 4 === 0;
  }
  var BLOCK_LEN = 64;
  var BLOCK_LEN32 = 16;
  var MAX_COUNTER = 2 ** 32 - 1;
  var U32_EMPTY = new Uint32Array;
  function runCipher(core, sigma, key, nonce, data, output, counter, rounds) {
    const len = data.length;
    const block = new Uint8Array(BLOCK_LEN);
    const b32 = (0, utils_js_1.u32)(block);
    const isAligned = isAligned32(data) && isAligned32(output);
    const d32 = isAligned ? (0, utils_js_1.u32)(data) : U32_EMPTY;
    const o32 = isAligned ? (0, utils_js_1.u32)(output) : U32_EMPTY;
    for (let pos = 0;pos < len; counter++) {
      core(sigma, key, nonce, b32, counter, rounds);
      if (counter >= MAX_COUNTER)
        throw new Error("arx: counter overflow");
      const take = Math.min(BLOCK_LEN, len - pos);
      if (isAligned && take === BLOCK_LEN) {
        const pos32 = pos / 4;
        if (pos % 4 !== 0)
          throw new Error("arx: invalid block position");
        for (let j = 0, posj;j < BLOCK_LEN32; j++) {
          posj = pos32 + j;
          o32[posj] = d32[posj] ^ b32[j];
        }
        pos += BLOCK_LEN;
        continue;
      }
      for (let j = 0, posj;j < take; j++) {
        posj = pos + j;
        output[posj] = data[posj] ^ block[j];
      }
      pos += take;
    }
  }
  function createCipher(core, opts) {
    const { allowShortKeys, extendNonceFn, counterLength, counterRight, rounds } = (0, utils_js_1.checkOpts)({ allowShortKeys: false, counterLength: 8, counterRight: false, rounds: 20 }, opts);
    if (typeof core !== "function")
      throw new Error("core must be a function");
    (0, _assert_js_1.anumber)(counterLength);
    (0, _assert_js_1.anumber)(rounds);
    (0, _assert_js_1.abool)(counterRight);
    (0, _assert_js_1.abool)(allowShortKeys);
    return (key, nonce, data, output, counter = 0) => {
      (0, _assert_js_1.abytes)(key);
      (0, _assert_js_1.abytes)(nonce);
      (0, _assert_js_1.abytes)(data);
      const len = data.length;
      if (output === undefined)
        output = new Uint8Array(len);
      (0, _assert_js_1.abytes)(output);
      (0, _assert_js_1.anumber)(counter);
      if (counter < 0 || counter >= MAX_COUNTER)
        throw new Error("arx: counter overflow");
      if (output.length < len)
        throw new Error(`arx: output (${output.length}) is shorter than data (${len})`);
      const toClean = [];
      let l = key.length;
      let k;
      let sigma;
      if (l === 32) {
        toClean.push(k = (0, utils_js_1.copyBytes)(key));
        sigma = sigma32_32;
      } else if (l === 16 && allowShortKeys) {
        k = new Uint8Array(32);
        k.set(key);
        k.set(key, 16);
        sigma = sigma16_32;
        toClean.push(k);
      } else {
        throw new Error(`arx: invalid 32-byte key, got length=${l}`);
      }
      if (!isAligned32(nonce))
        toClean.push(nonce = (0, utils_js_1.copyBytes)(nonce));
      const k32 = (0, utils_js_1.u32)(k);
      if (extendNonceFn) {
        if (nonce.length !== 24)
          throw new Error(`arx: extended nonce must be 24 bytes`);
        extendNonceFn(sigma, k32, (0, utils_js_1.u32)(nonce.subarray(0, 16)), k32);
        nonce = nonce.subarray(16);
      }
      const nonceNcLen = 16 - counterLength;
      if (nonceNcLen !== nonce.length)
        throw new Error(`arx: nonce must be ${nonceNcLen} or 16 bytes`);
      if (nonceNcLen !== 12) {
        const nc = new Uint8Array(12);
        nc.set(nonce, counterRight ? 0 : 12 - nonce.length);
        nonce = nc;
        toClean.push(nonce);
      }
      const n32 = (0, utils_js_1.u32)(nonce);
      runCipher(core, sigma, k32, n32, data, output, counter, rounds);
      (0, utils_js_1.clean)(...toClean);
      return output;
    };
  }
});

// node_modules/@noble/ciphers/_poly1305.js
var require__poly1305 = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.poly1305 = undefined;
  exports.wrapConstructorWithKey = wrapConstructorWithKey;
  var _assert_js_1 = require__assert2();
  var utils_js_1 = require_utils2();
  var u8to16 = (a, i) => a[i++] & 255 | (a[i++] & 255) << 8;

  class Poly1305 {
    constructor(key) {
      this.blockLen = 16;
      this.outputLen = 16;
      this.buffer = new Uint8Array(16);
      this.r = new Uint16Array(10);
      this.h = new Uint16Array(10);
      this.pad = new Uint16Array(8);
      this.pos = 0;
      this.finished = false;
      key = (0, utils_js_1.toBytes)(key);
      (0, _assert_js_1.abytes)(key, 32);
      const t0 = u8to16(key, 0);
      const t1 = u8to16(key, 2);
      const t2 = u8to16(key, 4);
      const t3 = u8to16(key, 6);
      const t4 = u8to16(key, 8);
      const t5 = u8to16(key, 10);
      const t6 = u8to16(key, 12);
      const t7 = u8to16(key, 14);
      this.r[0] = t0 & 8191;
      this.r[1] = (t0 >>> 13 | t1 << 3) & 8191;
      this.r[2] = (t1 >>> 10 | t2 << 6) & 7939;
      this.r[3] = (t2 >>> 7 | t3 << 9) & 8191;
      this.r[4] = (t3 >>> 4 | t4 << 12) & 255;
      this.r[5] = t4 >>> 1 & 8190;
      this.r[6] = (t4 >>> 14 | t5 << 2) & 8191;
      this.r[7] = (t5 >>> 11 | t6 << 5) & 8065;
      this.r[8] = (t6 >>> 8 | t7 << 8) & 8191;
      this.r[9] = t7 >>> 5 & 127;
      for (let i = 0;i < 8; i++)
        this.pad[i] = u8to16(key, 16 + 2 * i);
    }
    process(data, offset, isLast = false) {
      const hibit = isLast ? 0 : 1 << 11;
      const { h, r } = this;
      const r0 = r[0];
      const r1 = r[1];
      const r2 = r[2];
      const r3 = r[3];
      const r4 = r[4];
      const r5 = r[5];
      const r6 = r[6];
      const r7 = r[7];
      const r8 = r[8];
      const r9 = r[9];
      const t0 = u8to16(data, offset + 0);
      const t1 = u8to16(data, offset + 2);
      const t2 = u8to16(data, offset + 4);
      const t3 = u8to16(data, offset + 6);
      const t4 = u8to16(data, offset + 8);
      const t5 = u8to16(data, offset + 10);
      const t6 = u8to16(data, offset + 12);
      const t7 = u8to16(data, offset + 14);
      let h0 = h[0] + (t0 & 8191);
      let h1 = h[1] + ((t0 >>> 13 | t1 << 3) & 8191);
      let h2 = h[2] + ((t1 >>> 10 | t2 << 6) & 8191);
      let h3 = h[3] + ((t2 >>> 7 | t3 << 9) & 8191);
      let h4 = h[4] + ((t3 >>> 4 | t4 << 12) & 8191);
      let h5 = h[5] + (t4 >>> 1 & 8191);
      let h6 = h[6] + ((t4 >>> 14 | t5 << 2) & 8191);
      let h7 = h[7] + ((t5 >>> 11 | t6 << 5) & 8191);
      let h8 = h[8] + ((t6 >>> 8 | t7 << 8) & 8191);
      let h9 = h[9] + (t7 >>> 5 | hibit);
      let c = 0;
      let d0 = c + h0 * r0 + h1 * (5 * r9) + h2 * (5 * r8) + h3 * (5 * r7) + h4 * (5 * r6);
      c = d0 >>> 13;
      d0 &= 8191;
      d0 += h5 * (5 * r5) + h6 * (5 * r4) + h7 * (5 * r3) + h8 * (5 * r2) + h9 * (5 * r1);
      c += d0 >>> 13;
      d0 &= 8191;
      let d1 = c + h0 * r1 + h1 * r0 + h2 * (5 * r9) + h3 * (5 * r8) + h4 * (5 * r7);
      c = d1 >>> 13;
      d1 &= 8191;
      d1 += h5 * (5 * r6) + h6 * (5 * r5) + h7 * (5 * r4) + h8 * (5 * r3) + h9 * (5 * r2);
      c += d1 >>> 13;
      d1 &= 8191;
      let d2 = c + h0 * r2 + h1 * r1 + h2 * r0 + h3 * (5 * r9) + h4 * (5 * r8);
      c = d2 >>> 13;
      d2 &= 8191;
      d2 += h5 * (5 * r7) + h6 * (5 * r6) + h7 * (5 * r5) + h8 * (5 * r4) + h9 * (5 * r3);
      c += d2 >>> 13;
      d2 &= 8191;
      let d3 = c + h0 * r3 + h1 * r2 + h2 * r1 + h3 * r0 + h4 * (5 * r9);
      c = d3 >>> 13;
      d3 &= 8191;
      d3 += h5 * (5 * r8) + h6 * (5 * r7) + h7 * (5 * r6) + h8 * (5 * r5) + h9 * (5 * r4);
      c += d3 >>> 13;
      d3 &= 8191;
      let d4 = c + h0 * r4 + h1 * r3 + h2 * r2 + h3 * r1 + h4 * r0;
      c = d4 >>> 13;
      d4 &= 8191;
      d4 += h5 * (5 * r9) + h6 * (5 * r8) + h7 * (5 * r7) + h8 * (5 * r6) + h9 * (5 * r5);
      c += d4 >>> 13;
      d4 &= 8191;
      let d5 = c + h0 * r5 + h1 * r4 + h2 * r3 + h3 * r2 + h4 * r1;
      c = d5 >>> 13;
      d5 &= 8191;
      d5 += h5 * r0 + h6 * (5 * r9) + h7 * (5 * r8) + h8 * (5 * r7) + h9 * (5 * r6);
      c += d5 >>> 13;
      d5 &= 8191;
      let d6 = c + h0 * r6 + h1 * r5 + h2 * r4 + h3 * r3 + h4 * r2;
      c = d6 >>> 13;
      d6 &= 8191;
      d6 += h5 * r1 + h6 * r0 + h7 * (5 * r9) + h8 * (5 * r8) + h9 * (5 * r7);
      c += d6 >>> 13;
      d6 &= 8191;
      let d7 = c + h0 * r7 + h1 * r6 + h2 * r5 + h3 * r4 + h4 * r3;
      c = d7 >>> 13;
      d7 &= 8191;
      d7 += h5 * r2 + h6 * r1 + h7 * r0 + h8 * (5 * r9) + h9 * (5 * r8);
      c += d7 >>> 13;
      d7 &= 8191;
      let d8 = c + h0 * r8 + h1 * r7 + h2 * r6 + h3 * r5 + h4 * r4;
      c = d8 >>> 13;
      d8 &= 8191;
      d8 += h5 * r3 + h6 * r2 + h7 * r1 + h8 * r0 + h9 * (5 * r9);
      c += d8 >>> 13;
      d8 &= 8191;
      let d9 = c + h0 * r9 + h1 * r8 + h2 * r7 + h3 * r6 + h4 * r5;
      c = d9 >>> 13;
      d9 &= 8191;
      d9 += h5 * r4 + h6 * r3 + h7 * r2 + h8 * r1 + h9 * r0;
      c += d9 >>> 13;
      d9 &= 8191;
      c = (c << 2) + c | 0;
      c = c + d0 | 0;
      d0 = c & 8191;
      c = c >>> 13;
      d1 += c;
      h[0] = d0;
      h[1] = d1;
      h[2] = d2;
      h[3] = d3;
      h[4] = d4;
      h[5] = d5;
      h[6] = d6;
      h[7] = d7;
      h[8] = d8;
      h[9] = d9;
    }
    finalize() {
      const { h, pad } = this;
      const g = new Uint16Array(10);
      let c = h[1] >>> 13;
      h[1] &= 8191;
      for (let i = 2;i < 10; i++) {
        h[i] += c;
        c = h[i] >>> 13;
        h[i] &= 8191;
      }
      h[0] += c * 5;
      c = h[0] >>> 13;
      h[0] &= 8191;
      h[1] += c;
      c = h[1] >>> 13;
      h[1] &= 8191;
      h[2] += c;
      g[0] = h[0] + 5;
      c = g[0] >>> 13;
      g[0] &= 8191;
      for (let i = 1;i < 10; i++) {
        g[i] = h[i] + c;
        c = g[i] >>> 13;
        g[i] &= 8191;
      }
      g[9] -= 1 << 13;
      let mask = (c ^ 1) - 1;
      for (let i = 0;i < 10; i++)
        g[i] &= mask;
      mask = ~mask;
      for (let i = 0;i < 10; i++)
        h[i] = h[i] & mask | g[i];
      h[0] = (h[0] | h[1] << 13) & 65535;
      h[1] = (h[1] >>> 3 | h[2] << 10) & 65535;
      h[2] = (h[2] >>> 6 | h[3] << 7) & 65535;
      h[3] = (h[3] >>> 9 | h[4] << 4) & 65535;
      h[4] = (h[4] >>> 12 | h[5] << 1 | h[6] << 14) & 65535;
      h[5] = (h[6] >>> 2 | h[7] << 11) & 65535;
      h[6] = (h[7] >>> 5 | h[8] << 8) & 65535;
      h[7] = (h[8] >>> 8 | h[9] << 5) & 65535;
      let f = h[0] + pad[0];
      h[0] = f & 65535;
      for (let i = 1;i < 8; i++) {
        f = (h[i] + pad[i] | 0) + (f >>> 16) | 0;
        h[i] = f & 65535;
      }
      (0, utils_js_1.clean)(g);
    }
    update(data) {
      (0, _assert_js_1.aexists)(this);
      const { buffer, blockLen } = this;
      data = (0, utils_js_1.toBytes)(data);
      const len = data.length;
      for (let pos = 0;pos < len; ) {
        const take = Math.min(blockLen - this.pos, len - pos);
        if (take === blockLen) {
          for (;blockLen <= len - pos; pos += blockLen)
            this.process(data, pos);
          continue;
        }
        buffer.set(data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        pos += take;
        if (this.pos === blockLen) {
          this.process(buffer, 0, false);
          this.pos = 0;
        }
      }
      return this;
    }
    destroy() {
      (0, utils_js_1.clean)(this.h, this.r, this.buffer, this.pad);
    }
    digestInto(out) {
      (0, _assert_js_1.aexists)(this);
      (0, _assert_js_1.aoutput)(out, this);
      this.finished = true;
      const { buffer, h } = this;
      let { pos } = this;
      if (pos) {
        buffer[pos++] = 1;
        for (;pos < 16; pos++)
          buffer[pos] = 0;
        this.process(buffer, 0, true);
      }
      this.finalize();
      let opos = 0;
      for (let i = 0;i < 8; i++) {
        out[opos++] = h[i] >>> 0;
        out[opos++] = h[i] >>> 8;
      }
      return out;
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
  }
  function wrapConstructorWithKey(hashCons) {
    const hashC = (msg, key) => hashCons(key).update((0, utils_js_1.toBytes)(msg)).digest();
    const tmp = hashCons(new Uint8Array(32));
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = (key) => hashCons(key);
    return hashC;
  }
  exports.poly1305 = wrapConstructorWithKey((key) => new Poly1305(key));
});

// node_modules/@noble/ciphers/chacha.js
var require_chacha = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.xchacha20poly1305 = exports.chacha20poly1305 = exports._poly1305_aead = exports.chacha12 = exports.chacha8 = exports.xchacha20 = exports.chacha20 = exports.chacha20orig = undefined;
  exports.hchacha = hchacha;
  var _arx_js_1 = require__arx();
  var _poly1305_js_1 = require__poly1305();
  var utils_js_1 = require_utils2();
  function chachaCore(s, k, n, out, cnt, rounds = 20) {
    let y00 = s[0], y01 = s[1], y02 = s[2], y03 = s[3], y04 = k[0], y05 = k[1], y06 = k[2], y07 = k[3], y08 = k[4], y09 = k[5], y10 = k[6], y11 = k[7], y12 = cnt, y13 = n[0], y14 = n[1], y15 = n[2];
    let x00 = y00, x01 = y01, x02 = y02, x03 = y03, x04 = y04, x05 = y05, x06 = y06, x07 = y07, x08 = y08, x09 = y09, x10 = y10, x11 = y11, x12 = y12, x13 = y13, x14 = y14, x15 = y15;
    for (let r = 0;r < rounds; r += 2) {
      x00 = x00 + x04 | 0;
      x12 = (0, _arx_js_1.rotl)(x12 ^ x00, 16);
      x08 = x08 + x12 | 0;
      x04 = (0, _arx_js_1.rotl)(x04 ^ x08, 12);
      x00 = x00 + x04 | 0;
      x12 = (0, _arx_js_1.rotl)(x12 ^ x00, 8);
      x08 = x08 + x12 | 0;
      x04 = (0, _arx_js_1.rotl)(x04 ^ x08, 7);
      x01 = x01 + x05 | 0;
      x13 = (0, _arx_js_1.rotl)(x13 ^ x01, 16);
      x09 = x09 + x13 | 0;
      x05 = (0, _arx_js_1.rotl)(x05 ^ x09, 12);
      x01 = x01 + x05 | 0;
      x13 = (0, _arx_js_1.rotl)(x13 ^ x01, 8);
      x09 = x09 + x13 | 0;
      x05 = (0, _arx_js_1.rotl)(x05 ^ x09, 7);
      x02 = x02 + x06 | 0;
      x14 = (0, _arx_js_1.rotl)(x14 ^ x02, 16);
      x10 = x10 + x14 | 0;
      x06 = (0, _arx_js_1.rotl)(x06 ^ x10, 12);
      x02 = x02 + x06 | 0;
      x14 = (0, _arx_js_1.rotl)(x14 ^ x02, 8);
      x10 = x10 + x14 | 0;
      x06 = (0, _arx_js_1.rotl)(x06 ^ x10, 7);
      x03 = x03 + x07 | 0;
      x15 = (0, _arx_js_1.rotl)(x15 ^ x03, 16);
      x11 = x11 + x15 | 0;
      x07 = (0, _arx_js_1.rotl)(x07 ^ x11, 12);
      x03 = x03 + x07 | 0;
      x15 = (0, _arx_js_1.rotl)(x15 ^ x03, 8);
      x11 = x11 + x15 | 0;
      x07 = (0, _arx_js_1.rotl)(x07 ^ x11, 7);
      x00 = x00 + x05 | 0;
      x15 = (0, _arx_js_1.rotl)(x15 ^ x00, 16);
      x10 = x10 + x15 | 0;
      x05 = (0, _arx_js_1.rotl)(x05 ^ x10, 12);
      x00 = x00 + x05 | 0;
      x15 = (0, _arx_js_1.rotl)(x15 ^ x00, 8);
      x10 = x10 + x15 | 0;
      x05 = (0, _arx_js_1.rotl)(x05 ^ x10, 7);
      x01 = x01 + x06 | 0;
      x12 = (0, _arx_js_1.rotl)(x12 ^ x01, 16);
      x11 = x11 + x12 | 0;
      x06 = (0, _arx_js_1.rotl)(x06 ^ x11, 12);
      x01 = x01 + x06 | 0;
      x12 = (0, _arx_js_1.rotl)(x12 ^ x01, 8);
      x11 = x11 + x12 | 0;
      x06 = (0, _arx_js_1.rotl)(x06 ^ x11, 7);
      x02 = x02 + x07 | 0;
      x13 = (0, _arx_js_1.rotl)(x13 ^ x02, 16);
      x08 = x08 + x13 | 0;
      x07 = (0, _arx_js_1.rotl)(x07 ^ x08, 12);
      x02 = x02 + x07 | 0;
      x13 = (0, _arx_js_1.rotl)(x13 ^ x02, 8);
      x08 = x08 + x13 | 0;
      x07 = (0, _arx_js_1.rotl)(x07 ^ x08, 7);
      x03 = x03 + x04 | 0;
      x14 = (0, _arx_js_1.rotl)(x14 ^ x03, 16);
      x09 = x09 + x14 | 0;
      x04 = (0, _arx_js_1.rotl)(x04 ^ x09, 12);
      x03 = x03 + x04 | 0;
      x14 = (0, _arx_js_1.rotl)(x14 ^ x03, 8);
      x09 = x09 + x14 | 0;
      x04 = (0, _arx_js_1.rotl)(x04 ^ x09, 7);
    }
    let oi = 0;
    out[oi++] = y00 + x00 | 0;
    out[oi++] = y01 + x01 | 0;
    out[oi++] = y02 + x02 | 0;
    out[oi++] = y03 + x03 | 0;
    out[oi++] = y04 + x04 | 0;
    out[oi++] = y05 + x05 | 0;
    out[oi++] = y06 + x06 | 0;
    out[oi++] = y07 + x07 | 0;
    out[oi++] = y08 + x08 | 0;
    out[oi++] = y09 + x09 | 0;
    out[oi++] = y10 + x10 | 0;
    out[oi++] = y11 + x11 | 0;
    out[oi++] = y12 + x12 | 0;
    out[oi++] = y13 + x13 | 0;
    out[oi++] = y14 + x14 | 0;
    out[oi++] = y15 + x15 | 0;
  }
  function hchacha(s, k, i, o32) {
    let x00 = s[0], x01 = s[1], x02 = s[2], x03 = s[3], x04 = k[0], x05 = k[1], x06 = k[2], x07 = k[3], x08 = k[4], x09 = k[5], x10 = k[6], x11 = k[7], x12 = i[0], x13 = i[1], x14 = i[2], x15 = i[3];
    for (let r = 0;r < 20; r += 2) {
      x00 = x00 + x04 | 0;
      x12 = (0, _arx_js_1.rotl)(x12 ^ x00, 16);
      x08 = x08 + x12 | 0;
      x04 = (0, _arx_js_1.rotl)(x04 ^ x08, 12);
      x00 = x00 + x04 | 0;
      x12 = (0, _arx_js_1.rotl)(x12 ^ x00, 8);
      x08 = x08 + x12 | 0;
      x04 = (0, _arx_js_1.rotl)(x04 ^ x08, 7);
      x01 = x01 + x05 | 0;
      x13 = (0, _arx_js_1.rotl)(x13 ^ x01, 16);
      x09 = x09 + x13 | 0;
      x05 = (0, _arx_js_1.rotl)(x05 ^ x09, 12);
      x01 = x01 + x05 | 0;
      x13 = (0, _arx_js_1.rotl)(x13 ^ x01, 8);
      x09 = x09 + x13 | 0;
      x05 = (0, _arx_js_1.rotl)(x05 ^ x09, 7);
      x02 = x02 + x06 | 0;
      x14 = (0, _arx_js_1.rotl)(x14 ^ x02, 16);
      x10 = x10 + x14 | 0;
      x06 = (0, _arx_js_1.rotl)(x06 ^ x10, 12);
      x02 = x02 + x06 | 0;
      x14 = (0, _arx_js_1.rotl)(x14 ^ x02, 8);
      x10 = x10 + x14 | 0;
      x06 = (0, _arx_js_1.rotl)(x06 ^ x10, 7);
      x03 = x03 + x07 | 0;
      x15 = (0, _arx_js_1.rotl)(x15 ^ x03, 16);
      x11 = x11 + x15 | 0;
      x07 = (0, _arx_js_1.rotl)(x07 ^ x11, 12);
      x03 = x03 + x07 | 0;
      x15 = (0, _arx_js_1.rotl)(x15 ^ x03, 8);
      x11 = x11 + x15 | 0;
      x07 = (0, _arx_js_1.rotl)(x07 ^ x11, 7);
      x00 = x00 + x05 | 0;
      x15 = (0, _arx_js_1.rotl)(x15 ^ x00, 16);
      x10 = x10 + x15 | 0;
      x05 = (0, _arx_js_1.rotl)(x05 ^ x10, 12);
      x00 = x00 + x05 | 0;
      x15 = (0, _arx_js_1.rotl)(x15 ^ x00, 8);
      x10 = x10 + x15 | 0;
      x05 = (0, _arx_js_1.rotl)(x05 ^ x10, 7);
      x01 = x01 + x06 | 0;
      x12 = (0, _arx_js_1.rotl)(x12 ^ x01, 16);
      x11 = x11 + x12 | 0;
      x06 = (0, _arx_js_1.rotl)(x06 ^ x11, 12);
      x01 = x01 + x06 | 0;
      x12 = (0, _arx_js_1.rotl)(x12 ^ x01, 8);
      x11 = x11 + x12 | 0;
      x06 = (0, _arx_js_1.rotl)(x06 ^ x11, 7);
      x02 = x02 + x07 | 0;
      x13 = (0, _arx_js_1.rotl)(x13 ^ x02, 16);
      x08 = x08 + x13 | 0;
      x07 = (0, _arx_js_1.rotl)(x07 ^ x08, 12);
      x02 = x02 + x07 | 0;
      x13 = (0, _arx_js_1.rotl)(x13 ^ x02, 8);
      x08 = x08 + x13 | 0;
      x07 = (0, _arx_js_1.rotl)(x07 ^ x08, 7);
      x03 = x03 + x04 | 0;
      x14 = (0, _arx_js_1.rotl)(x14 ^ x03, 16);
      x09 = x09 + x14 | 0;
      x04 = (0, _arx_js_1.rotl)(x04 ^ x09, 12);
      x03 = x03 + x04 | 0;
      x14 = (0, _arx_js_1.rotl)(x14 ^ x03, 8);
      x09 = x09 + x14 | 0;
      x04 = (0, _arx_js_1.rotl)(x04 ^ x09, 7);
    }
    let oi = 0;
    o32[oi++] = x00;
    o32[oi++] = x01;
    o32[oi++] = x02;
    o32[oi++] = x03;
    o32[oi++] = x12;
    o32[oi++] = x13;
    o32[oi++] = x14;
    o32[oi++] = x15;
  }
  exports.chacha20orig = (0, _arx_js_1.createCipher)(chachaCore, {
    counterRight: false,
    counterLength: 8,
    allowShortKeys: true
  });
  exports.chacha20 = (0, _arx_js_1.createCipher)(chachaCore, {
    counterRight: false,
    counterLength: 4,
    allowShortKeys: false
  });
  exports.xchacha20 = (0, _arx_js_1.createCipher)(chachaCore, {
    counterRight: false,
    counterLength: 8,
    extendNonceFn: hchacha,
    allowShortKeys: false
  });
  exports.chacha8 = (0, _arx_js_1.createCipher)(chachaCore, {
    counterRight: false,
    counterLength: 4,
    rounds: 8
  });
  exports.chacha12 = (0, _arx_js_1.createCipher)(chachaCore, {
    counterRight: false,
    counterLength: 4,
    rounds: 12
  });
  var ZEROS16 = /* @__PURE__ */ new Uint8Array(16);
  var updatePadded = (h, msg) => {
    h.update(msg);
    const left = msg.length % 16;
    if (left)
      h.update(ZEROS16.subarray(left));
  };
  var ZEROS32 = /* @__PURE__ */ new Uint8Array(32);
  function computeTag(fn, key, nonce, data, AAD) {
    const authKey = fn(key, nonce, ZEROS32);
    const h = _poly1305_js_1.poly1305.create(authKey);
    if (AAD)
      updatePadded(h, AAD);
    updatePadded(h, data);
    const num = new Uint8Array(16);
    const view = (0, utils_js_1.createView)(num);
    (0, utils_js_1.setBigUint64)(view, 0, BigInt(AAD ? AAD.length : 0), true);
    (0, utils_js_1.setBigUint64)(view, 8, BigInt(data.length), true);
    h.update(num);
    const res = h.digest();
    (0, utils_js_1.clean)(authKey, num);
    return res;
  }
  var _poly1305_aead = (xorStream) => (key, nonce, AAD) => {
    const tagLength = 16;
    return {
      encrypt(plaintext, output) {
        const plength = plaintext.length;
        output = (0, utils_js_1.getOutput)(plength + tagLength, output, false);
        output.set(plaintext);
        const oPlain = output.subarray(0, -tagLength);
        xorStream(key, nonce, oPlain, oPlain, 1);
        const tag = computeTag(xorStream, key, nonce, oPlain, AAD);
        output.set(tag, plength);
        (0, utils_js_1.clean)(tag);
        return output;
      },
      decrypt(ciphertext, output) {
        output = (0, utils_js_1.getOutput)(ciphertext.length - tagLength, output, false);
        const data = ciphertext.subarray(0, -tagLength);
        const passedTag = ciphertext.subarray(-tagLength);
        const tag = computeTag(xorStream, key, nonce, data, AAD);
        if (!(0, utils_js_1.equalBytes)(passedTag, tag))
          throw new Error("invalid tag");
        output.set(ciphertext.subarray(0, -tagLength));
        xorStream(key, nonce, output, output, 1);
        (0, utils_js_1.clean)(tag);
        return output;
      }
    };
  };
  exports._poly1305_aead = _poly1305_aead;
  exports.chacha20poly1305 = (0, utils_js_1.wrapCipher)({ blockSize: 64, nonceLength: 12, tagLength: 16 }, (0, exports._poly1305_aead)(exports.chacha20));
  exports.xchacha20poly1305 = (0, utils_js_1.wrapCipher)({ blockSize: 64, nonceLength: 24, tagLength: 16 }, (0, exports._poly1305_aead)(exports.xchacha20));
});

// node_modules/@noble/hashes/sha3.js
var require_sha3 = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.shake256 = exports.shake128 = exports.keccak_512 = exports.keccak_384 = exports.keccak_256 = exports.keccak_224 = exports.sha3_512 = exports.sha3_384 = exports.sha3_256 = exports.sha3_224 = exports.Keccak = undefined;
  exports.keccakP = keccakP;
  var _assert_js_1 = require__assert();
  var _u64_js_1 = require__u64();
  var utils_js_1 = require_utils();
  var SHA3_PI = [];
  var SHA3_ROTL = [];
  var _SHA3_IOTA = [];
  var _0n = /* @__PURE__ */ BigInt(0);
  var _1n = /* @__PURE__ */ BigInt(1);
  var _2n = /* @__PURE__ */ BigInt(2);
  var _7n = /* @__PURE__ */ BigInt(7);
  var _256n = /* @__PURE__ */ BigInt(256);
  var _0x71n = /* @__PURE__ */ BigInt(113);
  for (let round = 0, R = _1n, x = 1, y = 0;round < 24; round++) {
    [x, y] = [y, (2 * x + 3 * y) % 5];
    SHA3_PI.push(2 * (5 * y + x));
    SHA3_ROTL.push((round + 1) * (round + 2) / 2 % 64);
    let t = _0n;
    for (let j = 0;j < 7; j++) {
      R = (R << _1n ^ (R >> _7n) * _0x71n) % _256n;
      if (R & _2n)
        t ^= _1n << (_1n << /* @__PURE__ */ BigInt(j)) - _1n;
    }
    _SHA3_IOTA.push(t);
  }
  var [SHA3_IOTA_H, SHA3_IOTA_L] = /* @__PURE__ */ (0, _u64_js_1.split)(_SHA3_IOTA, true);
  var rotlH = (h, l, s) => s > 32 ? (0, _u64_js_1.rotlBH)(h, l, s) : (0, _u64_js_1.rotlSH)(h, l, s);
  var rotlL = (h, l, s) => s > 32 ? (0, _u64_js_1.rotlBL)(h, l, s) : (0, _u64_js_1.rotlSL)(h, l, s);
  function keccakP(s, rounds = 24) {
    const B = new Uint32Array(5 * 2);
    for (let round = 24 - rounds;round < 24; round++) {
      for (let x = 0;x < 10; x++)
        B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
      for (let x = 0;x < 10; x += 2) {
        const idx1 = (x + 8) % 10;
        const idx0 = (x + 2) % 10;
        const B0 = B[idx0];
        const B1 = B[idx0 + 1];
        const Th = rotlH(B0, B1, 1) ^ B[idx1];
        const Tl = rotlL(B0, B1, 1) ^ B[idx1 + 1];
        for (let y = 0;y < 50; y += 10) {
          s[x + y] ^= Th;
          s[x + y + 1] ^= Tl;
        }
      }
      let curH = s[2];
      let curL = s[3];
      for (let t = 0;t < 24; t++) {
        const shift = SHA3_ROTL[t];
        const Th = rotlH(curH, curL, shift);
        const Tl = rotlL(curH, curL, shift);
        const PI = SHA3_PI[t];
        curH = s[PI];
        curL = s[PI + 1];
        s[PI] = Th;
        s[PI + 1] = Tl;
      }
      for (let y = 0;y < 50; y += 10) {
        for (let x = 0;x < 10; x++)
          B[x] = s[y + x];
        for (let x = 0;x < 10; x++)
          s[y + x] ^= ~B[(x + 2) % 10] & B[(x + 4) % 10];
      }
      s[0] ^= SHA3_IOTA_H[round];
      s[1] ^= SHA3_IOTA_L[round];
    }
    B.fill(0);
  }

  class Keccak extends utils_js_1.Hash {
    constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
      super();
      this.blockLen = blockLen;
      this.suffix = suffix;
      this.outputLen = outputLen;
      this.enableXOF = enableXOF;
      this.rounds = rounds;
      this.pos = 0;
      this.posOut = 0;
      this.finished = false;
      this.destroyed = false;
      (0, _assert_js_1.anumber)(outputLen);
      if (0 >= this.blockLen || this.blockLen >= 200)
        throw new Error("Sha3 supports only keccak-f1600 function");
      this.state = new Uint8Array(200);
      this.state32 = (0, utils_js_1.u32)(this.state);
    }
    keccak() {
      if (!utils_js_1.isLE)
        (0, utils_js_1.byteSwap32)(this.state32);
      keccakP(this.state32, this.rounds);
      if (!utils_js_1.isLE)
        (0, utils_js_1.byteSwap32)(this.state32);
      this.posOut = 0;
      this.pos = 0;
    }
    update(data) {
      (0, _assert_js_1.aexists)(this);
      const { blockLen, state } = this;
      data = (0, utils_js_1.toBytes)(data);
      const len = data.length;
      for (let pos = 0;pos < len; ) {
        const take = Math.min(blockLen - this.pos, len - pos);
        for (let i = 0;i < take; i++)
          state[this.pos++] ^= data[pos++];
        if (this.pos === blockLen)
          this.keccak();
      }
      return this;
    }
    finish() {
      if (this.finished)
        return;
      this.finished = true;
      const { state, suffix, pos, blockLen } = this;
      state[pos] ^= suffix;
      if ((suffix & 128) !== 0 && pos === blockLen - 1)
        this.keccak();
      state[blockLen - 1] ^= 128;
      this.keccak();
    }
    writeInto(out) {
      (0, _assert_js_1.aexists)(this, false);
      (0, _assert_js_1.abytes)(out);
      this.finish();
      const bufferOut = this.state;
      const { blockLen } = this;
      for (let pos = 0, len = out.length;pos < len; ) {
        if (this.posOut >= blockLen)
          this.keccak();
        const take = Math.min(blockLen - this.posOut, len - pos);
        out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
        this.posOut += take;
        pos += take;
      }
      return out;
    }
    xofInto(out) {
      if (!this.enableXOF)
        throw new Error("XOF is not possible for this instance");
      return this.writeInto(out);
    }
    xof(bytes) {
      (0, _assert_js_1.anumber)(bytes);
      return this.xofInto(new Uint8Array(bytes));
    }
    digestInto(out) {
      (0, _assert_js_1.aoutput)(out, this);
      if (this.finished)
        throw new Error("digest() was already called");
      this.writeInto(out);
      this.destroy();
      return out;
    }
    digest() {
      return this.digestInto(new Uint8Array(this.outputLen));
    }
    destroy() {
      this.destroyed = true;
      this.state.fill(0);
    }
    _cloneInto(to) {
      const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
      to || (to = new Keccak(blockLen, suffix, outputLen, enableXOF, rounds));
      to.state32.set(this.state32);
      to.pos = this.pos;
      to.posOut = this.posOut;
      to.finished = this.finished;
      to.rounds = rounds;
      to.suffix = suffix;
      to.outputLen = outputLen;
      to.enableXOF = enableXOF;
      to.destroyed = this.destroyed;
      return to;
    }
  }
  exports.Keccak = Keccak;
  var gen = (suffix, blockLen, outputLen) => (0, utils_js_1.wrapConstructor)(() => new Keccak(blockLen, suffix, outputLen));
  exports.sha3_224 = gen(6, 144, 224 / 8);
  exports.sha3_256 = gen(6, 136, 256 / 8);
  exports.sha3_384 = gen(6, 104, 384 / 8);
  exports.sha3_512 = gen(6, 72, 512 / 8);
  exports.keccak_224 = gen(1, 144, 224 / 8);
  exports.keccak_256 = gen(1, 136, 256 / 8);
  exports.keccak_384 = gen(1, 104, 384 / 8);
  exports.keccak_512 = gen(1, 72, 512 / 8);
  var genShake = (suffix, blockLen, outputLen) => (0, utils_js_1.wrapXOFConstructorWithOpts)((opts = {}) => new Keccak(blockLen, suffix, opts.dkLen === undefined ? outputLen : opts.dkLen, true));
  exports.shake128 = genShake(31, 168, 128 / 8);
  exports.shake256 = genShake(31, 136, 256 / 8);
});

// node_modules/@noble/hashes/_md.js
var require__md = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.HashMD = undefined;
  exports.setBigUint64 = setBigUint64;
  exports.Chi = Chi;
  exports.Maj = Maj;
  var _assert_js_1 = require__assert();
  var utils_js_1 = require_utils();
  function setBigUint64(view, byteOffset, value, isLE) {
    if (typeof view.setBigUint64 === "function")
      return view.setBigUint64(byteOffset, value, isLE);
    const _32n = BigInt(32);
    const _u32_max = BigInt(4294967295);
    const wh = Number(value >> _32n & _u32_max);
    const wl = Number(value & _u32_max);
    const h = isLE ? 4 : 0;
    const l = isLE ? 0 : 4;
    view.setUint32(byteOffset + h, wh, isLE);
    view.setUint32(byteOffset + l, wl, isLE);
  }
  function Chi(a, b, c) {
    return a & b ^ ~a & c;
  }
  function Maj(a, b, c) {
    return a & b ^ a & c ^ b & c;
  }

  class HashMD extends utils_js_1.Hash {
    constructor(blockLen, outputLen, padOffset, isLE) {
      super();
      this.blockLen = blockLen;
      this.outputLen = outputLen;
      this.padOffset = padOffset;
      this.isLE = isLE;
      this.finished = false;
      this.length = 0;
      this.pos = 0;
      this.destroyed = false;
      this.buffer = new Uint8Array(blockLen);
      this.view = (0, utils_js_1.createView)(this.buffer);
    }
    update(data) {
      (0, _assert_js_1.aexists)(this);
      const { view, buffer, blockLen } = this;
      data = (0, utils_js_1.toBytes)(data);
      const len = data.length;
      for (let pos = 0;pos < len; ) {
        const take = Math.min(blockLen - this.pos, len - pos);
        if (take === blockLen) {
          const dataView = (0, utils_js_1.createView)(data);
          for (;blockLen <= len - pos; pos += blockLen)
            this.process(dataView, pos);
          continue;
        }
        buffer.set(data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        pos += take;
        if (this.pos === blockLen) {
          this.process(view, 0);
          this.pos = 0;
        }
      }
      this.length += data.length;
      this.roundClean();
      return this;
    }
    digestInto(out) {
      (0, _assert_js_1.aexists)(this);
      (0, _assert_js_1.aoutput)(out, this);
      this.finished = true;
      const { buffer, view, blockLen, isLE } = this;
      let { pos } = this;
      buffer[pos++] = 128;
      this.buffer.subarray(pos).fill(0);
      if (this.padOffset > blockLen - pos) {
        this.process(view, 0);
        pos = 0;
      }
      for (let i = pos;i < blockLen; i++)
        buffer[i] = 0;
      setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE);
      this.process(view, 0);
      const oview = (0, utils_js_1.createView)(out);
      const len = this.outputLen;
      if (len % 4)
        throw new Error("_sha2: outputLen should be aligned to 32bit");
      const outLen = len / 4;
      const state = this.get();
      if (outLen > state.length)
        throw new Error("_sha2: outputLen bigger than state");
      for (let i = 0;i < outLen; i++)
        oview.setUint32(4 * i, state[i], isLE);
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
    _cloneInto(to) {
      to || (to = new this.constructor);
      to.set(...this.get());
      const { blockLen, buffer, length, finished, destroyed, pos } = this;
      to.length = length;
      to.pos = pos;
      to.finished = finished;
      to.destroyed = destroyed;
      if (length % blockLen)
        to.buffer.set(buffer);
      return to;
    }
  }
  exports.HashMD = HashMD;
});

// node_modules/@noble/hashes/sha256.js
var require_sha256 = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.sha224 = exports.sha256 = exports.SHA256 = undefined;
  var _md_js_1 = require__md();
  var utils_js_1 = require_utils();
  var SHA256_K = /* @__PURE__ */ new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  var SHA256_IV = /* @__PURE__ */ new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);
  var SHA256_W = /* @__PURE__ */ new Uint32Array(64);

  class SHA256 extends _md_js_1.HashMD {
    constructor() {
      super(64, 32, 8, false);
      this.A = SHA256_IV[0] | 0;
      this.B = SHA256_IV[1] | 0;
      this.C = SHA256_IV[2] | 0;
      this.D = SHA256_IV[3] | 0;
      this.E = SHA256_IV[4] | 0;
      this.F = SHA256_IV[5] | 0;
      this.G = SHA256_IV[6] | 0;
      this.H = SHA256_IV[7] | 0;
    }
    get() {
      const { A, B, C, D, E, F, G, H } = this;
      return [A, B, C, D, E, F, G, H];
    }
    set(A, B, C, D, E, F, G, H) {
      this.A = A | 0;
      this.B = B | 0;
      this.C = C | 0;
      this.D = D | 0;
      this.E = E | 0;
      this.F = F | 0;
      this.G = G | 0;
      this.H = H | 0;
    }
    process(view, offset) {
      for (let i = 0;i < 16; i++, offset += 4)
        SHA256_W[i] = view.getUint32(offset, false);
      for (let i = 16;i < 64; i++) {
        const W15 = SHA256_W[i - 15];
        const W2 = SHA256_W[i - 2];
        const s0 = (0, utils_js_1.rotr)(W15, 7) ^ (0, utils_js_1.rotr)(W15, 18) ^ W15 >>> 3;
        const s1 = (0, utils_js_1.rotr)(W2, 17) ^ (0, utils_js_1.rotr)(W2, 19) ^ W2 >>> 10;
        SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
      }
      let { A, B, C, D, E, F, G, H } = this;
      for (let i = 0;i < 64; i++) {
        const sigma1 = (0, utils_js_1.rotr)(E, 6) ^ (0, utils_js_1.rotr)(E, 11) ^ (0, utils_js_1.rotr)(E, 25);
        const T1 = H + sigma1 + (0, _md_js_1.Chi)(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
        const sigma0 = (0, utils_js_1.rotr)(A, 2) ^ (0, utils_js_1.rotr)(A, 13) ^ (0, utils_js_1.rotr)(A, 22);
        const T2 = sigma0 + (0, _md_js_1.Maj)(A, B, C) | 0;
        H = G;
        G = F;
        F = E;
        E = D + T1 | 0;
        D = C;
        C = B;
        B = A;
        A = T1 + T2 | 0;
      }
      A = A + this.A | 0;
      B = B + this.B | 0;
      C = C + this.C | 0;
      D = D + this.D | 0;
      E = E + this.E | 0;
      F = F + this.F | 0;
      G = G + this.G | 0;
      H = H + this.H | 0;
      this.set(A, B, C, D, E, F, G, H);
    }
    roundClean() {
      SHA256_W.fill(0);
    }
    destroy() {
      this.set(0, 0, 0, 0, 0, 0, 0, 0);
      this.buffer.fill(0);
    }
  }
  exports.SHA256 = SHA256;

  class SHA224 extends SHA256 {
    constructor() {
      super();
      this.A = 3238371032 | 0;
      this.B = 914150663 | 0;
      this.C = 812702999 | 0;
      this.D = 4144912697 | 0;
      this.E = 4290775857 | 0;
      this.F = 1750603025 | 0;
      this.G = 1694076839 | 0;
      this.H = 3204075428 | 0;
      this.outputLen = 28;
    }
  }
  exports.sha256 = (0, utils_js_1.wrapConstructor)(() => new SHA256);
  exports.sha224 = (0, utils_js_1.wrapConstructor)(() => new SHA224);
});

// node_modules/@noble/hashes/sha512.js
var require_sha512 = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.sha384 = exports.sha512_256 = exports.sha512_224 = exports.sha512 = exports.SHA384 = exports.SHA512_256 = exports.SHA512_224 = exports.SHA512 = undefined;
  var _md_js_1 = require__md();
  var _u64_js_1 = require__u64();
  var utils_js_1 = require_utils();
  var [SHA512_Kh, SHA512_Kl] = /* @__PURE__ */ (() => _u64_js_1.default.split([
    "0x428a2f98d728ae22",
    "0x7137449123ef65cd",
    "0xb5c0fbcfec4d3b2f",
    "0xe9b5dba58189dbbc",
    "0x3956c25bf348b538",
    "0x59f111f1b605d019",
    "0x923f82a4af194f9b",
    "0xab1c5ed5da6d8118",
    "0xd807aa98a3030242",
    "0x12835b0145706fbe",
    "0x243185be4ee4b28c",
    "0x550c7dc3d5ffb4e2",
    "0x72be5d74f27b896f",
    "0x80deb1fe3b1696b1",
    "0x9bdc06a725c71235",
    "0xc19bf174cf692694",
    "0xe49b69c19ef14ad2",
    "0xefbe4786384f25e3",
    "0x0fc19dc68b8cd5b5",
    "0x240ca1cc77ac9c65",
    "0x2de92c6f592b0275",
    "0x4a7484aa6ea6e483",
    "0x5cb0a9dcbd41fbd4",
    "0x76f988da831153b5",
    "0x983e5152ee66dfab",
    "0xa831c66d2db43210",
    "0xb00327c898fb213f",
    "0xbf597fc7beef0ee4",
    "0xc6e00bf33da88fc2",
    "0xd5a79147930aa725",
    "0x06ca6351e003826f",
    "0x142929670a0e6e70",
    "0x27b70a8546d22ffc",
    "0x2e1b21385c26c926",
    "0x4d2c6dfc5ac42aed",
    "0x53380d139d95b3df",
    "0x650a73548baf63de",
    "0x766a0abb3c77b2a8",
    "0x81c2c92e47edaee6",
    "0x92722c851482353b",
    "0xa2bfe8a14cf10364",
    "0xa81a664bbc423001",
    "0xc24b8b70d0f89791",
    "0xc76c51a30654be30",
    "0xd192e819d6ef5218",
    "0xd69906245565a910",
    "0xf40e35855771202a",
    "0x106aa07032bbd1b8",
    "0x19a4c116b8d2d0c8",
    "0x1e376c085141ab53",
    "0x2748774cdf8eeb99",
    "0x34b0bcb5e19b48a8",
    "0x391c0cb3c5c95a63",
    "0x4ed8aa4ae3418acb",
    "0x5b9cca4f7763e373",
    "0x682e6ff3d6b2b8a3",
    "0x748f82ee5defb2fc",
    "0x78a5636f43172f60",
    "0x84c87814a1f0ab72",
    "0x8cc702081a6439ec",
    "0x90befffa23631e28",
    "0xa4506cebde82bde9",
    "0xbef9a3f7b2c67915",
    "0xc67178f2e372532b",
    "0xca273eceea26619c",
    "0xd186b8c721c0c207",
    "0xeada7dd6cde0eb1e",
    "0xf57d4f7fee6ed178",
    "0x06f067aa72176fba",
    "0x0a637dc5a2c898a6",
    "0x113f9804bef90dae",
    "0x1b710b35131c471b",
    "0x28db77f523047d84",
    "0x32caab7b40c72493",
    "0x3c9ebe0a15c9bebc",
    "0x431d67c49c100d4c",
    "0x4cc5d4becb3e42b6",
    "0x597f299cfc657e2a",
    "0x5fcb6fab3ad6faec",
    "0x6c44198c4a475817"
  ].map((n) => BigInt(n))))();
  var SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
  var SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);

  class SHA512 extends _md_js_1.HashMD {
    constructor() {
      super(128, 64, 16, false);
      this.Ah = 1779033703 | 0;
      this.Al = 4089235720 | 0;
      this.Bh = 3144134277 | 0;
      this.Bl = 2227873595 | 0;
      this.Ch = 1013904242 | 0;
      this.Cl = 4271175723 | 0;
      this.Dh = 2773480762 | 0;
      this.Dl = 1595750129 | 0;
      this.Eh = 1359893119 | 0;
      this.El = 2917565137 | 0;
      this.Fh = 2600822924 | 0;
      this.Fl = 725511199 | 0;
      this.Gh = 528734635 | 0;
      this.Gl = 4215389547 | 0;
      this.Hh = 1541459225 | 0;
      this.Hl = 327033209 | 0;
    }
    get() {
      const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
      return [Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl];
    }
    set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
      this.Ah = Ah | 0;
      this.Al = Al | 0;
      this.Bh = Bh | 0;
      this.Bl = Bl | 0;
      this.Ch = Ch | 0;
      this.Cl = Cl | 0;
      this.Dh = Dh | 0;
      this.Dl = Dl | 0;
      this.Eh = Eh | 0;
      this.El = El | 0;
      this.Fh = Fh | 0;
      this.Fl = Fl | 0;
      this.Gh = Gh | 0;
      this.Gl = Gl | 0;
      this.Hh = Hh | 0;
      this.Hl = Hl | 0;
    }
    process(view, offset) {
      for (let i = 0;i < 16; i++, offset += 4) {
        SHA512_W_H[i] = view.getUint32(offset);
        SHA512_W_L[i] = view.getUint32(offset += 4);
      }
      for (let i = 16;i < 80; i++) {
        const W15h = SHA512_W_H[i - 15] | 0;
        const W15l = SHA512_W_L[i - 15] | 0;
        const s0h = _u64_js_1.default.rotrSH(W15h, W15l, 1) ^ _u64_js_1.default.rotrSH(W15h, W15l, 8) ^ _u64_js_1.default.shrSH(W15h, W15l, 7);
        const s0l = _u64_js_1.default.rotrSL(W15h, W15l, 1) ^ _u64_js_1.default.rotrSL(W15h, W15l, 8) ^ _u64_js_1.default.shrSL(W15h, W15l, 7);
        const W2h = SHA512_W_H[i - 2] | 0;
        const W2l = SHA512_W_L[i - 2] | 0;
        const s1h = _u64_js_1.default.rotrSH(W2h, W2l, 19) ^ _u64_js_1.default.rotrBH(W2h, W2l, 61) ^ _u64_js_1.default.shrSH(W2h, W2l, 6);
        const s1l = _u64_js_1.default.rotrSL(W2h, W2l, 19) ^ _u64_js_1.default.rotrBL(W2h, W2l, 61) ^ _u64_js_1.default.shrSL(W2h, W2l, 6);
        const SUMl = _u64_js_1.default.add4L(s0l, s1l, SHA512_W_L[i - 7], SHA512_W_L[i - 16]);
        const SUMh = _u64_js_1.default.add4H(SUMl, s0h, s1h, SHA512_W_H[i - 7], SHA512_W_H[i - 16]);
        SHA512_W_H[i] = SUMh | 0;
        SHA512_W_L[i] = SUMl | 0;
      }
      let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
      for (let i = 0;i < 80; i++) {
        const sigma1h = _u64_js_1.default.rotrSH(Eh, El, 14) ^ _u64_js_1.default.rotrSH(Eh, El, 18) ^ _u64_js_1.default.rotrBH(Eh, El, 41);
        const sigma1l = _u64_js_1.default.rotrSL(Eh, El, 14) ^ _u64_js_1.default.rotrSL(Eh, El, 18) ^ _u64_js_1.default.rotrBL(Eh, El, 41);
        const CHIh = Eh & Fh ^ ~Eh & Gh;
        const CHIl = El & Fl ^ ~El & Gl;
        const T1ll = _u64_js_1.default.add5L(Hl, sigma1l, CHIl, SHA512_Kl[i], SHA512_W_L[i]);
        const T1h = _u64_js_1.default.add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i], SHA512_W_H[i]);
        const T1l = T1ll | 0;
        const sigma0h = _u64_js_1.default.rotrSH(Ah, Al, 28) ^ _u64_js_1.default.rotrBH(Ah, Al, 34) ^ _u64_js_1.default.rotrBH(Ah, Al, 39);
        const sigma0l = _u64_js_1.default.rotrSL(Ah, Al, 28) ^ _u64_js_1.default.rotrBL(Ah, Al, 34) ^ _u64_js_1.default.rotrBL(Ah, Al, 39);
        const MAJh = Ah & Bh ^ Ah & Ch ^ Bh & Ch;
        const MAJl = Al & Bl ^ Al & Cl ^ Bl & Cl;
        Hh = Gh | 0;
        Hl = Gl | 0;
        Gh = Fh | 0;
        Gl = Fl | 0;
        Fh = Eh | 0;
        Fl = El | 0;
        ({ h: Eh, l: El } = _u64_js_1.default.add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
        Dh = Ch | 0;
        Dl = Cl | 0;
        Ch = Bh | 0;
        Cl = Bl | 0;
        Bh = Ah | 0;
        Bl = Al | 0;
        const All = _u64_js_1.default.add3L(T1l, sigma0l, MAJl);
        Ah = _u64_js_1.default.add3H(All, T1h, sigma0h, MAJh);
        Al = All | 0;
      }
      ({ h: Ah, l: Al } = _u64_js_1.default.add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
      ({ h: Bh, l: Bl } = _u64_js_1.default.add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
      ({ h: Ch, l: Cl } = _u64_js_1.default.add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
      ({ h: Dh, l: Dl } = _u64_js_1.default.add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
      ({ h: Eh, l: El } = _u64_js_1.default.add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
      ({ h: Fh, l: Fl } = _u64_js_1.default.add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
      ({ h: Gh, l: Gl } = _u64_js_1.default.add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
      ({ h: Hh, l: Hl } = _u64_js_1.default.add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
      this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
    }
    roundClean() {
      SHA512_W_H.fill(0);
      SHA512_W_L.fill(0);
    }
    destroy() {
      this.buffer.fill(0);
      this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
  }
  exports.SHA512 = SHA512;

  class SHA512_224 extends SHA512 {
    constructor() {
      super();
      this.Ah = 2352822216 | 0;
      this.Al = 424955298 | 0;
      this.Bh = 1944164710 | 0;
      this.Bl = 2312950998 | 0;
      this.Ch = 502970286 | 0;
      this.Cl = 855612546 | 0;
      this.Dh = 1738396948 | 0;
      this.Dl = 1479516111 | 0;
      this.Eh = 258812777 | 0;
      this.El = 2077511080 | 0;
      this.Fh = 2011393907 | 0;
      this.Fl = 79989058 | 0;
      this.Gh = 1067287976 | 0;
      this.Gl = 1780299464 | 0;
      this.Hh = 286451373 | 0;
      this.Hl = 2446758561 | 0;
      this.outputLen = 28;
    }
  }
  exports.SHA512_224 = SHA512_224;

  class SHA512_256 extends SHA512 {
    constructor() {
      super();
      this.Ah = 573645204 | 0;
      this.Al = 4230739756 | 0;
      this.Bh = 2673172387 | 0;
      this.Bl = 3360449730 | 0;
      this.Ch = 596883563 | 0;
      this.Cl = 1867755857 | 0;
      this.Dh = 2520282905 | 0;
      this.Dl = 1497426621 | 0;
      this.Eh = 2519219938 | 0;
      this.El = 2827943907 | 0;
      this.Fh = 3193839141 | 0;
      this.Fl = 1401305490 | 0;
      this.Gh = 721525244 | 0;
      this.Gl = 746961066 | 0;
      this.Hh = 246885852 | 0;
      this.Hl = 2177182882 | 0;
      this.outputLen = 32;
    }
  }
  exports.SHA512_256 = SHA512_256;

  class SHA384 extends SHA512 {
    constructor() {
      super();
      this.Ah = 3418070365 | 0;
      this.Al = 3238371032 | 0;
      this.Bh = 1654270250 | 0;
      this.Bl = 914150663 | 0;
      this.Ch = 2438529370 | 0;
      this.Cl = 812702999 | 0;
      this.Dh = 355462360 | 0;
      this.Dl = 4144912697 | 0;
      this.Eh = 1731405415 | 0;
      this.El = 4290775857 | 0;
      this.Fh = 2394180231 | 0;
      this.Fl = 1750603025 | 0;
      this.Gh = 3675008525 | 0;
      this.Gl = 1694076839 | 0;
      this.Hh = 1203062813 | 0;
      this.Hl = 3204075428 | 0;
      this.outputLen = 48;
    }
  }
  exports.SHA384 = SHA384;
  exports.sha512 = (0, utils_js_1.wrapConstructor)(() => new SHA512);
  exports.sha512_224 = (0, utils_js_1.wrapConstructor)(() => new SHA512_224);
  exports.sha512_256 = (0, utils_js_1.wrapConstructor)(() => new SHA512_256);
  exports.sha384 = (0, utils_js_1.wrapConstructor)(() => new SHA384);
});

// node_modules/@noble/post-quantum/utils.js
var require_utils3 = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.EMPTY = exports.utf8ToBytes = exports.concatBytes = exports.randomBytes = exports.ensureBytes = undefined;
  exports.equalBytes = equalBytes;
  exports.splitCoder = splitCoder;
  exports.vecCoder = vecCoder;
  exports.cleanBytes = cleanBytes;
  exports.getMask = getMask;
  exports.getMessage = getMessage;
  exports.getMessagePrehash = getMessagePrehash;
  /*! noble-post-quantum - MIT License (c) 2024 Paul Miller (paulmillr.com) */
  var _assert_1 = require__assert();
  var sha256_1 = require_sha256();
  var sha3_1 = require_sha3();
  var sha512_1 = require_sha512();
  var utils_1 = require_utils();
  Object.defineProperty(exports, "concatBytes", { enumerable: true, get: function() {
    return utils_1.concatBytes;
  } });
  Object.defineProperty(exports, "utf8ToBytes", { enumerable: true, get: function() {
    return utils_1.utf8ToBytes;
  } });
  exports.ensureBytes = _assert_1.abytes;
  exports.randomBytes = utils_1.randomBytes;
  function equalBytes(a, b) {
    if (a.length !== b.length)
      return false;
    let diff = 0;
    for (let i = 0;i < a.length; i++)
      diff |= a[i] ^ b[i];
    return diff === 0;
  }
  function splitCoder(...lengths) {
    const getLength = (c) => typeof c === "number" ? c : c.bytesLen;
    const bytesLen = lengths.reduce((sum, a) => sum + getLength(a), 0);
    return {
      bytesLen,
      encode: (bufs) => {
        const res = new Uint8Array(bytesLen);
        for (let i = 0, pos = 0;i < lengths.length; i++) {
          const c = lengths[i];
          const l = getLength(c);
          const b = typeof c === "number" ? bufs[i] : c.encode(bufs[i]);
          (0, exports.ensureBytes)(b, l);
          res.set(b, pos);
          if (typeof c !== "number")
            b.fill(0);
          pos += l;
        }
        return res;
      },
      decode: (buf) => {
        (0, exports.ensureBytes)(buf, bytesLen);
        const res = [];
        for (const c of lengths) {
          const l = getLength(c);
          const b = buf.subarray(0, l);
          res.push(typeof c === "number" ? b : c.decode(b));
          buf = buf.subarray(l);
        }
        return res;
      }
    };
  }
  function vecCoder(c, vecLen) {
    const bytesLen = vecLen * c.bytesLen;
    return {
      bytesLen,
      encode: (u) => {
        if (u.length !== vecLen)
          throw new Error(`vecCoder.encode: wrong length=${u.length}. Expected: ${vecLen}`);
        const res = new Uint8Array(bytesLen);
        for (let i = 0, pos = 0;i < u.length; i++) {
          const b = c.encode(u[i]);
          res.set(b, pos);
          b.fill(0);
          pos += b.length;
        }
        return res;
      },
      decode: (a) => {
        (0, exports.ensureBytes)(a, bytesLen);
        const r = [];
        for (let i = 0;i < a.length; i += c.bytesLen)
          r.push(c.decode(a.subarray(i, i + c.bytesLen)));
        return r;
      }
    };
  }
  function cleanBytes(...list) {
    for (const t of list) {
      if (Array.isArray(t))
        for (const b of t)
          b.fill(0);
      else
        t.fill(0);
    }
  }
  function getMask(bits) {
    return (1 << bits) - 1;
  }
  exports.EMPTY = new Uint8Array(0);
  function getMessage(msg, ctx = exports.EMPTY) {
    (0, exports.ensureBytes)(msg);
    (0, exports.ensureBytes)(ctx);
    if (ctx.length > 255)
      throw new Error("context should be less than 255 bytes");
    return (0, utils_1.concatBytes)(new Uint8Array([0, ctx.length]), ctx, msg);
  }
  var HASHES = {
    "SHA2-256": { oid: (0, utils_1.hexToBytes)("0609608648016503040201"), hash: sha256_1.sha256 },
    "SHA2-384": { oid: (0, utils_1.hexToBytes)("0609608648016503040202"), hash: sha512_1.sha384 },
    "SHA2-512": { oid: (0, utils_1.hexToBytes)("0609608648016503040203"), hash: sha512_1.sha512 },
    "SHA2-224": { oid: (0, utils_1.hexToBytes)("0609608648016503040204"), hash: sha256_1.sha224 },
    "SHA2-512/224": { oid: (0, utils_1.hexToBytes)("0609608648016503040205"), hash: sha512_1.sha512_224 },
    "SHA2-512/256": { oid: (0, utils_1.hexToBytes)("0609608648016503040206"), hash: sha512_1.sha512_256 },
    "SHA3-224": { oid: (0, utils_1.hexToBytes)("0609608648016503040207"), hash: sha3_1.sha3_224 },
    "SHA3-256": { oid: (0, utils_1.hexToBytes)("0609608648016503040208"), hash: sha3_1.sha3_256 },
    "SHA3-384": { oid: (0, utils_1.hexToBytes)("0609608648016503040209"), hash: sha3_1.sha3_384 },
    "SHA3-512": { oid: (0, utils_1.hexToBytes)("060960864801650304020A"), hash: sha3_1.sha3_512 },
    "SHAKE-128": {
      oid: (0, utils_1.hexToBytes)("060960864801650304020B"),
      hash: (msg) => (0, sha3_1.shake128)(msg, { dkLen: 32 })
    },
    "SHAKE-256": {
      oid: (0, utils_1.hexToBytes)("060960864801650304020C"),
      hash: (msg) => (0, sha3_1.shake256)(msg, { dkLen: 64 })
    }
  };
  function getMessagePrehash(hashName, msg, ctx = exports.EMPTY) {
    (0, exports.ensureBytes)(msg);
    (0, exports.ensureBytes)(ctx);
    if (ctx.length > 255)
      throw new Error("context should be less than 255 bytes");
    if (!HASHES[hashName])
      throw new Error("unknown hash: " + hashName);
    const { oid, hash } = HASHES[hashName];
    const hashed = hash(msg);
    return (0, utils_1.concatBytes)(new Uint8Array([1, ctx.length]), ctx, oid, hashed);
  }
});

// node_modules/@noble/post-quantum/_crystals.js
var require__crystals = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.XOF256 = exports.XOF128 = exports.genCrystals = undefined;
  /*! noble-post-quantum - MIT License (c) 2024 Paul Miller (paulmillr.com) */
  var sha3_1 = require_sha3();
  var utils_js_1 = require_utils3();
  function bitReversal(n, bits = 8) {
    const padded = n.toString(2).padStart(8, "0");
    const sliced = padded.slice(-bits).padStart(7, "0");
    const revrsd = sliced.split("").reverse().join("");
    return Number.parseInt(revrsd, 2);
  }
  var genCrystals = (opts) => {
    const { newPoly, N, Q, F, ROOT_OF_UNITY, brvBits, isKyber } = opts;
    const mod = (a, modulo = Q) => {
      const result = a % modulo | 0;
      return (result >= 0 ? result | 0 : modulo + result | 0) | 0;
    };
    const smod = (a, modulo = Q) => {
      const r = mod(a, modulo) | 0;
      return (r > modulo >> 1 ? r - modulo | 0 : r) | 0;
    };
    function getZettas() {
      const out = newPoly(N);
      for (let i = 0;i < N; i++) {
        const b = bitReversal(i, brvBits);
        const p = BigInt(ROOT_OF_UNITY) ** BigInt(b) % BigInt(Q);
        out[i] = Number(p) | 0;
      }
      return out;
    }
    const nttZetas = getZettas();
    const LEN1 = isKyber ? 128 : N;
    const LEN2 = isKyber ? 1 : 0;
    const NTT = {
      encode: (r) => {
        for (let k = 1, len = 128;len > LEN2; len >>= 1) {
          for (let start = 0;start < N; start += 2 * len) {
            const zeta = nttZetas[k++];
            for (let j = start;j < start + len; j++) {
              const t = mod(zeta * r[j + len]);
              r[j + len] = mod(r[j] - t) | 0;
              r[j] = mod(r[j] + t) | 0;
            }
          }
        }
        return r;
      },
      decode: (r) => {
        for (let k = LEN1 - 1, len = 1 + LEN2;len < LEN1 + LEN2; len <<= 1) {
          for (let start = 0;start < N; start += 2 * len) {
            const zeta = nttZetas[k--];
            for (let j = start;j < start + len; j++) {
              const t = r[j];
              r[j] = mod(t + r[j + len]);
              r[j + len] = mod(zeta * (r[j + len] - t));
            }
          }
        }
        for (let i = 0;i < r.length; i++)
          r[i] = mod(F * r[i]);
        return r;
      }
    };
    const bitsCoder = (d, c) => {
      const mask = (0, utils_js_1.getMask)(d);
      const bytesLen = d * (N / 8);
      return {
        bytesLen,
        encode: (poly) => {
          const r = new Uint8Array(bytesLen);
          for (let i = 0, buf = 0, bufLen = 0, pos = 0;i < poly.length; i++) {
            buf |= (c.encode(poly[i]) & mask) << bufLen;
            bufLen += d;
            for (;bufLen >= 8; bufLen -= 8, buf >>= 8)
              r[pos++] = buf & (0, utils_js_1.getMask)(bufLen);
          }
          return r;
        },
        decode: (bytes) => {
          const r = newPoly(N);
          for (let i = 0, buf = 0, bufLen = 0, pos = 0;i < bytes.length; i++) {
            buf |= bytes[i] << bufLen;
            bufLen += 8;
            for (;bufLen >= d; bufLen -= d, buf >>= d)
              r[pos++] = c.decode(buf & mask);
          }
          return r;
        }
      };
    };
    return { mod, smod, nttZetas, NTT, bitsCoder };
  };
  exports.genCrystals = genCrystals;
  var createXofShake = (shake) => (seed, blockLen) => {
    if (!blockLen)
      blockLen = shake.blockLen;
    const _seed = new Uint8Array(seed.length + 2);
    _seed.set(seed);
    const seedLen = seed.length;
    const buf = new Uint8Array(blockLen);
    let h = shake.create({});
    let calls = 0;
    let xofs = 0;
    return {
      stats: () => ({ calls, xofs }),
      get: (x, y) => {
        _seed[seedLen + 0] = x;
        _seed[seedLen + 1] = y;
        h.destroy();
        h = shake.create({}).update(_seed);
        calls++;
        return () => {
          xofs++;
          return h.xofInto(buf);
        };
      },
      clean: () => {
        h.destroy();
        buf.fill(0);
        _seed.fill(0);
      }
    };
  };
  exports.XOF128 = createXofShake(sha3_1.shake128);
  exports.XOF256 = createXofShake(sha3_1.shake256);
});

// node_modules/@noble/post-quantum/ml-kem.js
var require_ml_kem = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.ml_kem1024 = exports.ml_kem768 = exports.ml_kem512 = exports.PARAMS = undefined;
  /*! noble-post-quantum - MIT License (c) 2024 Paul Miller (paulmillr.com) */
  var sha3_1 = require_sha3();
  var utils_1 = require_utils();
  var _crystals_js_1 = require__crystals();
  var utils_js_1 = require_utils3();
  var N = 256;
  var Q = 3329;
  var F = 3303;
  var ROOT_OF_UNITY = 17;
  var { mod, nttZetas, NTT, bitsCoder } = (0, _crystals_js_1.genCrystals)({
    N,
    Q,
    F,
    ROOT_OF_UNITY,
    newPoly: (n) => new Uint16Array(n),
    brvBits: 7,
    isKyber: true
  });
  exports.PARAMS = {
    512: { N, Q, K: 2, ETA1: 3, ETA2: 2, du: 10, dv: 4, RBGstrength: 128 },
    768: { N, Q, K: 3, ETA1: 2, ETA2: 2, du: 10, dv: 4, RBGstrength: 192 },
    1024: { N, Q, K: 4, ETA1: 2, ETA2: 2, du: 11, dv: 5, RBGstrength: 256 }
  };
  var compress = (d) => {
    if (d >= 12)
      return { encode: (i) => i, decode: (i) => i };
    const a = 2 ** (d - 1);
    return {
      encode: (i) => ((i << d) + Q / 2) / Q,
      decode: (i) => i * Q + a >>> d
    };
  };
  var polyCoder = (d) => bitsCoder(d, compress(d));
  function polyAdd(a, b) {
    for (let i = 0;i < N; i++)
      a[i] = mod(a[i] + b[i]);
  }
  function polySub(a, b) {
    for (let i = 0;i < N; i++)
      a[i] = mod(a[i] - b[i]);
  }
  function BaseCaseMultiply(a0, a1, b0, b1, zeta) {
    const c0 = mod(a1 * b1 * zeta + a0 * b0);
    const c1 = mod(a0 * b1 + a1 * b0);
    return { c0, c1 };
  }
  function MultiplyNTTs(f, g) {
    for (let i = 0;i < N / 2; i++) {
      let z = nttZetas[64 + (i >> 1)];
      if (i & 1)
        z = -z;
      const { c0, c1 } = BaseCaseMultiply(f[2 * i + 0], f[2 * i + 1], g[2 * i + 0], g[2 * i + 1], z);
      f[2 * i + 0] = c0;
      f[2 * i + 1] = c1;
    }
    return f;
  }
  function SampleNTT(xof) {
    const r = new Uint16Array(N);
    for (let j = 0;j < N; ) {
      const b = xof();
      if (b.length % 3)
        throw new Error("SampleNTT: unaligned block");
      for (let i = 0;j < N && i + 3 <= b.length; i += 3) {
        const d1 = (b[i + 0] >> 0 | b[i + 1] << 8) & 4095;
        const d2 = (b[i + 1] >> 4 | b[i + 2] << 4) & 4095;
        if (d1 < Q)
          r[j++] = d1;
        if (j < N && d2 < Q)
          r[j++] = d2;
      }
    }
    return r;
  }
  function sampleCBD(PRF, seed, nonce, eta) {
    const buf = PRF(eta * N / 4, seed, nonce);
    const r = new Uint16Array(N);
    const b32 = (0, utils_1.u32)(buf);
    let len = 0;
    for (let i = 0, p = 0, bb = 0, t0 = 0;i < b32.length; i++) {
      let b = b32[i];
      for (let j = 0;j < 32; j++) {
        bb += b & 1;
        b >>= 1;
        len += 1;
        if (len === eta) {
          t0 = bb;
          bb = 0;
        } else if (len === 2 * eta) {
          r[p++] = mod(t0 - bb);
          bb = 0;
          len = 0;
        }
      }
    }
    if (len)
      throw new Error(`sampleCBD: leftover bits: ${len}`);
    return r;
  }
  var genKPKE = (opts2) => {
    const { K, PRF, XOF, HASH512, ETA1, ETA2, du, dv } = opts2;
    const poly1 = polyCoder(1);
    const polyV = polyCoder(dv);
    const polyU = polyCoder(du);
    const publicCoder = (0, utils_js_1.splitCoder)((0, utils_js_1.vecCoder)(polyCoder(12), K), 32);
    const secretCoder = (0, utils_js_1.vecCoder)(polyCoder(12), K);
    const cipherCoder = (0, utils_js_1.splitCoder)((0, utils_js_1.vecCoder)(polyU, K), polyV);
    const seedCoder = (0, utils_js_1.splitCoder)(32, 32);
    return {
      secretCoder,
      secretKeyLen: secretCoder.bytesLen,
      publicKeyLen: publicCoder.bytesLen,
      cipherTextLen: cipherCoder.bytesLen,
      keygen: (seed) => {
        const seedDst = new Uint8Array(33);
        seedDst.set(seed);
        seedDst[32] = K;
        const seedHash = HASH512(seedDst);
        const [rho, sigma] = seedCoder.decode(seedHash);
        const sHat = [];
        const tHat = [];
        for (let i = 0;i < K; i++)
          sHat.push(NTT.encode(sampleCBD(PRF, sigma, i, ETA1)));
        const x = XOF(rho);
        for (let i = 0;i < K; i++) {
          const e = NTT.encode(sampleCBD(PRF, sigma, K + i, ETA1));
          for (let j = 0;j < K; j++) {
            const aji = SampleNTT(x.get(j, i));
            polyAdd(e, MultiplyNTTs(aji, sHat[j]));
          }
          tHat.push(e);
        }
        x.clean();
        const res = {
          publicKey: publicCoder.encode([tHat, rho]),
          secretKey: secretCoder.encode(sHat)
        };
        (0, utils_js_1.cleanBytes)(rho, sigma, sHat, tHat, seedDst, seedHash);
        return res;
      },
      encrypt: (publicKey, msg, seed) => {
        const [tHat, rho] = publicCoder.decode(publicKey);
        const rHat = [];
        for (let i = 0;i < K; i++)
          rHat.push(NTT.encode(sampleCBD(PRF, seed, i, ETA1)));
        const x = XOF(rho);
        const tmp2 = new Uint16Array(N);
        const u = [];
        for (let i = 0;i < K; i++) {
          const e1 = sampleCBD(PRF, seed, K + i, ETA2);
          const tmp = new Uint16Array(N);
          for (let j = 0;j < K; j++) {
            const aij = SampleNTT(x.get(i, j));
            polyAdd(tmp, MultiplyNTTs(aij, rHat[j]));
          }
          polyAdd(e1, NTT.decode(tmp));
          u.push(e1);
          polyAdd(tmp2, MultiplyNTTs(tHat[i], rHat[i]));
          tmp.fill(0);
        }
        x.clean();
        const e2 = sampleCBD(PRF, seed, 2 * K, ETA2);
        polyAdd(e2, NTT.decode(tmp2));
        const v = poly1.decode(msg);
        polyAdd(v, e2);
        (0, utils_js_1.cleanBytes)(tHat, rHat, tmp2, e2);
        return cipherCoder.encode([u, v]);
      },
      decrypt: (cipherText, privateKey) => {
        const [u, v] = cipherCoder.decode(cipherText);
        const sk = secretCoder.decode(privateKey);
        const tmp = new Uint16Array(N);
        for (let i = 0;i < K; i++)
          polyAdd(tmp, MultiplyNTTs(sk[i], NTT.encode(u[i])));
        polySub(v, NTT.decode(tmp));
        (0, utils_js_1.cleanBytes)(tmp, sk, u);
        return poly1.encode(v);
      }
    };
  };
  function createKyber(opts2) {
    const KPKE = genKPKE(opts2);
    const { HASH256, HASH512, KDF } = opts2;
    const { secretCoder: KPKESecretCoder, cipherTextLen } = KPKE;
    const publicKeyLen = KPKE.publicKeyLen;
    const secretCoder = (0, utils_js_1.splitCoder)(KPKE.secretKeyLen, KPKE.publicKeyLen, 32, 32);
    const secretKeyLen = secretCoder.bytesLen;
    const msgLen = 32;
    return {
      publicKeyLen,
      msgLen,
      keygen: (seed = (0, utils_js_1.randomBytes)(64)) => {
        (0, utils_js_1.ensureBytes)(seed, 64);
        const { publicKey, secretKey: sk } = KPKE.keygen(seed.subarray(0, 32));
        const publicKeyHash = HASH256(publicKey);
        const secretKey = secretCoder.encode([sk, publicKey, publicKeyHash, seed.subarray(32)]);
        (0, utils_js_1.cleanBytes)(sk, publicKeyHash);
        return { publicKey, secretKey };
      },
      encapsulate: (publicKey, msg = (0, utils_js_1.randomBytes)(32)) => {
        (0, utils_js_1.ensureBytes)(publicKey, publicKeyLen);
        (0, utils_js_1.ensureBytes)(msg, msgLen);
        const eke = publicKey.subarray(0, 384 * opts2.K);
        const ek = KPKESecretCoder.encode(KPKESecretCoder.decode(eke.slice()));
        if (!(0, utils_js_1.equalBytes)(ek, eke)) {
          (0, utils_js_1.cleanBytes)(ek);
          throw new Error("ML-KEM.encapsulate: wrong publicKey modulus");
        }
        (0, utils_js_1.cleanBytes)(ek);
        const kr = HASH512.create().update(msg).update(HASH256(publicKey)).digest();
        const cipherText = KPKE.encrypt(publicKey, msg, kr.subarray(32, 64));
        kr.subarray(32).fill(0);
        return { cipherText, sharedSecret: kr.subarray(0, 32) };
      },
      decapsulate: (cipherText, secretKey) => {
        (0, utils_js_1.ensureBytes)(secretKey, secretKeyLen);
        (0, utils_js_1.ensureBytes)(cipherText, cipherTextLen);
        const [sk, publicKey, publicKeyHash, z] = secretCoder.decode(secretKey);
        const msg = KPKE.decrypt(cipherText, sk);
        const kr = HASH512.create().update(msg).update(publicKeyHash).digest();
        const Khat = kr.subarray(0, 32);
        const cipherText2 = KPKE.encrypt(publicKey, msg, kr.subarray(32, 64));
        const isValid = (0, utils_js_1.equalBytes)(cipherText, cipherText2);
        const Kbar = KDF.create({ dkLen: 32 }).update(z).update(cipherText).digest();
        (0, utils_js_1.cleanBytes)(msg, cipherText2, !isValid ? Khat : Kbar);
        return isValid ? Khat : Kbar;
      }
    };
  }
  function shakePRF(dkLen, key, nonce) {
    return sha3_1.shake256.create({ dkLen }).update(key).update(new Uint8Array([nonce])).digest();
  }
  var opts = {
    HASH256: sha3_1.sha3_256,
    HASH512: sha3_1.sha3_512,
    KDF: sha3_1.shake256,
    XOF: _crystals_js_1.XOF128,
    PRF: shakePRF
  };
  exports.ml_kem512 = createKyber({
    ...opts,
    ...exports.PARAMS[512]
  });
  exports.ml_kem768 = createKyber({
    ...opts,
    ...exports.PARAMS[768]
  });
  exports.ml_kem1024 = createKyber({
    ...opts,
    ...exports.PARAMS[1024]
  });
});

// node_modules/@noble/post-quantum/ml-dsa.js
var require_ml_dsa = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.ml_dsa87 = exports.ml_dsa65 = exports.ml_dsa44 = exports.PARAMS = undefined;
  /*! noble-post-quantum - MIT License (c) 2024 Paul Miller (paulmillr.com) */
  var sha3_1 = require_sha3();
  var _crystals_js_1 = require__crystals();
  var utils_js_1 = require_utils3();
  var N = 256;
  var Q = 8380417;
  var ROOT_OF_UNITY = 1753;
  var F = 8347681;
  var D = 13;
  var GAMMA2_1 = Math.floor((Q - 1) / 88) | 0;
  var GAMMA2_2 = Math.floor((Q - 1) / 32) | 0;
  exports.PARAMS = {
    2: { K: 4, L: 4, D, GAMMA1: 2 ** 17, GAMMA2: GAMMA2_1, TAU: 39, ETA: 2, OMEGA: 80 },
    3: { K: 6, L: 5, D, GAMMA1: 2 ** 19, GAMMA2: GAMMA2_2, TAU: 49, ETA: 4, OMEGA: 55 },
    5: { K: 8, L: 7, D, GAMMA1: 2 ** 19, GAMMA2: GAMMA2_2, TAU: 60, ETA: 2, OMEGA: 75 }
  };
  var newPoly = (n) => new Int32Array(n);
  var { mod, smod, NTT, bitsCoder } = (0, _crystals_js_1.genCrystals)({
    N,
    Q,
    F,
    ROOT_OF_UNITY,
    newPoly,
    isKyber: false,
    brvBits: 8
  });
  var id = (n) => n;
  var polyCoder = (d, compress = id, verify = id) => bitsCoder(d, {
    encode: (i) => compress(verify(i)),
    decode: (i) => verify(compress(i))
  });
  var polyAdd = (a, b) => {
    for (let i = 0;i < a.length; i++)
      a[i] = mod(a[i] + b[i]);
    return a;
  };
  var polySub = (a, b) => {
    for (let i = 0;i < a.length; i++)
      a[i] = mod(a[i] - b[i]);
    return a;
  };
  var polyShiftl = (p) => {
    for (let i = 0;i < N; i++)
      p[i] <<= D;
    return p;
  };
  var polyChknorm = (p, B) => {
    for (let i = 0;i < N; i++)
      if (Math.abs(smod(p[i])) >= B)
        return true;
    return false;
  };
  var MultiplyNTTs = (a, b) => {
    const c = newPoly(N);
    for (let i = 0;i < a.length; i++)
      c[i] = mod(a[i] * b[i]);
    return c;
  };
  function RejNTTPoly(xof) {
    const r = newPoly(N);
    for (let j = 0;j < N; ) {
      const b = xof();
      if (b.length % 3)
        throw new Error("RejNTTPoly: unaligned block");
      for (let i = 0;j < N && i <= b.length - 3; i += 3) {
        const t = (b[i + 0] | b[i + 1] << 8 | b[i + 2] << 16) & 8388607;
        if (t < Q)
          r[j++] = t;
      }
    }
    return r;
  }
  function getDilithium(opts) {
    const { K, L, GAMMA1, GAMMA2, TAU, ETA, OMEGA } = opts;
    const { CRH_BYTES, TR_BYTES, C_TILDE_BYTES, XOF128, XOF256 } = opts;
    if (![2, 4].includes(ETA))
      throw new Error("Wrong ETA");
    if (![1 << 17, 1 << 19].includes(GAMMA1))
      throw new Error("Wrong GAMMA1");
    if (![GAMMA2_1, GAMMA2_2].includes(GAMMA2))
      throw new Error("Wrong GAMMA2");
    const BETA = TAU * ETA;
    const decompose = (r) => {
      const rPlus = mod(r);
      const r0 = smod(rPlus, 2 * GAMMA2) | 0;
      if (rPlus - r0 === Q - 1)
        return { r1: 0 | 0, r0: r0 - 1 | 0 };
      const r1 = Math.floor((rPlus - r0) / (2 * GAMMA2)) | 0;
      return { r1, r0 };
    };
    const HighBits = (r) => decompose(r).r1;
    const LowBits = (r) => decompose(r).r0;
    const MakeHint = (z, r) => {
      const res0 = z <= GAMMA2 || z > Q - GAMMA2 || z === Q - GAMMA2 && r === 0 ? 0 : 1;
      return res0;
    };
    const UseHint = (h, r) => {
      const m = Math.floor((Q - 1) / (2 * GAMMA2));
      const { r1, r0 } = decompose(r);
      if (h === 1)
        return r0 > 0 ? mod(r1 + 1, m) | 0 : mod(r1 - 1, m) | 0;
      return r1 | 0;
    };
    const Power2Round = (r) => {
      const rPlus = mod(r);
      const r0 = smod(rPlus, 2 ** D) | 0;
      return { r1: Math.floor((rPlus - r0) / 2 ** D) | 0, r0 };
    };
    const hintCoder = {
      bytesLen: OMEGA + K,
      encode: (h) => {
        if (h === false)
          throw new Error("hint.encode: hint is false");
        const res = new Uint8Array(OMEGA + K);
        for (let i = 0, k = 0;i < K; i++) {
          for (let j = 0;j < N; j++)
            if (h[i][j] !== 0)
              res[k++] = j;
          res[OMEGA + i] = k;
        }
        return res;
      },
      decode: (buf) => {
        const h = [];
        let k = 0;
        for (let i = 0;i < K; i++) {
          const hi = newPoly(N);
          if (buf[OMEGA + i] < k || buf[OMEGA + i] > OMEGA)
            return false;
          for (let j = k;j < buf[OMEGA + i]; j++) {
            if (j > k && buf[j] <= buf[j - 1])
              return false;
            hi[buf[j]] = 1;
          }
          k = buf[OMEGA + i];
          h.push(hi);
        }
        for (let j = k;j < OMEGA; j++)
          if (buf[j] !== 0)
            return false;
        return h;
      }
    };
    const ETACoder = polyCoder(ETA === 2 ? 3 : 4, (i) => ETA - i, (i) => {
      if (!(-ETA <= i && i <= ETA))
        throw new Error(`malformed key s1/s3 ${i} outside of ETA range [${-ETA}, ${ETA}]`);
      return i;
    });
    const T0Coder = polyCoder(13, (i) => (1 << D - 1) - i);
    const T1Coder = polyCoder(10);
    const ZCoder = polyCoder(GAMMA1 === 1 << 17 ? 18 : 20, (i) => smod(GAMMA1 - i));
    const W1Coder = polyCoder(GAMMA2 === GAMMA2_1 ? 6 : 4);
    const W1Vec = (0, utils_js_1.vecCoder)(W1Coder, K);
    const publicCoder = (0, utils_js_1.splitCoder)(32, (0, utils_js_1.vecCoder)(T1Coder, K));
    const secretCoder = (0, utils_js_1.splitCoder)(32, 32, TR_BYTES, (0, utils_js_1.vecCoder)(ETACoder, L), (0, utils_js_1.vecCoder)(ETACoder, K), (0, utils_js_1.vecCoder)(T0Coder, K));
    const sigCoder = (0, utils_js_1.splitCoder)(C_TILDE_BYTES, (0, utils_js_1.vecCoder)(ZCoder, L), hintCoder);
    const CoefFromHalfByte = ETA === 2 ? (n) => n < 15 ? 2 - n % 5 : false : (n) => n < 9 ? 4 - n : false;
    function RejBoundedPoly(xof) {
      const r = newPoly(N);
      for (let j = 0;j < N; ) {
        const b = xof();
        for (let i = 0;j < N && i < b.length; i += 1) {
          const d1 = CoefFromHalfByte(b[i] & 15);
          const d2 = CoefFromHalfByte(b[i] >> 4 & 15);
          if (d1 !== false)
            r[j++] = d1;
          if (j < N && d2 !== false)
            r[j++] = d2;
        }
      }
      return r;
    }
    const SampleInBall = (seed) => {
      const pre = newPoly(N);
      const s = sha3_1.shake256.create({}).update(seed);
      const buf = new Uint8Array(sha3_1.shake256.blockLen);
      s.xofInto(buf);
      const masks = buf.slice(0, 8);
      for (let i = N - TAU, pos = 8, maskPos = 0, maskBit = 0;i < N; i++) {
        let b = i + 1;
        for (;b > i; ) {
          b = buf[pos++];
          if (pos < sha3_1.shake256.blockLen)
            continue;
          s.xofInto(buf);
          pos = 0;
        }
        pre[i] = pre[b];
        pre[b] = 1 - ((masks[maskPos] >> maskBit++ & 1) << 1);
        if (maskBit >= 8) {
          maskPos++;
          maskBit = 0;
        }
      }
      return pre;
    };
    const polyPowerRound = (p) => {
      const res0 = newPoly(N);
      const res1 = newPoly(N);
      for (let i = 0;i < p.length; i++) {
        const { r0, r1 } = Power2Round(p[i]);
        res0[i] = r0;
        res1[i] = r1;
      }
      return { r0: res0, r1: res1 };
    };
    const polyUseHint = (u, h) => {
      for (let i = 0;i < N; i++)
        u[i] = UseHint(h[i], u[i]);
      return u;
    };
    const polyMakeHint = (a, b) => {
      const v = newPoly(N);
      let cnt = 0;
      for (let i = 0;i < N; i++) {
        const h = MakeHint(a[i], b[i]);
        v[i] = h;
        cnt += h;
      }
      return { v, cnt };
    };
    const signRandBytes = 32;
    const seedCoder = (0, utils_js_1.splitCoder)(32, 64, 32);
    const internal = {
      signRandBytes,
      keygen: (seed = (0, utils_js_1.randomBytes)(32)) => {
        const seedDst = new Uint8Array(32 + 2);
        seedDst.set(seed);
        seedDst[32] = K;
        seedDst[33] = L;
        const [rho, rhoPrime, K_] = seedCoder.decode((0, sha3_1.shake256)(seedDst, { dkLen: seedCoder.bytesLen }));
        const xofPrime = XOF256(rhoPrime);
        const s1 = [];
        for (let i = 0;i < L; i++)
          s1.push(RejBoundedPoly(xofPrime.get(i & 255, i >> 8 & 255)));
        const s2 = [];
        for (let i = L;i < L + K; i++)
          s2.push(RejBoundedPoly(xofPrime.get(i & 255, i >> 8 & 255)));
        const s1Hat = s1.map((i) => NTT.encode(i.slice()));
        const t0 = [];
        const t1 = [];
        const xof = XOF128(rho);
        const t = newPoly(N);
        for (let i = 0;i < K; i++) {
          t.fill(0);
          for (let j = 0;j < L; j++) {
            const aij = RejNTTPoly(xof.get(j, i));
            polyAdd(t, MultiplyNTTs(aij, s1Hat[j]));
          }
          NTT.decode(t);
          const { r0, r1 } = polyPowerRound(polyAdd(t, s2[i]));
          t0.push(r0);
          t1.push(r1);
        }
        const publicKey = publicCoder.encode([rho, t1]);
        const tr = (0, sha3_1.shake256)(publicKey, { dkLen: TR_BYTES });
        const secretKey = secretCoder.encode([rho, K_, tr, s1, s2, t0]);
        xof.clean();
        xofPrime.clean();
        (0, utils_js_1.cleanBytes)(rho, rhoPrime, K_, s1, s2, s1Hat, t, t0, t1, tr, seedDst);
        return { publicKey, secretKey };
      },
      sign: (secretKey, msg, random, externalMu = false) => {
        const [rho, _K, tr, s1, s2, t0] = secretCoder.decode(secretKey);
        const A = [];
        const xof = XOF128(rho);
        for (let i = 0;i < K; i++) {
          const pv = [];
          for (let j = 0;j < L; j++)
            pv.push(RejNTTPoly(xof.get(j, i)));
          A.push(pv);
        }
        xof.clean();
        for (let i = 0;i < L; i++)
          NTT.encode(s1[i]);
        for (let i = 0;i < K; i++) {
          NTT.encode(s2[i]);
          NTT.encode(t0[i]);
        }
        const mu = externalMu ? msg : sha3_1.shake256.create({ dkLen: CRH_BYTES }).update(tr).update(msg).digest();
        const rnd = random ? random : new Uint8Array(32);
        (0, utils_js_1.ensureBytes)(rnd);
        const rhoprime = sha3_1.shake256.create({ dkLen: CRH_BYTES }).update(_K).update(rnd).update(mu).digest();
        (0, utils_js_1.ensureBytes)(rhoprime, CRH_BYTES);
        const x256 = XOF256(rhoprime, ZCoder.bytesLen);
        main_loop:
          for (let kappa = 0;; ) {
            const y = [];
            for (let i = 0;i < L; i++, kappa++)
              y.push(ZCoder.decode(x256.get(kappa & 255, kappa >> 8)()));
            const z = y.map((i) => NTT.encode(i.slice()));
            const w = [];
            for (let i = 0;i < K; i++) {
              const wi = newPoly(N);
              for (let j = 0;j < L; j++)
                polyAdd(wi, MultiplyNTTs(A[i][j], z[j]));
              NTT.decode(wi);
              w.push(wi);
            }
            const w1 = w.map((j) => j.map(HighBits));
            const cTilde = sha3_1.shake256.create({ dkLen: C_TILDE_BYTES }).update(mu).update(W1Vec.encode(w1)).digest();
            const cHat = NTT.encode(SampleInBall(cTilde));
            const cs1 = s1.map((i) => MultiplyNTTs(i, cHat));
            for (let i = 0;i < L; i++) {
              polyAdd(NTT.decode(cs1[i]), y[i]);
              if (polyChknorm(cs1[i], GAMMA1 - BETA))
                continue main_loop;
            }
            let cnt = 0;
            const h = [];
            for (let i = 0;i < K; i++) {
              const cs2 = NTT.decode(MultiplyNTTs(s2[i], cHat));
              const r0 = polySub(w[i], cs2).map(LowBits);
              if (polyChknorm(r0, GAMMA2 - BETA))
                continue main_loop;
              const ct0 = NTT.decode(MultiplyNTTs(t0[i], cHat));
              if (polyChknorm(ct0, GAMMA2))
                continue main_loop;
              polyAdd(r0, ct0);
              const hint = polyMakeHint(r0, w1[i]);
              h.push(hint.v);
              cnt += hint.cnt;
            }
            if (cnt > OMEGA)
              continue;
            x256.clean();
            const res = sigCoder.encode([cTilde, cs1, h]);
            (0, utils_js_1.cleanBytes)(cTilde, cs1, h, cHat, w1, w, z, y, rhoprime, mu, s1, s2, t0, ...A);
            return res;
          }
        throw new Error("Unreachable code path reached, report this error");
      },
      verify: (publicKey, msg, sig, externalMu = false) => {
        const [rho, t1] = publicCoder.decode(publicKey);
        const tr = (0, sha3_1.shake256)(publicKey, { dkLen: TR_BYTES });
        if (sig.length !== sigCoder.bytesLen)
          return false;
        const [cTilde, z, h] = sigCoder.decode(sig);
        if (h === false)
          return false;
        for (let i = 0;i < L; i++)
          if (polyChknorm(z[i], GAMMA1 - BETA))
            return false;
        const mu = externalMu ? msg : sha3_1.shake256.create({ dkLen: CRH_BYTES }).update(tr).update(msg).digest();
        const c = NTT.encode(SampleInBall(cTilde));
        const zNtt = z.map((i) => i.slice());
        for (let i = 0;i < L; i++)
          NTT.encode(zNtt[i]);
        const wTick1 = [];
        const xof = XOF128(rho);
        for (let i = 0;i < K; i++) {
          const ct12d = MultiplyNTTs(NTT.encode(polyShiftl(t1[i])), c);
          const Az = newPoly(N);
          for (let j = 0;j < L; j++) {
            const aij = RejNTTPoly(xof.get(j, i));
            polyAdd(Az, MultiplyNTTs(aij, zNtt[j]));
          }
          const wApprox = NTT.decode(polySub(Az, ct12d));
          wTick1.push(polyUseHint(wApprox, h[i]));
        }
        xof.clean();
        const c2 = sha3_1.shake256.create({ dkLen: C_TILDE_BYTES }).update(mu).update(W1Vec.encode(wTick1)).digest();
        for (const t of h) {
          const sum = t.reduce((acc, i) => acc + i, 0);
          if (!(sum <= OMEGA))
            return false;
        }
        for (const t of z)
          if (polyChknorm(t, GAMMA1 - BETA))
            return false;
        return (0, utils_js_1.equalBytes)(cTilde, c2);
      }
    };
    return {
      internal,
      keygen: internal.keygen,
      signRandBytes: internal.signRandBytes,
      sign: (secretKey, msg, ctx = utils_js_1.EMPTY, random) => {
        const M = (0, utils_js_1.getMessage)(msg, ctx);
        const res = internal.sign(secretKey, M, random);
        M.fill(0);
        return res;
      },
      verify: (publicKey, msg, sig, ctx = utils_js_1.EMPTY) => {
        return internal.verify(publicKey, (0, utils_js_1.getMessage)(msg, ctx), sig);
      },
      prehash: (hashName) => ({
        sign: (secretKey, msg, ctx = utils_js_1.EMPTY, random) => {
          const M = (0, utils_js_1.getMessagePrehash)(hashName, msg, ctx);
          const res = internal.sign(secretKey, M, random);
          M.fill(0);
          return res;
        },
        verify: (publicKey, msg, sig, ctx = utils_js_1.EMPTY) => {
          return internal.verify(publicKey, (0, utils_js_1.getMessagePrehash)(hashName, msg, ctx), sig);
        }
      })
    };
  }
  exports.ml_dsa44 = getDilithium({
    ...exports.PARAMS[2],
    CRH_BYTES: 64,
    TR_BYTES: 64,
    C_TILDE_BYTES: 32,
    XOF128: _crystals_js_1.XOF128,
    XOF256: _crystals_js_1.XOF256
  });
  exports.ml_dsa65 = getDilithium({
    ...exports.PARAMS[3],
    CRH_BYTES: 64,
    TR_BYTES: 64,
    C_TILDE_BYTES: 48,
    XOF128: _crystals_js_1.XOF128,
    XOF256: _crystals_js_1.XOF256
  });
  exports.ml_dsa87 = getDilithium({
    ...exports.PARAMS[5],
    CRH_BYTES: 64,
    TR_BYTES: 64,
    C_TILDE_BYTES: 64,
    XOF128: _crystals_js_1.XOF128,
    XOF256: _crystals_js_1.XOF256
  });
});

// src/lib/decoder.ts
var pkg = __toESM(require_dist(), 1);
var { Uuid } = pkg;
var KyPublicKeySize = 1568;
var KySecretKeySize = 3168;
var DiPublicKeySize = 2592;
var DiSecretKeySize = 4896;
function encodePassword(passwordObject) {
  if (!passwordObject || typeof passwordObject.password !== "string" || typeof passwordObject.username !== "string") {
    console.error("encodePassword: Missing required fields 'password' and/or 'username'.");
    return null;
  }
  function encodeString(str) {
    const encoder = new TextEncoder;
    const encodedStr = encoder.encode(str);
    const len = encodedStr.length;
    const result = new ArrayBuffer(8 + len);
    const view = new DataView(result);
    let offset2 = 0;
    const bigNum = BigInt(len);
    view.setBigUint64(offset2, bigNum, true);
    offset2 += 8;
    if (len > 0) {
      for (let i = 0;i < len; ++i) {
        view.setUint8(offset2++, encodedStr[i]);
      }
    }
    const result2 = new Uint8Array(result);
    return result2;
  }
  function encodeOptional(str) {
    if (str !== undefined && str !== null) {
      const flag = new Uint8Array([1]);
      const encodedString = encodeString(str);
      return { flag, encodedString };
    } else {
      const flag = new Uint8Array([0]);
      return { flag, encodedString: null };
    }
  }
  const parts = [];
  parts.push(encodeString(passwordObject.password));
  const appIdObj = encodeOptional(passwordObject.app_id);
  parts.push(appIdObj.flag);
  if (appIdObj.encodedString) {
    parts.push(appIdObj.encodedString);
  }
  parts.push(encodeString(passwordObject.username));
  const descriptionObj = encodeOptional(passwordObject.description);
  parts.push(descriptionObj.flag);
  if (descriptionObj.encodedString) {
    parts.push(descriptionObj.encodedString);
  }
  const urlObj = encodeOptional(passwordObject.url);
  parts.push(urlObj.flag);
  if (urlObj.encodedString) {
    parts.push(urlObj.encodedString);
  }
  const otpObj = encodeOptional(passwordObject.otp);
  parts.push(otpObj.flag);
  if (otpObj.encodedString) {
    parts.push(otpObj.encodedString);
  }
  const totalLength = parts.reduce((acc, part) => acc + part.length, 0);
  const combined = new Uint8Array(totalLength);
  let offset = 0;
  for (const part of parts) {
    combined.set(part, offset);
    offset += part.length;
  }
  return combined;
}
function decodePassword(bytes) {
  let offset = 0;
  if (!bytes || !(bytes instanceof Uint8Array)) {
    console.error("decodePassword: Input is not a valid Uint8Array.");
    return null;
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  function readString(bytes2, offset2) {
    if (!bytes2 || !(bytes2 instanceof Uint8Array)) {
      console.error("decodeString: Input is not a valid Uint8Array.");
      return null;
    }
    const view2 = new DataView(bytes2.buffer, bytes2.byteOffset, bytes2.byteLength);
    const len = Number(view2.getBigUint64(offset2, true));
    offset2 += 8;
    if (offset2 + len > bytes2.byteLength)
      return null;
    const strBytes = bytes2.slice(offset2, offset2 + len);
    const decoder = new TextDecoder;
    const str = decoder.decode(strBytes);
    return { str, bytesRead: 8 + len };
  }
  let passwordResult = readString(bytes, offset);
  if (!passwordResult)
    return null;
  let password = passwordResult.str;
  offset += passwordResult.bytesRead;
  const appIdPresent = view.getUint8(offset);
  let app_id = null;
  if (appIdPresent === 1) {
    offset++;
    let appResult = readString(bytes, offset);
    if (!appResult)
      return null;
    app_id = appResult.str;
    offset += appResult.bytesRead;
  } else if (appIdPresent !== 0) {
    return null;
  } else {
    offset++;
  }
  let usernameResult = readString(bytes, offset);
  if (!usernameResult)
    return null;
  let username = usernameResult.str;
  offset += usernameResult.bytesRead;
  const descriptionPresent = view.getUint8(offset);
  let description = null;
  if (descriptionPresent === 1) {
    offset++;
    let descriptionResult = readString(bytes, offset);
    if (!descriptionResult)
      return null;
    description = descriptionResult.str;
    offset += descriptionResult.bytesRead;
  } else if (descriptionPresent !== 0) {
    return null;
  } else {
    offset++;
  }
  const urlPresent = view.getUint8(offset);
  let url = null;
  if (urlPresent === 1) {
    offset++;
    let urlResult = readString(bytes, offset);
    if (!urlResult)
      return null;
    url = urlResult.str;
    offset += urlResult.bytesRead;
  } else if (urlPresent !== 0) {
    return null;
  } else {
    offset++;
  }
  const otpPresent = view.getUint8(offset);
  let otp = null;
  if (otpPresent === 1) {
    offset++;
    let otpResult = readString(bytes, offset);
    if (!otpResult)
      return null;
    otp = otpResult.str;
    offset += otpResult.bytesRead;
  } else if (otpPresent !== 0) {
    return null;
  } else {
    offset++;
  }
  const passwordObject = {
    password,
    app_id,
    username,
    description,
    url,
    otp
  };
  return passwordObject;
}
function uuidToStr(uuid) {
  try {
    const uuidBytes = new Uint8Array(uuid.bytes);
    let uuidBytes2 = new Array(uuidBytes.length);
    for (let i = 0;i < uuidBytes.length; i++) {
      uuidBytes2[i] = uuidBytes[i];
    }
    const uuidObj = new Uuid(uuidBytes2);
    console.log("uuidObj:", uuidObj);
    return uuidObj.toString();
  } catch (e) {
    console.error("Erreur lors de la conversion de l'UUID en chaîne:", e);
    return "";
  }
}
function decodeString(bytes) {
  if (!bytes || !(bytes instanceof Uint8Array)) {
    console.error("decodeString: L'entrée n'est pas un Uint8Array valide.");
    return null;
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let offset = 0;
  const len = Number(view.getBigUint64(offset, true));
  offset += 8;
  if (offset + len > bytes.byteLength) {
    return null;
  }
  const strBytes = bytes.slice(offset, offset + len);
  const decoder = new TextDecoder;
  const str = decoder.decode(strBytes);
  return { str, bytesRead: 8 + len };
}
function decodeKyPublicKey(bytes) {
  if (bytes.length < KyPublicKeySize) {
    return null;
  }
  const key = bytes.slice(0, KyPublicKeySize);
  return { key };
}
function decodeKySecretKey(bytes) {
  if (bytes.length < KySecretKeySize) {
    return null;
  }
  const key = bytes.slice(0, KySecretKeySize);
  return { key };
}
function decodeDiPublicKey(bytes) {
  if (bytes.length < DiPublicKeySize) {
    return null;
  }
  const key = bytes.slice(0, DiPublicKeySize);
  return { key };
}
function decodeDiSecretKey(bytes) {
  if (bytes.length < DiSecretKeySize) {
    return null;
  }
  const key = bytes.slice(0, DiSecretKeySize);
  return { key };
}
function decodeClient(bytes) {
  let offset = 0;
  offset += 8;
  const ky_p_result = decodeKyPublicKey(bytes.slice(offset));
  if (!ky_p_result)
    return null;
  const ky_p = ky_p_result.key;
  offset += KyPublicKeySize;
  offset += 8;
  const ky_q_result = decodeKySecretKey(bytes.slice(offset));
  if (!ky_q_result)
    return null;
  const ky_q = ky_q_result.key;
  offset += KySecretKeySize;
  offset += 8;
  const di_p_result = decodeDiPublicKey(bytes.slice(offset));
  if (!di_p_result)
    return null;
  const di_p = di_p_result.key;
  offset += DiPublicKeySize;
  offset += 8;
  const di_q_result = decodeDiSecretKey(bytes.slice(offset));
  if (!di_q_result)
    return null;
  const di_q = di_q_result.key;
  offset += DiSecretKeySize;
  if (!bytes || !(bytes instanceof Uint8Array)) {
    console.error("decodeClient: L'entrée n'est pas un Uint8Array valide.");
    return null;
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset + offset, bytes.byteLength - offset);
  offset = 0;
  const secretPresent = view.getUint8(offset++);
  let secret = null;
  if (secretPresent === 1) {
    if (offset + 32 > view.byteLength)
      return null;
    secret = bytes.slice(view.byteOffset + offset, view.byteOffset + offset + 32);
    offset += 32;
  } else if (secretPresent !== 0) {
    return null;
  }
  const client = {
    ky_p,
    ky_q,
    di_p,
    di_q,
    secret
  };
  return {
    client,
    remainingBytes: bytes.slice(view.byteOffset + offset)
  };
}
function decodeCK(bytes) {
  let offset = 0;
  const emailResult = decodeString(bytes);
  if (!emailResult)
    return null;
  const email = emailResult.str;
  offset += emailResult.bytesRead;
  const view = new DataView(bytes.buffer, bytes.byteOffset + offset, bytes.byteLength - offset);
  offset = 0;
  const uuidPresent = view.getUint8(offset++);
  let uuid = null;
  if (uuidPresent === 1) {
    offset += 8;
    const uuidBytes = bytes.slice(view.byteOffset + offset, view.byteOffset + offset + 16);
    if (uuidBytes.length !== 16)
      return null;
    uuid = { bytes: uuidBytes };
    offset += 16;
  } else if (uuidPresent !== 0) {
    return null;
  }
  offset += 8;
  const ky_p_result = decodeKyPublicKey(bytes.slice(view.byteOffset + offset));
  if (!ky_p_result)
    return null;
  const ky_p = ky_p_result.key;
  offset += KyPublicKeySize;
  offset += 8;
  const di_p_result = decodeDiPublicKey(bytes.slice(view.byteOffset + offset));
  if (!di_p_result)
    return null;
  const di_p = di_p_result.key;
  offset += DiPublicKeySize;
  const ck = {
    email,
    id: uuid,
    ky_p: { bytes: ky_p },
    di_p: { bytes: di_p }
  };
  return {
    ck,
    remainingBytes: bytes.slice(view.byteOffset + offset)
  };
}
function decodeClientEx(bytes) {
  const uint8Array = bytes instanceof ArrayBuffer ? new Uint8Array(bytes) : bytes;
  const clientResult = decodeClient(uint8Array);
  if (!clientResult)
    return null;
  const client = clientResult.client;
  const remainingBytesAfterClient = clientResult.remainingBytes;
  const ckResult = decodeCK(remainingBytesAfterClient);
  if (!ckResult)
    return null;
  const ck = ckResult.ck;
  return { c: client, id: ck };
}

// src/lib/client.ts
var import_blake3 = __toESM(require_blake3(), 1);
var import_chacha = __toESM(require_chacha(), 1);
var pkg2 = __toESM(require_dist(), 1);
var import_ml_kem = __toESM(require_ml_kem(), 1);
var import_utils = __toESM(require_utils3(), 1);
var API_URL = "https://skap.klyt.eu/";
var sessionToken = null;
var fetchOptions = {
  credentials: "include",
  mode: "cors",
  cache: "no-cache",
  redirect: "follow"
};
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "restoreSessionToken" && message.token) {
    sessionToken = message.token;
    console.log("Token de session restauré:", sessionToken);
    sendResponse({ success: true });
  }
  return true;
});
function setSessionToken(token) {
  sessionToken = token;
  browser.runtime.sendMessage({
    action: "saveSessionToken",
    token
  }).then((response) => {
    console.log("Réponse du background script:", response);
  });
}
function getSessionToken() {
  if (!sessionToken) {
    browser.runtime.sendMessage({ action: "getSessionToken" }).then((response) => {
      sessionToken = response.token;
    });
  } else {
    return sessionToken;
  }
}
function getRequestOptions(method = "GET", body) {
  const options = {
    ...fetchOptions,
    method,
    headers: {
      ...method !== "GET" ? { "Content-Type": "application/json" } : {},
      Accept: "application/json",
      Connection: "keep-alive"
    }
  };
  if (sessionToken) {
    options.headers = {
      ...options.headers,
      Authorization: sessionToken
    };
  }
  if (body) {
    options.body = JSON.stringify(body);
  }
  return options;
}
function encrypt(pass, client) {
  const passb = encodePassword(pass);
  if (!passb) {
    return { result: null, error: "Échec de l'encodage du mot de passe" };
  }
  if (!client.ky_q) {
    return { result: null, error: "Missing client.ky_q" };
  }
  const ky_q = new Uint8Array(client.ky_q);
  const hash = import_blake3.blake3(ky_q).slice(0, 32);
  const nonce = import_utils.randomBytes(24);
  const key = new Uint8Array(hash);
  const cipher = import_chacha.xchacha20poly1305(key, nonce);
  const ciphertext = cipher.encrypt(passb);
  const ep = {
    ciphertext,
    nonce,
    nonce2: null
  };
  return { result: ep, error: null };
}
function send(ep, client) {
  if (!client.secret) {
    return { result: null, error: "Missing client.secret" };
  }
  const secret = new Uint8Array(client.secret);
  const hash = import_blake3.blake3(secret).slice(0, 32);
  const nonce2 = import_utils.randomBytes(24);
  const key = new Uint8Array(hash);
  const cipher = import_chacha.xchacha20poly1305(key, nonce2);
  const ciphertext = cipher.encrypt(ep.ciphertext);
  const ep2 = {
    ciphertext,
    nonce: ep.nonce,
    nonce2
  };
  return { result: ep2, error: null };
}
async function create_pass(uuid, pass, client) {
  if (!sessionToken) {
    sessionToken = getSessionToken() ?? null;
    if (!sessionToken) {
      return { result: null, error: "Token de session manquant" };
    }
  }
  const encrypted = encrypt(pass, client);
  if (!encrypted.result) {
    return { result: null, error: encrypted.error };
  }
  const eq = send(encrypted.result, client);
  if (!eq.result) {
    return { result: null, error: eq.error };
  }
  const truer = {
    ciphertext: Array.from(eq.result.ciphertext),
    nonce: Array.from(eq.result.nonce),
    nonce2: Array.from(eq.result.nonce2)
  };
  const res = await fetch(API_URL + "create_pass_json/" + uuidToStr(uuid), {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: sessionToken ?? ""
    },
    body: JSON.stringify(truer)
  });
  if (!res.ok) {
    return { result: null, error: res.statusText };
  }
  const result = await res.json();
  return { result, error: null };
}
async function auth(uuid, client) {
  try {
    console.log("uuid:", uuid);
    console.log("client:", client);
    console.log(uuidToStr(uuid));
    const response = await fetch(API_URL + "challenge_json/" + uuidToStr(uuid), getRequestOptions());
    if (!response.ok) {
      return { result: null, client: null, error: response.statusText };
    }
    const challenge = await response.json();
    const challengeBytes = arraytoUint8Array(challenge);
    const di_q = new Uint8Array(client.di_q);
    console.log("di_q:", di_q);
    console.log("challengeBytes:", challengeBytes);
    const { ml_dsa87 } = await Promise.resolve().then(() => __toESM(require_ml_dsa(), 1));
    const signature = ml_dsa87.sign(di_q, challengeBytes);
    const signArray = arrayfrom(signature);
    const response2 = await fetch(API_URL + "verify_json/" + uuidToStr(uuid), getRequestOptions("POST", signArray));
    if (!response2.ok) {
      return { result: null, client: null, error: response2.statusText };
    }
    try {
      const tokenResponse = await response2.json();
      console.log("Token de session récupéré:", tokenResponse);
      if (typeof tokenResponse === "string") {
        setSessionToken(tokenResponse);
        console.log("Token de session récupéré:", tokenResponse);
      } else {
        console.warn("La réponse n'est pas un token de session valide:", tokenResponse);
      }
    } catch (error) {
      console.error("Erreur lors de la récupération du token de session:", error);
    }
    const response3 = await fetch(API_URL + "sync_json/" + uuidToStr(uuid), getRequestOptions());
    console.log("En-têtes de la requête sync_json:", getRequestOptions().headers);
    if (!response3.ok) {
      return { result: null, shared: null, error: response3.statusText };
    }
    const result2 = Uint8Array.from(await response3.json());
    const { ml_kem1024: ml_kem10242 } = await Promise.resolve().then(() => __toESM(require_ml_kem(), 1));
    const ky_q = new Uint8Array(client.ky_q);
    const shared = ml_kem10242.decapsulate(result2, ky_q);
    client.secret = shared;
    return { result: response2, client, error: null };
  } catch (error) {
    console.error("Erreur d'authentification:", error);
    return { result: null, client: null, error: String(error) };
  }
}
async function get_all(uuid, client) {
  try {
    if (!sessionToken) {
      console.warn("Token de session non disponible, l'authentification pourrait échouer");
    } else {
      console.log("Token de session utilisé pour get_all:", sessionToken);
    }
    const options = getRequestOptions();
    console.log("En-têtes de la requête send_all_json:", options.headers);
    const response = await fetch(API_URL + "send_all_json/" + uuidToStr(uuid), options);
    if (!response.ok) {
      return { passwords: [], error: response.statusText };
    }
    const result = await response.json();
    const secretKey = new Uint8Array(client.secret);
    const hash = import_blake3.blake3(secretKey).slice(0, 32);
    const key = new Uint8Array(hash);
    const ky_q = new Uint8Array(client.ky_q);
    const hash2 = import_blake3.blake3(ky_q).slice(0, 32);
    const key2 = new Uint8Array(hash2);
    if (!secretKey) {
      return { passwords: [], error: "Clé secrète manquante" };
    }
    const passwordsResult = result.passwords || [];
    const passwordsList = [];
    const sharedRecipients = result.shared || [];
    for (const [ep, uuidStr] of passwordsResult) {
      try {
        if (!ep.nonce2) {
          console.error("nonce2 manquant");
          continue;
        }
        const nonce2 = ep.nonce2 instanceof Uint8Array ? ep.nonce2.slice(0, 24) : Uint8Array.from(ep.nonce2).slice(0, 24);
        const chacha = import_chacha.xchacha20poly1305(key, nonce2);
        const ciphertext1 = ep.ciphertext instanceof Uint8Array ? ep.ciphertext : Uint8Array.from(ep.ciphertext);
        const decryptedIntermediate = chacha.decrypt(ciphertext1);
        const nonce = ep.nonce instanceof Uint8Array ? ep.nonce : Uint8Array.from(ep.nonce);
        if (!client.ky_q) {
          console.error("ky_q manquant");
          continue;
        }
        const cipher = import_chacha.xchacha20poly1305(key2, nonce);
        const finalDecrypted = cipher.decrypt(decryptedIntermediate);
        console.log("finalDecrypted:", finalDecrypted);
        const password = decodePassword(finalDecrypted);
        if (!password) {
          console.error("Mot de passe non valide");
          continue;
        }
        passwordsList.push(password);
        console.log("Mot de passe déchiffré:", password);
      } catch (error) {
        console.error("Erreur lors du déchiffrement d'un mot de passe:", error);
      }
    }
    for (const [sharedPass, ownerUuid, passUuid] of sharedRecipients) {
      const sharedPassObj = {
        kem_ct: Uint8Array.from(sharedPass.kem_ct),
        ep: {
          ciphertext: Uint8Array.from(sharedPass.ep.ciphertext),
          nonce: Uint8Array.from(sharedPass.ep.nonce),
          nonce2: sharedPass.ep.nonce2 ? Uint8Array.from(sharedPass.ep.nonce2) : null
        },
        status: sharedPass.status
      };
      const sharedSecret = import_ml_kem.ml_kem1024.decapsulate(sharedPassObj.kem_ct, ky_q);
      const secretKey2 = import_blake3.blake3(sharedSecret).slice(0, 32);
      const key3 = new Uint8Array(secretKey2);
      const nonce = sharedPassObj.ep.nonce instanceof Uint8Array ? sharedPassObj.ep.nonce : Uint8Array.from(sharedPassObj.ep.nonce);
      const cipher = import_chacha.xchacha20poly1305(key3, nonce);
      const ciphertext = sharedPassObj.ep.ciphertext instanceof Uint8Array ? sharedPassObj.ep.ciphertext : Uint8Array.from(sharedPassObj.ep.ciphertext);
      const decryptedBytes = cipher.decrypt(ciphertext);
      const password = decodePassword(decryptedBytes);
      if (!password) {
        console.error("Mot de passe non valide");
        continue;
      }
      if (sharedPassObj.status === 1 /* Accepted */) {
        passwordsList.push(password);
      }
    }
    return { passwords: passwordsList, error: null };
  } catch (error) {
    console.error("Erreur lors de la récupération des mots de passe:", error);
    return { passwords: [], error: String(error) };
  }
}
function loadClientFromFile(fileData) {
  try {
    const client = decodeClientEx(fileData);
    console.log("Chargement du client à partir du fichier...");
    console.log(client);
    return client;
  } catch (error) {
    console.error("Erreur lors du chargement du client:", error);
    return null;
  }
}
function arrayfrom(array) {
  let array2 = new Array(array.length);
  for (let i = 0;i < array.length; i++) {
    array2[i] = array[i];
  }
  return array2;
}
function arraytoUint8Array(array) {
  let array2 = new Uint8Array(array.length);
  for (let i = 0;i < array.length; i++) {
    array2[i] = array[i];
  }
  return array2;
}

// node_modules/otpauth/dist/otpauth.esm.js
//! otpauth 9.3.6 | (c) Héctor Molinero Fernández | MIT | https://github.com/hectorm/otpauth
//! noble-hashes 1.6.1 | (c) Paul Miller | MIT | https://github.com/paulmillr/noble-hashes
var uintDecode = (num) => {
  const buf = new ArrayBuffer(8);
  const arr = new Uint8Array(buf);
  let acc = num;
  for (let i = 7;i >= 0; i--) {
    if (acc === 0)
      break;
    arr[i] = acc & 255;
    acc -= arr[i];
    acc /= 256;
  }
  return arr;
};
function anumber(n) {
  if (!Number.isSafeInteger(n) || n < 0)
    throw new Error("positive integer expected, got " + n);
}
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function abytes(b, ...lengths) {
  if (!isBytes(b))
    throw new Error("Uint8Array expected");
  if (lengths.length > 0 && !lengths.includes(b.length))
    throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b.length);
}
function ahash(h) {
  if (typeof h !== "function" || typeof h.create !== "function")
    throw new Error("Hash should be wrapped by utils.wrapConstructor");
  anumber(h.outputLen);
  anumber(h.blockLen);
}
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput(out, instance) {
  abytes(out);
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error("digestInto() expects output buffer of length at least " + min);
  }
}
/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var u32 = (arr) => new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
var createView = (arr) => new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
var rotr = (word, shift) => word << 32 - shift | word >>> shift;
var rotl = (word, shift) => word << shift | word >>> 32 - shift >>> 0;
var isLE = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([
  287454020
]).buffer)[0] === 68)();
var byteSwap = (word) => word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
function byteSwap32(arr) {
  for (let i = 0;i < arr.length; i++) {
    arr[i] = byteSwap(arr[i]);
  }
}
function utf8ToBytes(str) {
  if (typeof str !== "string")
    throw new Error("utf8ToBytes expected string, got " + typeof str);
  return new Uint8Array(new TextEncoder().encode(str));
}
function toBytes(data) {
  if (typeof data === "string")
    data = utf8ToBytes(data);
  abytes(data);
  return data;
}

class Hash {
  clone() {
    return this._cloneInto();
  }
}
function wrapConstructor(hashCons) {
  const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
  const tmp = hashCons();
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = () => hashCons();
  return hashC;
}

class HMAC extends Hash {
  update(buf) {
    aexists(this);
    this.iHash.update(buf);
    return this;
  }
  digestInto(out) {
    aexists(this);
    abytes(out, this.outputLen);
    this.finished = true;
    this.iHash.digestInto(out);
    this.oHash.update(out);
    this.oHash.digestInto(out);
    this.destroy();
  }
  digest() {
    const out = new Uint8Array(this.oHash.outputLen);
    this.digestInto(out);
    return out;
  }
  _cloneInto(to) {
    to || (to = Object.create(Object.getPrototypeOf(this), {}));
    const { oHash, iHash, finished, destroyed, blockLen, outputLen } = this;
    to = to;
    to.finished = finished;
    to.destroyed = destroyed;
    to.blockLen = blockLen;
    to.outputLen = outputLen;
    to.oHash = oHash._cloneInto(to.oHash);
    to.iHash = iHash._cloneInto(to.iHash);
    return to;
  }
  destroy() {
    this.destroyed = true;
    this.oHash.destroy();
    this.iHash.destroy();
  }
  constructor(hash, _key) {
    super();
    this.finished = false;
    this.destroyed = false;
    ahash(hash);
    const key = toBytes(_key);
    this.iHash = hash.create();
    if (typeof this.iHash.update !== "function")
      throw new Error("Expected instance of class which extends utils.Hash");
    this.blockLen = this.iHash.blockLen;
    this.outputLen = this.iHash.outputLen;
    const blockLen = this.blockLen;
    const pad = new Uint8Array(blockLen);
    pad.set(key.length > blockLen ? hash.create().update(key).digest() : key);
    for (let i = 0;i < pad.length; i++)
      pad[i] ^= 54;
    this.iHash.update(pad);
    this.oHash = hash.create();
    for (let i = 0;i < pad.length; i++)
      pad[i] ^= 54 ^ 92;
    this.oHash.update(pad);
    pad.fill(0);
  }
}
var hmac = (hash, key, message) => new HMAC(hash, key).update(message).digest();
hmac.create = (hash, key) => new HMAC(hash, key);
function setBigUint64(view, byteOffset, value, isLE2) {
  if (typeof view.setBigUint64 === "function")
    return view.setBigUint64(byteOffset, value, isLE2);
  const _32n = BigInt(32);
  const _u32_max = BigInt(4294967295);
  const wh = Number(value >> _32n & _u32_max);
  const wl = Number(value & _u32_max);
  const h = isLE2 ? 4 : 0;
  const l = isLE2 ? 0 : 4;
  view.setUint32(byteOffset + h, wh, isLE2);
  view.setUint32(byteOffset + l, wl, isLE2);
}
var Chi = (a, b, c) => a & b ^ ~a & c;
var Maj = (a, b, c) => a & b ^ a & c ^ b & c;

class HashMD extends Hash {
  update(data) {
    aexists(this);
    const { view, buffer, blockLen } = this;
    data = toBytes(data);
    const len = data.length;
    for (let pos = 0;pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView(data);
        for (;blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        continue;
      }
      buffer.set(data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
      }
    }
    this.length += data.length;
    this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists(this);
    aoutput(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE: isLE2 } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    this.buffer.subarray(pos).fill(0);
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      pos = 0;
    }
    for (let i = pos;i < blockLen; i++)
      buffer[i] = 0;
    setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE2);
    this.process(view, 0);
    const oview = createView(out);
    const len = this.outputLen;
    if (len % 4)
      throw new Error("_sha2: outputLen should be aligned to 32bit");
    const outLen = len / 4;
    const state = this.get();
    if (outLen > state.length)
      throw new Error("_sha2: outputLen bigger than state");
    for (let i = 0;i < outLen; i++)
      oview.setUint32(4 * i, state[i], isLE2);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneInto(to) {
    to || (to = new this.constructor);
    to.set(...this.get());
    const { blockLen, buffer, length, finished, destroyed, pos } = this;
    to.length = length;
    to.pos = pos;
    to.finished = finished;
    to.destroyed = destroyed;
    if (length % blockLen)
      to.buffer.set(buffer);
    return to;
  }
  constructor(blockLen, outputLen, padOffset, isLE2) {
    super();
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE2;
    this.finished = false;
    this.length = 0;
    this.pos = 0;
    this.destroyed = false;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView(this.buffer);
  }
}
var SHA1_IV = /* @__PURE__ */ new Uint32Array([
  1732584193,
  4023233417,
  2562383102,
  271733878,
  3285377520
]);
var SHA1_W = /* @__PURE__ */ new Uint32Array(80);

class SHA1 extends HashMD {
  get() {
    const { A, B, C, D, E } = this;
    return [
      A,
      B,
      C,
      D,
      E
    ];
  }
  set(A, B, C, D, E) {
    this.A = A | 0;
    this.B = B | 0;
    this.C = C | 0;
    this.D = D | 0;
    this.E = E | 0;
  }
  process(view, offset) {
    for (let i = 0;i < 16; i++, offset += 4)
      SHA1_W[i] = view.getUint32(offset, false);
    for (let i = 16;i < 80; i++)
      SHA1_W[i] = rotl(SHA1_W[i - 3] ^ SHA1_W[i - 8] ^ SHA1_W[i - 14] ^ SHA1_W[i - 16], 1);
    let { A, B, C, D, E } = this;
    for (let i = 0;i < 80; i++) {
      let F, K;
      if (i < 20) {
        F = Chi(B, C, D);
        K = 1518500249;
      } else if (i < 40) {
        F = B ^ C ^ D;
        K = 1859775393;
      } else if (i < 60) {
        F = Maj(B, C, D);
        K = 2400959708;
      } else {
        F = B ^ C ^ D;
        K = 3395469782;
      }
      const T = rotl(A, 5) + F + E + K + SHA1_W[i] | 0;
      E = D;
      D = C;
      C = rotl(B, 30);
      B = A;
      A = T;
    }
    A = A + this.A | 0;
    B = B + this.B | 0;
    C = C + this.C | 0;
    D = D + this.D | 0;
    E = E + this.E | 0;
    this.set(A, B, C, D, E);
  }
  roundClean() {
    SHA1_W.fill(0);
  }
  destroy() {
    this.set(0, 0, 0, 0, 0);
    this.buffer.fill(0);
  }
  constructor() {
    super(64, 20, 8, false);
    this.A = SHA1_IV[0] | 0;
    this.B = SHA1_IV[1] | 0;
    this.C = SHA1_IV[2] | 0;
    this.D = SHA1_IV[3] | 0;
    this.E = SHA1_IV[4] | 0;
  }
}
var sha1 = /* @__PURE__ */ wrapConstructor(() => new SHA1);
var SHA256_K = /* @__PURE__ */ new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var SHA256_IV = /* @__PURE__ */ new Uint32Array([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);

class SHA256 extends HashMD {
  get() {
    const { A, B, C, D, E, F, G, H } = this;
    return [
      A,
      B,
      C,
      D,
      E,
      F,
      G,
      H
    ];
  }
  set(A, B, C, D, E, F, G, H) {
    this.A = A | 0;
    this.B = B | 0;
    this.C = C | 0;
    this.D = D | 0;
    this.E = E | 0;
    this.F = F | 0;
    this.G = G | 0;
    this.H = H | 0;
  }
  process(view, offset) {
    for (let i = 0;i < 16; i++, offset += 4)
      SHA256_W[i] = view.getUint32(offset, false);
    for (let i = 16;i < 64; i++) {
      const W15 = SHA256_W[i - 15];
      const W2 = SHA256_W[i - 2];
      const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
      const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
      SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
    }
    let { A, B, C, D, E, F, G, H } = this;
    for (let i = 0;i < 64; i++) {
      const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
      const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
      const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
      const T2 = sigma0 + Maj(A, B, C) | 0;
      H = G;
      G = F;
      F = E;
      E = D + T1 | 0;
      D = C;
      C = B;
      B = A;
      A = T1 + T2 | 0;
    }
    A = A + this.A | 0;
    B = B + this.B | 0;
    C = C + this.C | 0;
    D = D + this.D | 0;
    E = E + this.E | 0;
    F = F + this.F | 0;
    G = G + this.G | 0;
    H = H + this.H | 0;
    this.set(A, B, C, D, E, F, G, H);
  }
  roundClean() {
    SHA256_W.fill(0);
  }
  destroy() {
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    this.buffer.fill(0);
  }
  constructor() {
    super(64, 32, 8, false);
    this.A = SHA256_IV[0] | 0;
    this.B = SHA256_IV[1] | 0;
    this.C = SHA256_IV[2] | 0;
    this.D = SHA256_IV[3] | 0;
    this.E = SHA256_IV[4] | 0;
    this.F = SHA256_IV[5] | 0;
    this.G = SHA256_IV[6] | 0;
    this.H = SHA256_IV[7] | 0;
  }
}

class SHA224 extends SHA256 {
  constructor() {
    super();
    this.A = 3238371032 | 0;
    this.B = 914150663 | 0;
    this.C = 812702999 | 0;
    this.D = 4144912697 | 0;
    this.E = 4290775857 | 0;
    this.F = 1750603025 | 0;
    this.G = 1694076839 | 0;
    this.H = 3204075428 | 0;
    this.outputLen = 28;
  }
}
var sha256 = /* @__PURE__ */ wrapConstructor(() => new SHA256);
var sha224 = /* @__PURE__ */ wrapConstructor(() => new SHA224);
var U32_MASK64 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
var _32n = /* @__PURE__ */ BigInt(32);
function fromBig(n, le = false) {
  if (le)
    return {
      h: Number(n & U32_MASK64),
      l: Number(n >> _32n & U32_MASK64)
    };
  return {
    h: Number(n >> _32n & U32_MASK64) | 0,
    l: Number(n & U32_MASK64) | 0
  };
}
function split(lst, le = false) {
  let Ah = new Uint32Array(lst.length);
  let Al = new Uint32Array(lst.length);
  for (let i = 0;i < lst.length; i++) {
    const { h, l } = fromBig(lst[i], le);
    [Ah[i], Al[i]] = [
      h,
      l
    ];
  }
  return [
    Ah,
    Al
  ];
}
var toBig = (h, l) => BigInt(h >>> 0) << _32n | BigInt(l >>> 0);
var shrSH = (h, _l, s) => h >>> s;
var shrSL = (h, l, s) => h << 32 - s | l >>> s;
var rotrSH = (h, l, s) => h >>> s | l << 32 - s;
var rotrSL = (h, l, s) => h << 32 - s | l >>> s;
var rotrBH = (h, l, s) => h << 64 - s | l >>> s - 32;
var rotrBL = (h, l, s) => h >>> s - 32 | l << 64 - s;
var rotr32H = (_h, l) => l;
var rotr32L = (h, _l) => h;
var rotlSH = (h, l, s) => h << s | l >>> 32 - s;
var rotlSL = (h, l, s) => l << s | h >>> 32 - s;
var rotlBH = (h, l, s) => l << s - 32 | h >>> 64 - s;
var rotlBL = (h, l, s) => h << s - 32 | l >>> 64 - s;
function add(Ah, Al, Bh, Bl) {
  const l = (Al >>> 0) + (Bl >>> 0);
  return {
    h: Ah + Bh + (l / 2 ** 32 | 0) | 0,
    l: l | 0
  };
}
var add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
var add3H = (low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0;
var add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0);
var add4H = (low, Ah, Bh, Ch, Dh) => Ah + Bh + Ch + Dh + (low / 2 ** 32 | 0) | 0;
var add5L = (Al, Bl, Cl, Dl, El) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0) + (El >>> 0);
var add5H = (low, Ah, Bh, Ch, Dh, Eh) => Ah + Bh + Ch + Dh + Eh + (low / 2 ** 32 | 0) | 0;
var u64 = {
  fromBig,
  split,
  toBig,
  shrSH,
  shrSL,
  rotrSH,
  rotrSL,
  rotrBH,
  rotrBL,
  rotr32H,
  rotr32L,
  rotlSH,
  rotlSL,
  rotlBH,
  rotlBL,
  add,
  add3L,
  add3H,
  add4L,
  add4H,
  add5H,
  add5L
};
var [SHA512_Kh, SHA512_Kl] = /* @__PURE__ */ (() => u64.split([
  "0x428a2f98d728ae22",
  "0x7137449123ef65cd",
  "0xb5c0fbcfec4d3b2f",
  "0xe9b5dba58189dbbc",
  "0x3956c25bf348b538",
  "0x59f111f1b605d019",
  "0x923f82a4af194f9b",
  "0xab1c5ed5da6d8118",
  "0xd807aa98a3030242",
  "0x12835b0145706fbe",
  "0x243185be4ee4b28c",
  "0x550c7dc3d5ffb4e2",
  "0x72be5d74f27b896f",
  "0x80deb1fe3b1696b1",
  "0x9bdc06a725c71235",
  "0xc19bf174cf692694",
  "0xe49b69c19ef14ad2",
  "0xefbe4786384f25e3",
  "0x0fc19dc68b8cd5b5",
  "0x240ca1cc77ac9c65",
  "0x2de92c6f592b0275",
  "0x4a7484aa6ea6e483",
  "0x5cb0a9dcbd41fbd4",
  "0x76f988da831153b5",
  "0x983e5152ee66dfab",
  "0xa831c66d2db43210",
  "0xb00327c898fb213f",
  "0xbf597fc7beef0ee4",
  "0xc6e00bf33da88fc2",
  "0xd5a79147930aa725",
  "0x06ca6351e003826f",
  "0x142929670a0e6e70",
  "0x27b70a8546d22ffc",
  "0x2e1b21385c26c926",
  "0x4d2c6dfc5ac42aed",
  "0x53380d139d95b3df",
  "0x650a73548baf63de",
  "0x766a0abb3c77b2a8",
  "0x81c2c92e47edaee6",
  "0x92722c851482353b",
  "0xa2bfe8a14cf10364",
  "0xa81a664bbc423001",
  "0xc24b8b70d0f89791",
  "0xc76c51a30654be30",
  "0xd192e819d6ef5218",
  "0xd69906245565a910",
  "0xf40e35855771202a",
  "0x106aa07032bbd1b8",
  "0x19a4c116b8d2d0c8",
  "0x1e376c085141ab53",
  "0x2748774cdf8eeb99",
  "0x34b0bcb5e19b48a8",
  "0x391c0cb3c5c95a63",
  "0x4ed8aa4ae3418acb",
  "0x5b9cca4f7763e373",
  "0x682e6ff3d6b2b8a3",
  "0x748f82ee5defb2fc",
  "0x78a5636f43172f60",
  "0x84c87814a1f0ab72",
  "0x8cc702081a6439ec",
  "0x90befffa23631e28",
  "0xa4506cebde82bde9",
  "0xbef9a3f7b2c67915",
  "0xc67178f2e372532b",
  "0xca273eceea26619c",
  "0xd186b8c721c0c207",
  "0xeada7dd6cde0eb1e",
  "0xf57d4f7fee6ed178",
  "0x06f067aa72176fba",
  "0x0a637dc5a2c898a6",
  "0x113f9804bef90dae",
  "0x1b710b35131c471b",
  "0x28db77f523047d84",
  "0x32caab7b40c72493",
  "0x3c9ebe0a15c9bebc",
  "0x431d67c49c100d4c",
  "0x4cc5d4becb3e42b6",
  "0x597f299cfc657e2a",
  "0x5fcb6fab3ad6faec",
  "0x6c44198c4a475817"
].map((n) => BigInt(n))))();
var SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
var SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);

class SHA512 extends HashMD {
  get() {
    const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
    return [
      Ah,
      Al,
      Bh,
      Bl,
      Ch,
      Cl,
      Dh,
      Dl,
      Eh,
      El,
      Fh,
      Fl,
      Gh,
      Gl,
      Hh,
      Hl
    ];
  }
  set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
    this.Ah = Ah | 0;
    this.Al = Al | 0;
    this.Bh = Bh | 0;
    this.Bl = Bl | 0;
    this.Ch = Ch | 0;
    this.Cl = Cl | 0;
    this.Dh = Dh | 0;
    this.Dl = Dl | 0;
    this.Eh = Eh | 0;
    this.El = El | 0;
    this.Fh = Fh | 0;
    this.Fl = Fl | 0;
    this.Gh = Gh | 0;
    this.Gl = Gl | 0;
    this.Hh = Hh | 0;
    this.Hl = Hl | 0;
  }
  process(view, offset) {
    for (let i = 0;i < 16; i++, offset += 4) {
      SHA512_W_H[i] = view.getUint32(offset);
      SHA512_W_L[i] = view.getUint32(offset += 4);
    }
    for (let i = 16;i < 80; i++) {
      const W15h = SHA512_W_H[i - 15] | 0;
      const W15l = SHA512_W_L[i - 15] | 0;
      const s0h = u64.rotrSH(W15h, W15l, 1) ^ u64.rotrSH(W15h, W15l, 8) ^ u64.shrSH(W15h, W15l, 7);
      const s0l = u64.rotrSL(W15h, W15l, 1) ^ u64.rotrSL(W15h, W15l, 8) ^ u64.shrSL(W15h, W15l, 7);
      const W2h = SHA512_W_H[i - 2] | 0;
      const W2l = SHA512_W_L[i - 2] | 0;
      const s1h = u64.rotrSH(W2h, W2l, 19) ^ u64.rotrBH(W2h, W2l, 61) ^ u64.shrSH(W2h, W2l, 6);
      const s1l = u64.rotrSL(W2h, W2l, 19) ^ u64.rotrBL(W2h, W2l, 61) ^ u64.shrSL(W2h, W2l, 6);
      const SUMl = u64.add4L(s0l, s1l, SHA512_W_L[i - 7], SHA512_W_L[i - 16]);
      const SUMh = u64.add4H(SUMl, s0h, s1h, SHA512_W_H[i - 7], SHA512_W_H[i - 16]);
      SHA512_W_H[i] = SUMh | 0;
      SHA512_W_L[i] = SUMl | 0;
    }
    let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
    for (let i = 0;i < 80; i++) {
      const sigma1h = u64.rotrSH(Eh, El, 14) ^ u64.rotrSH(Eh, El, 18) ^ u64.rotrBH(Eh, El, 41);
      const sigma1l = u64.rotrSL(Eh, El, 14) ^ u64.rotrSL(Eh, El, 18) ^ u64.rotrBL(Eh, El, 41);
      const CHIh = Eh & Fh ^ ~Eh & Gh;
      const CHIl = El & Fl ^ ~El & Gl;
      const T1ll = u64.add5L(Hl, sigma1l, CHIl, SHA512_Kl[i], SHA512_W_L[i]);
      const T1h = u64.add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i], SHA512_W_H[i]);
      const T1l = T1ll | 0;
      const sigma0h = u64.rotrSH(Ah, Al, 28) ^ u64.rotrBH(Ah, Al, 34) ^ u64.rotrBH(Ah, Al, 39);
      const sigma0l = u64.rotrSL(Ah, Al, 28) ^ u64.rotrBL(Ah, Al, 34) ^ u64.rotrBL(Ah, Al, 39);
      const MAJh = Ah & Bh ^ Ah & Ch ^ Bh & Ch;
      const MAJl = Al & Bl ^ Al & Cl ^ Bl & Cl;
      Hh = Gh | 0;
      Hl = Gl | 0;
      Gh = Fh | 0;
      Gl = Fl | 0;
      Fh = Eh | 0;
      Fl = El | 0;
      ({ h: Eh, l: El } = u64.add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
      Dh = Ch | 0;
      Dl = Cl | 0;
      Ch = Bh | 0;
      Cl = Bl | 0;
      Bh = Ah | 0;
      Bl = Al | 0;
      const All = u64.add3L(T1l, sigma0l, MAJl);
      Ah = u64.add3H(All, T1h, sigma0h, MAJh);
      Al = All | 0;
    }
    ({ h: Ah, l: Al } = u64.add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
    ({ h: Bh, l: Bl } = u64.add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
    ({ h: Ch, l: Cl } = u64.add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
    ({ h: Dh, l: Dl } = u64.add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
    ({ h: Eh, l: El } = u64.add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
    ({ h: Fh, l: Fl } = u64.add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
    ({ h: Gh, l: Gl } = u64.add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
    ({ h: Hh, l: Hl } = u64.add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
    this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
  }
  roundClean() {
    SHA512_W_H.fill(0);
    SHA512_W_L.fill(0);
  }
  destroy() {
    this.buffer.fill(0);
    this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
  }
  constructor() {
    super(128, 64, 16, false);
    this.Ah = 1779033703 | 0;
    this.Al = 4089235720 | 0;
    this.Bh = 3144134277 | 0;
    this.Bl = 2227873595 | 0;
    this.Ch = 1013904242 | 0;
    this.Cl = 4271175723 | 0;
    this.Dh = 2773480762 | 0;
    this.Dl = 1595750129 | 0;
    this.Eh = 1359893119 | 0;
    this.El = 2917565137 | 0;
    this.Fh = 2600822924 | 0;
    this.Fl = 725511199 | 0;
    this.Gh = 528734635 | 0;
    this.Gl = 4215389547 | 0;
    this.Hh = 1541459225 | 0;
    this.Hl = 327033209 | 0;
  }
}

class SHA384 extends SHA512 {
  constructor() {
    super();
    this.Ah = 3418070365 | 0;
    this.Al = 3238371032 | 0;
    this.Bh = 1654270250 | 0;
    this.Bl = 914150663 | 0;
    this.Ch = 2438529370 | 0;
    this.Cl = 812702999 | 0;
    this.Dh = 355462360 | 0;
    this.Dl = 4144912697 | 0;
    this.Eh = 1731405415 | 0;
    this.El = 4290775857 | 0;
    this.Fh = 2394180231 | 0;
    this.Fl = 1750603025 | 0;
    this.Gh = 3675008525 | 0;
    this.Gl = 1694076839 | 0;
    this.Hh = 1203062813 | 0;
    this.Hl = 3204075428 | 0;
    this.outputLen = 48;
  }
}
var sha512 = /* @__PURE__ */ wrapConstructor(() => new SHA512);
var sha384 = /* @__PURE__ */ wrapConstructor(() => new SHA384);
var SHA3_PI = [];
var SHA3_ROTL = [];
var _SHA3_IOTA = [];
var _0n = /* @__PURE__ */ BigInt(0);
var _1n = /* @__PURE__ */ BigInt(1);
var _2n = /* @__PURE__ */ BigInt(2);
var _7n = /* @__PURE__ */ BigInt(7);
var _256n = /* @__PURE__ */ BigInt(256);
var _0x71n = /* @__PURE__ */ BigInt(113);
for (let round = 0, R = _1n, x = 1, y = 0;round < 24; round++) {
  [x, y] = [
    y,
    (2 * x + 3 * y) % 5
  ];
  SHA3_PI.push(2 * (5 * y + x));
  SHA3_ROTL.push((round + 1) * (round + 2) / 2 % 64);
  let t = _0n;
  for (let j = 0;j < 7; j++) {
    R = (R << _1n ^ (R >> _7n) * _0x71n) % _256n;
    if (R & _2n)
      t ^= _1n << (_1n << /* @__PURE__ */ BigInt(j)) - _1n;
  }
  _SHA3_IOTA.push(t);
}
var [SHA3_IOTA_H, SHA3_IOTA_L] = /* @__PURE__ */ split(_SHA3_IOTA, true);
var rotlH = (h, l, s) => s > 32 ? rotlBH(h, l, s) : rotlSH(h, l, s);
var rotlL = (h, l, s) => s > 32 ? rotlBL(h, l, s) : rotlSL(h, l, s);
function keccakP(s, rounds = 24) {
  const B = new Uint32Array(5 * 2);
  for (let round = 24 - rounds;round < 24; round++) {
    for (let x = 0;x < 10; x++)
      B[x] = s[x] ^ s[x + 10] ^ s[x + 20] ^ s[x + 30] ^ s[x + 40];
    for (let x = 0;x < 10; x += 2) {
      const idx1 = (x + 8) % 10;
      const idx0 = (x + 2) % 10;
      const B0 = B[idx0];
      const B1 = B[idx0 + 1];
      const Th = rotlH(B0, B1, 1) ^ B[idx1];
      const Tl = rotlL(B0, B1, 1) ^ B[idx1 + 1];
      for (let y = 0;y < 50; y += 10) {
        s[x + y] ^= Th;
        s[x + y + 1] ^= Tl;
      }
    }
    let curH = s[2];
    let curL = s[3];
    for (let t = 0;t < 24; t++) {
      const shift = SHA3_ROTL[t];
      const Th = rotlH(curH, curL, shift);
      const Tl = rotlL(curH, curL, shift);
      const PI = SHA3_PI[t];
      curH = s[PI];
      curL = s[PI + 1];
      s[PI] = Th;
      s[PI + 1] = Tl;
    }
    for (let y = 0;y < 50; y += 10) {
      for (let x = 0;x < 10; x++)
        B[x] = s[y + x];
      for (let x = 0;x < 10; x++)
        s[y + x] ^= ~B[(x + 2) % 10] & B[(x + 4) % 10];
    }
    s[0] ^= SHA3_IOTA_H[round];
    s[1] ^= SHA3_IOTA_L[round];
  }
  B.fill(0);
}

class Keccak extends Hash {
  keccak() {
    if (!isLE)
      byteSwap32(this.state32);
    keccakP(this.state32, this.rounds);
    if (!isLE)
      byteSwap32(this.state32);
    this.posOut = 0;
    this.pos = 0;
  }
  update(data) {
    aexists(this);
    const { blockLen, state } = this;
    data = toBytes(data);
    const len = data.length;
    for (let pos = 0;pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      for (let i = 0;i < take; i++)
        state[this.pos++] ^= data[pos++];
      if (this.pos === blockLen)
        this.keccak();
    }
    return this;
  }
  finish() {
    if (this.finished)
      return;
    this.finished = true;
    const { state, suffix, pos, blockLen } = this;
    state[pos] ^= suffix;
    if ((suffix & 128) !== 0 && pos === blockLen - 1)
      this.keccak();
    state[blockLen - 1] ^= 128;
    this.keccak();
  }
  writeInto(out) {
    aexists(this, false);
    abytes(out);
    this.finish();
    const bufferOut = this.state;
    const { blockLen } = this;
    for (let pos = 0, len = out.length;pos < len; ) {
      if (this.posOut >= blockLen)
        this.keccak();
      const take = Math.min(blockLen - this.posOut, len - pos);
      out.set(bufferOut.subarray(this.posOut, this.posOut + take), pos);
      this.posOut += take;
      pos += take;
    }
    return out;
  }
  xofInto(out) {
    if (!this.enableXOF)
      throw new Error("XOF is not possible for this instance");
    return this.writeInto(out);
  }
  xof(bytes) {
    anumber(bytes);
    return this.xofInto(new Uint8Array(bytes));
  }
  digestInto(out) {
    aoutput(out, this);
    if (this.finished)
      throw new Error("digest() was already called");
    this.writeInto(out);
    this.destroy();
    return out;
  }
  digest() {
    return this.digestInto(new Uint8Array(this.outputLen));
  }
  destroy() {
    this.destroyed = true;
    this.state.fill(0);
  }
  _cloneInto(to) {
    const { blockLen, suffix, outputLen, rounds, enableXOF } = this;
    to || (to = new Keccak(blockLen, suffix, outputLen, enableXOF, rounds));
    to.state32.set(this.state32);
    to.pos = this.pos;
    to.posOut = this.posOut;
    to.finished = this.finished;
    to.rounds = rounds;
    to.suffix = suffix;
    to.outputLen = outputLen;
    to.enableXOF = enableXOF;
    to.destroyed = this.destroyed;
    return to;
  }
  constructor(blockLen, suffix, outputLen, enableXOF = false, rounds = 24) {
    super();
    this.blockLen = blockLen;
    this.suffix = suffix;
    this.outputLen = outputLen;
    this.enableXOF = enableXOF;
    this.rounds = rounds;
    this.pos = 0;
    this.posOut = 0;
    this.finished = false;
    this.destroyed = false;
    anumber(outputLen);
    if (0 >= this.blockLen || this.blockLen >= 200)
      throw new Error("Sha3 supports only keccak-f1600 function");
    this.state = new Uint8Array(200);
    this.state32 = u32(this.state);
  }
}
var gen = (suffix, blockLen, outputLen) => wrapConstructor(() => new Keccak(blockLen, suffix, outputLen));
var sha3_224 = /* @__PURE__ */ gen(6, 144, 224 / 8);
var sha3_256 = /* @__PURE__ */ gen(6, 136, 256 / 8);
var sha3_384 = /* @__PURE__ */ gen(6, 104, 384 / 8);
var sha3_512 = /* @__PURE__ */ gen(6, 72, 512 / 8);
var globalScope = (() => {
  if (typeof globalThis === "object")
    return globalThis;
  else {
    Object.defineProperty(Object.prototype, "__GLOBALTHIS__", {
      get() {
        return this;
      },
      configurable: true
    });
    try {
      if (typeof __GLOBALTHIS__ !== "undefined")
        return __GLOBALTHIS__;
    } finally {
      delete Object.prototype.__GLOBALTHIS__;
    }
  }
  if (typeof self !== "undefined")
    return self;
  else if (typeof window !== "undefined")
    return window;
  else if (typeof global !== "undefined")
    return global;
  return;
})();
var nobleHashes = {
  SHA1: sha1,
  SHA224: sha224,
  SHA256: sha256,
  SHA384: sha384,
  SHA512: sha512,
  "SHA3-224": sha3_224,
  "SHA3-256": sha3_256,
  "SHA3-384": sha3_384,
  "SHA3-512": sha3_512
};
var canonicalizeAlgorithm = (algorithm) => {
  switch (true) {
    case /^(?:SHA-?1|SSL3-SHA1)$/i.test(algorithm):
      return "SHA1";
    case /^SHA(?:2?-)?224$/i.test(algorithm):
      return "SHA224";
    case /^SHA(?:2?-)?256$/i.test(algorithm):
      return "SHA256";
    case /^SHA(?:2?-)?384$/i.test(algorithm):
      return "SHA384";
    case /^SHA(?:2?-)?512$/i.test(algorithm):
      return "SHA512";
    case /^SHA3-224$/i.test(algorithm):
      return "SHA3-224";
    case /^SHA3-256$/i.test(algorithm):
      return "SHA3-256";
    case /^SHA3-384$/i.test(algorithm):
      return "SHA3-384";
    case /^SHA3-512$/i.test(algorithm):
      return "SHA3-512";
    default:
      throw new TypeError(`Unknown hash algorithm: ${algorithm}`);
  }
};
var hmacDigest = (algorithm, key, message) => {
  if (hmac) {
    const hash = nobleHashes[algorithm] ?? nobleHashes[canonicalizeAlgorithm(algorithm)];
    return hmac(hash, key, message);
  } else {
    throw new Error("Missing HMAC function");
  }
};
var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
var base32Decode = (str) => {
  str = str.replace(/ /g, "");
  let end = str.length;
  while (str[end - 1] === "=")
    --end;
  str = (end < str.length ? str.substring(0, end) : str).toUpperCase();
  const buf = new ArrayBuffer(str.length * 5 / 8 | 0);
  const arr = new Uint8Array(buf);
  let bits = 0;
  let value = 0;
  let index = 0;
  for (let i = 0;i < str.length; i++) {
    const idx = ALPHABET.indexOf(str[i]);
    if (idx === -1)
      throw new TypeError(`Invalid character found: ${str[i]}`);
    value = value << 5 | idx;
    bits += 5;
    if (bits >= 8) {
      bits -= 8;
      arr[index++] = value >>> bits;
    }
  }
  return arr;
};
var base32Encode = (arr) => {
  let bits = 0;
  let value = 0;
  let str = "";
  for (let i = 0;i < arr.length; i++) {
    value = value << 8 | arr[i];
    bits += 8;
    while (bits >= 5) {
      str += ALPHABET[value >>> bits - 5 & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    str += ALPHABET[value << 5 - bits & 31];
  }
  return str;
};
var hexDecode = (str) => {
  str = str.replace(/ /g, "");
  const buf = new ArrayBuffer(str.length / 2);
  const arr = new Uint8Array(buf);
  for (let i = 0;i < str.length; i += 2) {
    arr[i / 2] = parseInt(str.substring(i, i + 2), 16);
  }
  return arr;
};
var hexEncode = (arr) => {
  let str = "";
  for (let i = 0;i < arr.length; i++) {
    const hex = arr[i].toString(16);
    if (hex.length === 1)
      str += "0";
    str += hex;
  }
  return str.toUpperCase();
};
var latin1Decode = (str) => {
  const buf = new ArrayBuffer(str.length);
  const arr = new Uint8Array(buf);
  for (let i = 0;i < str.length; i++) {
    arr[i] = str.charCodeAt(i) & 255;
  }
  return arr;
};
var latin1Encode = (arr) => {
  let str = "";
  for (let i = 0;i < arr.length; i++) {
    str += String.fromCharCode(arr[i]);
  }
  return str;
};
var ENCODER = globalScope.TextEncoder ? new globalScope.TextEncoder : null;
var DECODER = globalScope.TextDecoder ? new globalScope.TextDecoder : null;
var utf8Decode = (str) => {
  if (!ENCODER) {
    throw new Error("Encoding API not available");
  }
  return ENCODER.encode(str);
};
var utf8Encode = (arr) => {
  if (!DECODER) {
    throw new Error("Encoding API not available");
  }
  return DECODER.decode(arr);
};
var randomBytes2 = (size) => {
  if (globalScope.crypto?.getRandomValues) {
    return globalScope.crypto.getRandomValues(new Uint8Array(size));
  } else {
    throw new Error("Cryptography API not available");
  }
};

class Secret {
  static fromLatin1(str) {
    return new Secret({
      buffer: latin1Decode(str).buffer
    });
  }
  static fromUTF8(str) {
    return new Secret({
      buffer: utf8Decode(str).buffer
    });
  }
  static fromBase32(str) {
    return new Secret({
      buffer: base32Decode(str).buffer
    });
  }
  static fromHex(str) {
    return new Secret({
      buffer: hexDecode(str).buffer
    });
  }
  get buffer() {
    return this.bytes.buffer;
  }
  get latin1() {
    Object.defineProperty(this, "latin1", {
      enumerable: true,
      writable: false,
      configurable: false,
      value: latin1Encode(this.bytes)
    });
    return this.latin1;
  }
  get utf8() {
    Object.defineProperty(this, "utf8", {
      enumerable: true,
      writable: false,
      configurable: false,
      value: utf8Encode(this.bytes)
    });
    return this.utf8;
  }
  get base32() {
    Object.defineProperty(this, "base32", {
      enumerable: true,
      writable: false,
      configurable: false,
      value: base32Encode(this.bytes)
    });
    return this.base32;
  }
  get hex() {
    Object.defineProperty(this, "hex", {
      enumerable: true,
      writable: false,
      configurable: false,
      value: hexEncode(this.bytes)
    });
    return this.hex;
  }
  constructor({ buffer, size = 20 } = {}) {
    this.bytes = typeof buffer === "undefined" ? randomBytes2(size) : new Uint8Array(buffer);
    Object.defineProperty(this, "bytes", {
      enumerable: true,
      writable: false,
      configurable: false,
      value: this.bytes
    });
  }
}
var timingSafeEqual = (a, b) => {
  {
    if (a.length !== b.length) {
      throw new TypeError("Input strings must have the same length");
    }
    let i = -1;
    let out = 0;
    while (++i < a.length) {
      out |= a.charCodeAt(i) ^ b.charCodeAt(i);
    }
    return out === 0;
  }
};

class HOTP {
  static get defaults() {
    return {
      issuer: "",
      label: "OTPAuth",
      issuerInLabel: true,
      algorithm: "SHA1",
      digits: 6,
      counter: 0,
      window: 1
    };
  }
  static generate({ secret, algorithm = HOTP.defaults.algorithm, digits = HOTP.defaults.digits, counter = HOTP.defaults.counter }) {
    const digest = hmacDigest(algorithm, secret.bytes, uintDecode(counter));
    const offset = digest[digest.byteLength - 1] & 15;
    const otp = ((digest[offset] & 127) << 24 | (digest[offset + 1] & 255) << 16 | (digest[offset + 2] & 255) << 8 | digest[offset + 3] & 255) % 10 ** digits;
    return otp.toString().padStart(digits, "0");
  }
  generate({ counter = this.counter++ } = {}) {
    return HOTP.generate({
      secret: this.secret,
      algorithm: this.algorithm,
      digits: this.digits,
      counter
    });
  }
  static validate({ token, secret, algorithm, digits = HOTP.defaults.digits, counter = HOTP.defaults.counter, window: window2 = HOTP.defaults.window }) {
    if (token.length !== digits)
      return null;
    let delta = null;
    const check = (i) => {
      const generatedToken = HOTP.generate({
        secret,
        algorithm,
        digits,
        counter: i
      });
      if (timingSafeEqual(token, generatedToken)) {
        delta = i - counter;
      }
    };
    check(counter);
    for (let i = 1;i <= window2 && delta === null; ++i) {
      check(counter - i);
      if (delta !== null)
        break;
      check(counter + i);
      if (delta !== null)
        break;
    }
    return delta;
  }
  validate({ token, counter = this.counter, window: window2 }) {
    return HOTP.validate({
      token,
      secret: this.secret,
      algorithm: this.algorithm,
      digits: this.digits,
      counter,
      window: window2
    });
  }
  toString() {
    const e = encodeURIComponent;
    return "otpauth://hotp/" + `${this.issuer.length > 0 ? this.issuerInLabel ? `${e(this.issuer)}:${e(this.label)}?issuer=${e(this.issuer)}&` : `${e(this.label)}?issuer=${e(this.issuer)}&` : `${e(this.label)}?`}` + `secret=${e(this.secret.base32)}&` + `algorithm=${e(this.algorithm)}&` + `digits=${e(this.digits)}&` + `counter=${e(this.counter)}`;
  }
  constructor({ issuer = HOTP.defaults.issuer, label = HOTP.defaults.label, issuerInLabel = HOTP.defaults.issuerInLabel, secret = new Secret, algorithm = HOTP.defaults.algorithm, digits = HOTP.defaults.digits, counter = HOTP.defaults.counter } = {}) {
    this.issuer = issuer;
    this.label = label;
    this.issuerInLabel = issuerInLabel;
    this.secret = typeof secret === "string" ? Secret.fromBase32(secret) : secret;
    this.algorithm = canonicalizeAlgorithm(algorithm);
    this.digits = digits;
    this.counter = counter;
  }
}

class TOTP {
  static get defaults() {
    return {
      issuer: "",
      label: "OTPAuth",
      issuerInLabel: true,
      algorithm: "SHA1",
      digits: 6,
      period: 30,
      window: 1
    };
  }
  static generate({ secret, algorithm, digits, period = TOTP.defaults.period, timestamp = Date.now() }) {
    return HOTP.generate({
      secret,
      algorithm,
      digits,
      counter: Math.floor(timestamp / 1000 / period)
    });
  }
  generate({ timestamp = Date.now() } = {}) {
    return TOTP.generate({
      secret: this.secret,
      algorithm: this.algorithm,
      digits: this.digits,
      period: this.period,
      timestamp
    });
  }
  static validate({ token, secret, algorithm, digits, period = TOTP.defaults.period, timestamp = Date.now(), window: window2 }) {
    return HOTP.validate({
      token,
      secret,
      algorithm,
      digits,
      counter: Math.floor(timestamp / 1000 / period),
      window: window2
    });
  }
  validate({ token, timestamp, window: window2 }) {
    return TOTP.validate({
      token,
      secret: this.secret,
      algorithm: this.algorithm,
      digits: this.digits,
      period: this.period,
      timestamp,
      window: window2
    });
  }
  toString() {
    const e = encodeURIComponent;
    return "otpauth://totp/" + `${this.issuer.length > 0 ? this.issuerInLabel ? `${e(this.issuer)}:${e(this.label)}?issuer=${e(this.issuer)}&` : `${e(this.label)}?issuer=${e(this.issuer)}&` : `${e(this.label)}?`}` + `secret=${e(this.secret.base32)}&` + `algorithm=${e(this.algorithm)}&` + `digits=${e(this.digits)}&` + `period=${e(this.period)}`;
  }
  constructor({ issuer = TOTP.defaults.issuer, label = TOTP.defaults.label, issuerInLabel = TOTP.defaults.issuerInLabel, secret = new Secret, algorithm = TOTP.defaults.algorithm, digits = TOTP.defaults.digits, period = TOTP.defaults.period } = {}) {
    this.issuer = issuer;
    this.label = label;
    this.issuerInLabel = issuerInLabel;
    this.secret = typeof secret === "string" ? Secret.fromBase32(secret) : secret;
    this.algorithm = canonicalizeAlgorithm(algorithm);
    this.digits = digits;
    this.period = period;
  }
}

// src/background.ts
var CLIENT_EXPIRATION_TIME = 60 * 60 * 1000;
var currentClient = null;
var cachedPasswords = null;
function setSessionToken2(token) {
  browser.storage.local.set({ sessionToken: token }).then(() => {
    console.log("Token de session sauvegardé dans le stockage local");
  });
}
function getSessionToken2() {
  return new Promise((resolve) => {
    browser.storage.local.get(["sessionToken"]).then((result) => {
      resolve(result.sessionToken || null);
    });
  });
}
function storeClientSecurely(client) {
  const expirationTime = Date.now() + CLIENT_EXPIRATION_TIME;
  return new Promise((resolve) => {
    browser.storage.local.set({
      secureClient: {
        client,
        expirationTime
      }
    }).then(resolve);
  });
}
function storePasswordsSecurely(passwords) {
  const expirationTime = Date.now() + CLIENT_EXPIRATION_TIME;
  return new Promise((resolve) => {
    browser.storage.local.set({
      securePasswords: {
        passwords,
        expirationTime
      }
    }).then(() => {
      console.log("Mots de passe stockés de manière sécurisée avec expiration dans 1 heure");
      resolve();
    });
  });
}
async function getSecureClient() {
  return new Promise((resolve) => {
    browser.storage.local.get(["secureClient"]).then((result) => {
      if (result.secureClient && result.secureClient.expirationTime > Date.now()) {
        console.log("Client récupéré du stockage sécurisé");
        resolve(result.secureClient.client);
      } else {
        if (result.secureClient) {
          console.log("Client expiré, suppression du stockage");
          browser.storage.local.remove(["secureClient"]);
        }
        resolve(null);
      }
    });
  });
}
async function getSecurePasswords() {
  return new Promise((resolve) => {
    browser.storage.local.get(["securePasswords"]).then((result) => {
      if (result.securePasswords && result.securePasswords.expirationTime > Date.now()) {
        console.log("Mots de passe récupérés du stockage sécurisé");
        resolve(result.securePasswords.passwords);
      } else {
        if (result.securePasswords) {
          console.log("Mots de passe expirés, suppression du stockage");
          browser.storage.local.remove(["securePasswords"]);
        }
        resolve(null);
      }
    });
  });
}
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Message reçu dans le background:", message);
  switch (message.action) {
    case "fileSelected":
      handleFileSelected(message).then(sendResponse);
      return true;
    case "checkSecureClient":
      getSecureClient().then((client) => {
        if (client) {
          currentClient = client;
          return { success: true };
        } else {
          return { success: false };
        }
      }).catch((error) => {
        console.error("Erreur lors de la vérification du client sécurisé:", error);
        return { success: false, message: "Erreur lors de la vérification du client sécurisé" };
      }).then(sendResponse);
      return true;
    case "authenticate":
      if (currentClient && currentClient.id.id) {
        console.log(currentClient);
        auth(currentClient.id.id, currentClient.c).then((result) => {
          if (result.error) {
            return { success: false, message: result.error };
          } else {
            if (currentClient && result.client) {
              currentClient.c = result.client;
              browser.storage.local.set({ currentClient }).then(() => {
                console.log("Client authentifié sauvegardé dans le stockage local");
              });
              storeClientSecurely(currentClient).then(() => {
                console.log("Client authentifié stocké de manière sécurisée");
              });
            }
            return { success: true, message: "Authentification réussie" };
          }
        }).catch((error) => {
          return { success: false, message: error.toString() };
        }).then(sendResponse);
        return true;
      } else {
        sendResponse({ success: false, message: "Client ou UUID manquant" });
      }
      break;
    case "getPasswords":
      getSecurePasswords().then((passwords) => {
        let response2;
        if (passwords) {
          cachedPasswords = passwords;
          console.log("Utilisation des mots de passe en cache");
          response2 = { success: true, passwords };
          sendResponse(response2);
        } else if (currentClient && currentClient.id.id) {
          get_all(currentClient.id.id, currentClient.c).then((result) => {
            if (result.error) {
              response2 = { success: false, message: result.error, passwords: undefined };
            } else {
              const passwords2 = result.passwords;
              if (passwords2 && passwords2.length > 0) {
                cachedPasswords = passwords2;
                storePasswordsSecurely(passwords2).then(() => {
                  console.log("Mots de passe stockés de manière sécurisée");
                });
              }
              console.log("Mots de passe récupérés:", passwords2);
              response2 = {
                success: true,
                passwords: passwords2
              };
            }
            sendResponse(response2);
          }).catch((error) => {
            response2 = { success: false, message: error.toString(), passwords: undefined };
            sendResponse(response2);
          });
        } else {
          response2 = { success: false, message: "Client ou UUID manquant", passwords: undefined };
          sendResponse(response2);
        }
      });
      return true;
    case "refreshPasswords":
      let response;
      if (currentClient && currentClient.id.id) {
        get_all(currentClient.id.id, currentClient.c).then((result) => {
          if (result.error) {
            response = { success: false, message: result.error, passwords: undefined };
            sendResponse(response);
          } else {
            const passwords = result.passwords;
            if (passwords && passwords.length > 0) {
              cachedPasswords = passwords;
              return storePasswordsSecurely(passwords).then(() => {
                console.log("Mots de passe récupérés et stockés de manière sécurisée");
                response = { success: true, passwords };
                sendResponse(response);
              });
            }
            response = { success: true, passwords };
            sendResponse(response);
          }
        }).catch((error) => {
          response = { success: false, message: error.toString() };
          sendResponse(response);
        }).then(sendResponse);
      } else {
        response = { success: false, message: "Client ou UUID manquant" };
        sendResponse(response);
      }
      return true;
    case "saveSessionToken":
      if (message.token) {
        setSessionToken2(message.token);
        sendResponse({ success: true, message: "Token de session sauvegardé" });
      } else {
        sendResponse({ success: false, message: "Token de session manquant" });
      }
      break;
    case "getSessionToken":
      getSessionToken2().then((token) => {
        if (token) {
          return { success: true, token };
        } else {
          return { success: false, message: "Token de session manquant" };
        }
      }).then(sendResponse);
      return true;
    case "checkSecurePasswords":
      getSecurePasswords().then((passwords) => {
        if (passwords && passwords.length > 0) {
          cachedPasswords = passwords;
          return { success: true, passwords };
        } else {
          return { success: false, message: "Aucun mot de passe sécurisé disponible" };
        }
      }).then(sendResponse);
      return true;
    case "classifyFields":
      console.log("Demande de classification des champs");
      classifyFormFields().then((fields) => {
        return { success: true, fields };
      }).catch((error) => {
        console.error("Erreur lors de la classification des champs:", error);
        return { success: false, message: error.message };
      }).then(sendResponse);
      return true;
    case "generateTOTP":
      if (message.params) {
        try {
          const code = generateTOTPCode(message.params);
          sendResponse({ success: true, code });
        } catch (error) {
          console.error("Erreur lors de la génération du code TOTP:", error);
          sendResponse({ success: false, message: error.toString() });
        }
      } else {
        sendResponse({ success: false, message: "Paramètres TOTP manquants" });
      }
      break;
    case "saveNewCredential":
      handleSaveNewCredential(message).then(sendResponse);
      return true;
    default:
      sendResponse({ success: false, message: "Action non reconnue" });
  }
  return true;
});
function base64ToArrayBuffer(base64) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0;i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}
async function initializeClient() {
  const secureClient = await getSecureClient();
  if (secureClient) {
    currentClient = secureClient;
    console.log("Client restauré depuis le stockage sécurisé");
    const securePasswords = await getSecurePasswords();
    if (securePasswords) {
      cachedPasswords = securePasswords;
      console.log("Mots de passe restaurés depuis le stockage sécurisé");
    }
  } else {
    browser.storage.local.get(["currentClient"]).then((result) => {
      if (result.currentClient) {
        currentClient = result.currentClient;
        console.log("Client restauré depuis le stockage local");
      }
    });
  }
  browser.storage.local.get(["sessionToken"]).then((result) => {
    if (result.sessionToken) {
      console.log("Token de session restauré depuis le stockage local");
      browser.runtime.sendMessage({
        action: "restoreSessionToken",
        token: result.sessionToken
      });
    }
  });
}
initializeClient();
console.log("Service worker SkapAuto installé pour Firefox");
async function classifyFormFields() {
  return new Promise((resolve, reject) => {
    browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
      if (!tabs || tabs.length === 0) {
        reject(new Error("Aucun onglet actif trouvé"));
        return;
      }
      const activeTab = tabs[0];
      if (!activeTab.id) {
        reject(new Error("L'onglet actif n'a pas d'ID"));
        return;
      }
      browser.tabs.sendMessage(activeTab.id, { action: "classifyFields" }).then((response) => {
        if (!response || !response.success) {
          reject(new Error(response?.message || "Échec de la classification des champs"));
          return;
        }
        resolve(response.fields);
      }).catch((error) => {
        reject(new Error(`Erreur lors de l'envoi du message: ${error.message}`));
      });
    });
  });
}
function generateTOTPCode(params) {
  try {
    console.log("Génération du code TOTP avec les paramètres:", params);
    const totp = new TOTP({
      secret: params.secret,
      algorithm: params.algorithm,
      digits: params.digits,
      period: params.period,
      issuer: undefined
    });
    const code = totp.generate();
    console.log("Code TOTP généré:", code);
    return code;
  } catch (error) {
    console.error("Erreur lors de la génération du code TOTP:", error);
    throw error;
  }
}
async function handleFileSelected(message) {
  try {
    console.log("Traitement du fichier sélectionné:", message.fileName);
    const arrayBuffer = base64ToArrayBuffer(message.fileData);
    const client = loadClientFromFile(arrayBuffer);
    if (client) {
      currentClient = client;
      await storeClientSecurely(client);
      console.log("Client stocké de manière sécurisée");
      const fileMetadata = {
        name: message.fileName || "client.dat",
        type: message.fileType || "application/octet-stream",
        size: message.fileSize || arrayBuffer.byteLength,
        timestamp: Date.now()
      };
      await browser.storage.local.set({ clientFileMetadata: fileMetadata });
      browser.runtime.sendMessage({
        action: "clientLoaded",
        success: true,
        fileMetadata
      });
      return { success: true };
    } else {
      console.error("Format de fichier client invalide");
      return { success: false, message: "Format de fichier client invalide" };
    }
  } catch (error) {
    console.error("Erreur lors du chargement du client:", error);
    return {
      success: false,
      message: `Erreur lors du chargement du client: ${error instanceof Error ? error.message : "Erreur inconnue"}`
    };
  }
}
async function handleSaveNewCredential(message) {
  try {
    if (!currentClient) {
      console.error("Client non disponible pour enregistrer les identifiants");
      return { success: false, message: "Client non disponible" };
    }
    const credential = message.credential;
    if (!credential || !credential.username || !credential.password) {
      console.error("Identifiants incomplets");
      return { success: false, message: "Identifiants incomplets" };
    }
    const newPassword = {
      username: credential.username,
      password: credential.password,
      url: credential.url || null,
      description: credential.description || null,
      otp: credential.otp || null,
      app_id: null
    };
    if (!currentClient.id.id) {
      console.error("UUID du client manquant");
      return { success: false, message: "UUID du client manquant" };
    }
    const result = await create_pass(currentClient.id.id, newPassword, currentClient.c);
    if (result.error) {
      console.error("Erreur lors de la création du mot de passe:", result.error);
      return { success: false, message: result.error };
    }
    const passwordsResult = await getSecurePasswords();
    if (passwordsResult) {
      const updatedPasswords = [...passwordsResult, newPassword];
      await storePasswordsSecurely(updatedPasswords);
    }
    console.log("Identifiants enregistrés avec succès");
    return { success: true };
  } catch (error) {
    console.error("Erreur lors de l'enregistrement des identifiants:", error);
    return { success: false, message: error instanceof Error ? error.message : "Erreur inconnue" };
  }
}
export {
  setSessionToken2 as setSessionToken,
  getSessionToken2 as getSessionToken
};
