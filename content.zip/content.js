// src/content.ts
console.log("SkapAuto content script chargé");
var autofillAttempted = false;
var otpAutofillAttempted = false;
var fileInput = document.createElement("input");
fileInput.type = "file";
fileInput.style.opacity = "2";
fileInput.style.position = "absolute";
fileInput.style.left = "-1000px";
fileInput.style.top = "-1000px";
document.body.appendChild(fileInput);
fileInput.addEventListener("change", (event) => {
  const input = event.target;
  if (input.files && input.files.length > 0) {
    const file = input.files[0];
    const reader = new FileReader;
    reader.onload = (e) => {
      if (e.target && e.target.result) {
        const base64Data = e.target.result.toString().split(",")[1];
        browser.runtime.sendMessage({
          action: "fileSelected",
          fileName: file.name,
          fileData: base64Data,
          fileType: file.type || "application/octet-stream",
          fileSize: file.size
        });
      }
    };
    reader.readAsDataURL(file);
  }
  document.body.removeChild(fileInput);
});
(async () => {
  try {
    const fields = detectAutofillFields();
    if (fields.some((f) => f.type === "password") && (fields.some((f) => f.type === "name") || fields.some((f) => f.type === "email"))) {
      console.log("Champs de formulaire détectés, tentative d'autofill automatique");
      await autoFillCredentials();
      autofillAttempted = true;
    }
    if (fields.some((f) => f.type === "otp")) {
      console.log("Champs OTP détectés, tentative d'autofill automatique");
      await autoFillOTP();
      otpAutofillAttempted = true;
    }
    setupMutationObserver();
    setupFormSubmissionDetection();
    console.log("Initialisation complète du script de contenu");
  } catch (error) {
    console.error("Erreur lors de l'initialisation du script de contenu:", error);
  }
})();
function detectAutofillFields() {
  const autofillFields = [];
  const patterns = {
    name: /^(?:pseudo|name|full[_-]?name|first[_-]?name|last[_-]?name|fname|lname|given[_-]?name|family[_-]?name|current-email|j_username|user_name|user|user-name|login|vb_login_username|user name|user id|user-id|userid|id|form_loginname|wpname|mail|loginid|login id|login_name|openid_identifier|authentication_email|openid|auth_email|auth_id|authentication_identifier|authentication_id|customer_number|customernumber|onlineid|identifier|ww_x_util|loginfmt)$/i,
    email: /^(?:e[_-]?mail|email[_-]?address|mail|e.?mail|courriel|correo.*electr(o|ó)nico|メールアドレス|Электронной.?Почты|邮件|邮箱|電郵地址|ഇ-മെയില്‍|ഇലക്ട്രോണിക്.?മെയിൽ|ایمیل|پست.*الکترونیک|ईमेल|इलॅक्ट्रॉनिक.?मेल|(\\b|_)eposta(\\b|_)|(?:いめーる|電子.?郵便|[Ee]-?mail)(.?住所)?|email_address|email-address|emailaddress|user_email|user-email|login_email|login-email|authentication_email|auth_email|form_email|wpmail|mail_address|mail-address|mailaddress|address|e_mail|e_mail_address|emailid|email_id|email-id)$/i,
    password: /^(?:password|pass|pwd|current[_-]?password|new[_-]?password|j_password|user_password|user-password|login_password|login-password|passwort|contraseña|senha|mot de passe|auth_pass|authentication_password|web_password|wppassword|userpassword|user-pass|form_pw|loginpassword|session_password|sessionpassword|ap_password|password1|password-1|pass-word|passw|passwrd|upassword|user_pass)$/i,
    otp: /^(?:otp|one[_-]?time[_-]?code|verification[_-]?code|auth[_-]?code|security[_-]?code|2fa|one-time-password|one_time_password|verification-code|verification_code|verificationcode|security-code|security_code|securitycode|auth-code|auth_code|authcode|code|code-input|code_input|codeinput|pin|pin-code|pin_code|pincode|token|token-code|token_code|tokencode|mfa-code|mfa_code|mfacode|2fa-code|2fa_code|2facode|two-factor-code|two_factor_code|twofactorcode|totp|totp-code|totp_code|totpcode)$/i
  };
  const inputElements = document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"]), textarea');
  inputElements.forEach((element) => {
    const type = element.getAttribute("type")?.toLowerCase() || "";
    const id = element.id.toLowerCase();
    const name = element.name.toLowerCase();
    const autocomplete = element.getAttribute("autocomplete")?.toLowerCase() || "";
    let fieldType = null;
    if (autocomplete === "off") {
      return;
    }
    if (type === "email") {
      fieldType = "email";
    } else if (type === "password") {
      fieldType = "password";
    }
    if (!fieldType) {
      if (autocomplete.includes("name") || autocomplete === "name") {
        fieldType = "name";
      } else if (autocomplete === "email") {
        fieldType = "email";
      } else if (autocomplete === "current-password" || autocomplete === "new-password") {
        fieldType = "password";
      } else if (autocomplete === "one-time-code") {
        fieldType = "otp";
      }
    }
    if (!fieldType) {
      if (patterns.name.test(id) || patterns.name.test(name)) {
        fieldType = "name";
      } else if (patterns.email.test(id) || patterns.email.test(name)) {
        fieldType = "email";
      } else if (patterns.password.test(id) || patterns.password.test(name)) {
        fieldType = "password";
      } else if (patterns.otp.test(id) || patterns.otp.test(name)) {
        fieldType = "otp";
      }
    }
    if (!fieldType) {
      const placeholder = element.placeholder.toLowerCase();
      const labelElement = document.querySelector(`label[for="${element.id}"]`);
      const labelText = labelElement ? labelElement.textContent?.toLowerCase() || "" : "";
      if (patterns.name.test(placeholder) || patterns.name.test(labelText)) {
        fieldType = "name";
      } else if (patterns.email.test(placeholder) || patterns.email.test(labelText)) {
        fieldType = "email";
      } else if (patterns.password.test(placeholder) || patterns.password.test(labelText)) {
        fieldType = "password";
      } else if (patterns.otp.test(placeholder) || patterns.otp.test(labelText)) {
        fieldType = "otp";
      }
    }
    if (!fieldType && element instanceof HTMLInputElement && (element.maxLength === 1 || element.maxLength === 6) && element.pattern === "[0-9]*") {
      fieldType = "otp";
    }
    if (fieldType) {
      autofillFields.push({
        element,
        type: fieldType
      });
    }
  });
  return autofillFields;
}
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    let newInputsDetected = false;
    for (const mutation of mutations) {
      if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
        for (const node of Array.from(mutation.addedNodes)) {
          if (node instanceof HTMLElement) {
            const inputs = node.querySelectorAll("input");
            if (inputs.length > 0) {
              newInputsDetected = true;
              break;
            }
          }
        }
      }
      if (newInputsDetected)
        break;
    }
    if (newInputsDetected) {
      console.log("Nouveaux champs détectés, vérification...");
      setTimeout(checkForNewLoginForms, 1000);
    }
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  console.log("Observateur de mutations configuré");
}
async function checkForNewLoginForms() {
  const fields = detectAutofillFields();
  console.log("Champs de formulaire détectés:", fields);
  const passwordEmpty = fields.some((f) => f.type === "password" && (!f.element.value || f.element.value === ""));
  const hasNameField = fields.some((f) => f.type === "name");
  const hasEmailField = fields.some((f) => f.type === "email");
  const nameFieldEmpty = fields.some((f) => f.type === "name" && (!f.element.value || f.element.value === ""));
  const emailFieldEmpty = fields.some((f) => f.type === "email" && (!f.element.value || f.element.value === ""));
  const usernameEmpty = nameFieldEmpty || emailFieldEmpty;
  console.log(usernameEmpty);
  if (passwordEmpty && usernameEmpty) {
    console.log("Nouveau formulaire de connexion détecté, tentative d'autofill");
    await autoFillCredentials();
    autofillAttempted = true;
  } else if (passwordEmpty) {
    console.log("Nouveau formulaire de connexion détecté, tentative d'autofill");
    await autoFillCredentials();
    autofillAttempted = true;
  } else if (usernameEmpty) {
    console.log("Nouveau formulaire de connexion détecté, tentative d'autofill");
    await autoFillCredentials();
    autofillAttempted = true;
  }
  if (fields.some((f) => f.type === "otp") && !otpAutofillAttempted) {
    const otpEmpty = fields.some((f) => f.type === "otp" && !f.element.value);
    if (otpEmpty) {
      console.log("Nouveau champ OTP détecté, tentative d'autofill");
      await autoFillOTP();
      otpAutofillAttempted = true;
    }
  }
}
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Message reçu dans le content script:", message);
  switch (message.action) {
    case "fillPassword":
      if (message.site && message.username && message.password) {
        fillPasswordForm(message.username, message.password);
        sendResponse({ success: true, message: "Formulaire rempli" });
      } else {
        sendResponse({ success: false, message: "Informations de connexion incomplètes" });
      }
      break;
    case "fillOTP":
      if (message.otp) {
        fillOTPField(message.otp);
        sendResponse({ success: true, message: "Champ OTP rempli" });
      } else {
        sendResponse({ success: false, message: "Code OTP manquant" });
      }
      break;
    case "identifyFields":
      console.log("Identifier les champs de formulaire sur la page");
      const result = detectAutofillFields();
      sendResponse({ success: true, fields: result });
      break;
    case "injectFile":
      console.log("Injecting file selector");
      showNotification("Veuillez cliquer sur la page pour activer le sélecteur de fichier", "info");
      const handleUserClick = () => {
        fileInput.click();
        document.removeEventListener("click", handleUserClick);
      };
      document.addEventListener("click", handleUserClick, { once: true });
      sendResponse({ success: true, message: "En attente du clic utilisateur pour le sélecteur de fichier" });
      break;
    case "forceAutofill":
      autofillAttempted = false;
      autoFillCredentials().then(() => {
        sendResponse({ success: true, message: "Autofill forcé effectué" });
      }).catch((error) => {
        sendResponse({ success: false, message: error.message });
      });
      return true;
    case "forceOTPAutofill":
      otpAutofillAttempted = false;
      autoFillOTP().then(() => {
        sendResponse({ success: true, message: "Autofill OTP forcé effectué" });
      }).catch((error) => {
        sendResponse({ success: false, message: error.message });
      });
      return true;
    default:
      sendResponse({ success: false, message: "Action non reconnue" });
  }
  return true;
});
async function getMatchingCredentials() {
  return new Promise((resolve) => {
    browser.runtime.sendMessage({ action: "getPasswords" }).then((response) => {
      if (response && response.success && response.passwords) {
        const currentUrl = window.location.href;
        const currentHostname = window.location.hostname;
        const matchingPasswords = response.passwords.filter((password) => {
          if (!password.url)
            return false;
          try {
            const storedUrl = new URL(password.url);
            return storedUrl.hostname === currentHostname;
          } catch (e) {
            return currentUrl.includes(password.url) || currentHostname.includes(password.url);
          }
        });
        const credentials = matchingPasswords.map((password) => ({
          username: password.username,
          password: password.password,
          url: password.url,
          description: password.description,
          otp: password.otp
        }));
        resolve(credentials);
      } else {
        resolve([]);
      }
    });
  });
}
function showConfirmationMenu(credential) {
  const existingMenu = document.getElementById("skapauto-confirmation-menu");
  if (existingMenu) {
    existingMenu.remove();
  }
  const menu = document.createElement("div");
  menu.id = "skapauto-confirmation-menu";
  menu.style.position = "fixed";
  menu.style.top = "10px";
  menu.style.right = "10px";
  menu.style.backgroundColor = "#ced7e1";
  menu.style.borderRadius = "0.5rem";
  menu.style.padding = "16px";
  menu.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
  menu.style.zIndex = "9999";
  menu.style.maxWidth = "300px";
  menu.style.fontFamily = "'Work Sans', sans-serif";
  menu.style.transition = "transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out";
  const title = document.createElement("div");
  title.textContent = "Confirmer l'autofill";
  title.style.fontFamily = "'Raleway', sans-serif";
  title.style.fontWeight = "bold";
  title.style.marginBottom = "10px";
  title.style.borderBottom = "1px solid #1d1b21";
  title.style.paddingBottom = "5px";
  title.style.color = "#1d1b21";
  menu.appendChild(title);
  const info = document.createElement("div");
  info.style.marginBottom = "10px";
  info.style.padding = "5px";
  const usernameSpan = document.createElement("div");
  usernameSpan.textContent = `Nom d'utilisateur: ${credential.username}`;
  usernameSpan.style.fontWeight = "bold";
  usernameSpan.style.color = "#1d1b21";
  info.appendChild(usernameSpan);
  const serviceSpan = document.createElement("div");
  serviceSpan.textContent = `Service: ${credential.url}`;
  serviceSpan.style.color = "#474b4f";
  serviceSpan.style.fontSize = "0.9em";
  info.appendChild(serviceSpan);
  menu.appendChild(info);
  const buttonContainer = document.createElement("div");
  buttonContainer.style.display = "flex";
  buttonContainer.style.justifyContent = "space-between";
  buttonContainer.style.gap = "10px";
  buttonContainer.style.marginTop = "16px";
  const acceptButton = document.createElement("div");
  acceptButton.textContent = "Accepter";
  acceptButton.style.flex = "1";
  acceptButton.style.textAlign = "center";
  acceptButton.style.padding = "8px";
  acceptButton.style.backgroundColor = "#a7f3ae";
  acceptButton.style.color = "#1d1b21";
  acceptButton.style.borderRadius = "0.375rem";
  acceptButton.style.cursor = "pointer";
  acceptButton.style.transition = "all 0.2s ease-in-out";
  acceptButton.addEventListener("mouseover", () => {
    acceptButton.style.opacity = "0.9";
    acceptButton.style.transform = "translateY(-1px)";
  });
  acceptButton.addEventListener("mouseout", () => {
    acceptButton.style.opacity = "1";
    acceptButton.style.transform = "translateY(0)";
  });
  acceptButton.addEventListener("click", () => {
    fillPasswordForm(credential.username, credential.password);
    menu.remove();
  });
  const cancelButton = document.createElement("div");
  cancelButton.textContent = "Annuler";
  cancelButton.style.flex = "1";
  cancelButton.style.textAlign = "center";
  cancelButton.style.padding = "8px";
  cancelButton.style.backgroundColor = "#f2c3c2";
  cancelButton.style.color = "#1d1b21";
  cancelButton.style.borderRadius = "0.375rem";
  cancelButton.style.cursor = "pointer";
  cancelButton.style.transition = "all 0.2s ease-in-out";
  cancelButton.addEventListener("mouseover", () => {
    cancelButton.style.opacity = "0.9";
    cancelButton.style.transform = "translateY(-1px)";
  });
  cancelButton.addEventListener("mouseout", () => {
    cancelButton.style.opacity = "1";
    cancelButton.style.transform = "translateY(0)";
  });
  cancelButton.addEventListener("click", () => {
    menu.remove();
  });
  buttonContainer.appendChild(acceptButton);
  buttonContainer.appendChild(cancelButton);
  menu.appendChild(buttonContainer);
  document.body.appendChild(menu);
  menu.addEventListener("mouseover", () => {
    menu.style.transform = "translateY(-2px)";
    menu.style.boxShadow = "0 6px 8px rgba(0, 0, 0, 0.15)";
  });
  menu.addEventListener("mouseout", () => {
    menu.style.transform = "translateY(0)";
    menu.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
  });
  setTimeout(() => {
    if (document.getElementById("skapauto-confirmation-menu")) {
      document.getElementById("skapauto-confirmation-menu").remove();
    }
  }, 30000);
}
async function autoFillCredentials() {
  const credentials = await getMatchingCredentials();
  if (credentials.length === 0) {
    console.log("Aucun identifiant correspondant trouvé");
    return;
  }
  if (credentials.length === 1) {
    console.log("Un seul identifiant correspondant trouvé, affichage du menu de confirmation");
    showConfirmationMenu(credentials[0]);
    return;
  }
  console.log("Plusieurs identifiants correspondants trouvés, affichage du menu de sélection");
  showCredentialSelectionMenu(credentials);
}
function showCredentialSelectionMenu(credentials) {
  const existingMenu = document.getElementById("skapauto-credential-menu");
  if (existingMenu) {
    existingMenu.remove();
  }
  const menu = document.createElement("div");
  menu.id = "skapauto-credential-menu";
  menu.style.position = "fixed";
  menu.style.top = "10px";
  menu.style.right = "10px";
  menu.style.backgroundColor = "#ced7e1";
  menu.style.borderRadius = "0.5rem";
  menu.style.padding = "16px";
  menu.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
  menu.style.zIndex = "9999";
  menu.style.maxWidth = "300px";
  menu.style.fontFamily = "'Work Sans', sans-serif";
  menu.style.transition = "transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out";
  const title = document.createElement("div");
  title.textContent = "Choisir un identifiant";
  title.style.fontFamily = "'Raleway', sans-serif";
  title.style.fontWeight = "bold";
  title.style.marginBottom = "10px";
  title.style.borderBottom = "1px solid #1d1b21";
  title.style.paddingBottom = "5px";
  title.style.color = "#1d1b21";
  menu.appendChild(title);
  credentials.forEach((credential, index) => {
    const option = document.createElement("div");
    option.style.padding = "8px";
    option.style.cursor = "pointer";
    option.style.borderBottom = index < credentials.length - 1 ? "1px solid #1d1b21" : "none";
    option.style.transition = "all 0.2s ease-in-out";
    const infoContainer = document.createElement("div");
    const serviceContainer = document.createElement("div");
    serviceContainer.style.display = "flex";
    serviceContainer.style.alignItems = "center";
    serviceContainer.style.marginBottom = "4px";
    if (credential.favicon) {
      const favicon = document.createElement("img");
      favicon.src = getFaviconUrl(credential.url || "");
      favicon.style.width = "16px";
      favicon.style.height = "16px";
      favicon.style.marginRight = "8px";
      serviceContainer.appendChild(favicon);
    }
    const serviceName = document.createElement("span");
    serviceName.textContent = credential.url || "Identifiant";
    serviceName.style.fontWeight = "bold";
    serviceName.style.color = "#1d1b21";
    serviceContainer.appendChild(serviceName);
    infoContainer.appendChild(serviceContainer);
    const username = document.createElement("div");
    username.textContent = credential.username;
    username.style.fontSize = "0.9em";
    username.style.color = "#474b4f";
    infoContainer.appendChild(username);
    option.appendChild(infoContainer);
    option.addEventListener("mouseover", () => {
      option.style.backgroundColor = "#f0f0f0";
      option.style.transform = "translateX(5px)";
    });
    option.addEventListener("mouseout", () => {
      option.style.backgroundColor = "transparent";
      option.style.transform = "translateX(0)";
    });
    option.addEventListener("click", () => {
      fillPasswordForm(credential.username, credential.password);
      menu.remove();
    });
    menu.appendChild(option);
  });
  const closeButton = document.createElement("div");
  closeButton.textContent = "Fermer";
  closeButton.style.textAlign = "center";
  closeButton.style.marginTop = "16px";
  closeButton.style.padding = "8px";
  closeButton.style.backgroundColor = "#f2c3c2";
  closeButton.style.color = "#1d1b21";
  closeButton.style.borderRadius = "0.375rem";
  closeButton.style.cursor = "pointer";
  closeButton.style.transition = "all 0.2s ease-in-out";
  closeButton.addEventListener("mouseover", () => {
    closeButton.style.opacity = "0.9";
    closeButton.style.transform = "translateY(-1px)";
  });
  closeButton.addEventListener("mouseout", () => {
    closeButton.style.opacity = "1";
    closeButton.style.transform = "translateY(0)";
  });
  closeButton.addEventListener("click", () => {
    menu.remove();
  });
  menu.appendChild(closeButton);
  document.body.appendChild(menu);
  menu.addEventListener("mouseover", () => {
    menu.style.transform = "translateY(-2px)";
    menu.style.boxShadow = "0 6px 8px rgba(0, 0, 0, 0.15)";
  });
  menu.addEventListener("mouseout", () => {
    menu.style.transform = "translateY(0)";
    menu.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
  });
  setTimeout(() => {
    if (document.getElementById("skapauto-credential-menu")) {
      document.getElementById("skapauto-credential-menu").remove();
    }
  }, 30000);
}
function fillPasswordForm(username, password) {
  const fields = detectAutofillFields();
  console.log(fields);
  if (fields.some((f) => f.type === "name")) {
    const usernameField = fields.find((f) => f.type === "name")?.element;
    usernameField.value = username;
    usernameField.dispatchEvent(new Event("input", { bubbles: true }));
    usernameField.dispatchEvent(new Event("change", { bubbles: true }));
  } else if (fields.some((f) => f.type === "email")) {
    const emailField = fields.find((f) => f.type === "email")?.element;
    emailField.value = username;
    emailField.dispatchEvent(new Event("input", { bubbles: true }));
    emailField.dispatchEvent(new Event("change", { bubbles: true }));
  } else {
    const usernameFields = document.querySelectorAll('input[type="text"], input[type="email"], input[name*="user"], input[name*="email"], input[id*="user"], input[id*="email"]');
    if (usernameFields.length > 0) {
      const usernameField = usernameFields[0];
      usernameField.value = username;
      usernameField.dispatchEvent(new Event("input", { bubbles: true }));
      usernameField.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  if (fields.some((f) => f.type === "password")) {
    const passwordField = fields.find((f) => f.type === "password")?.element;
    passwordField.value = password;
    passwordField.dispatchEvent(new Event("input", { bubbles: true }));
    passwordField.dispatchEvent(new Event("change", { bubbles: true }));
  } else {
    const passwordFields = document.querySelectorAll('input[type="password"]');
    if (passwordFields.length > 0) {
      const passwordField = passwordFields[0];
      passwordField.value = password;
      passwordField.dispatchEvent(new Event("input", { bubbles: true }));
      passwordField.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  setTimeout(() => {
    let form = null;
    if (fields.some((f) => f.type === "password")) {
      form = fields.find((f) => f.type === "password")?.element.closest("form") || null;
    } else if (fields.some((f) => f.type === "name")) {
      form = fields.find((f) => f.type === "name")?.element.closest("form") || null;
    } else if (fields.some((f) => f.type === "email")) {
      form = fields.find((f) => f.type === "email")?.element.closest("form") || null;
    }
    if (form) {
      const submitButton = form.querySelector('button[type="submit"], input[type="submit"]');
      if (submitButton) {
        submitButton.click();
      }
    }
  }, 500);
}
function showOTPConfirmationMenu(credential) {
  const existingMenu = document.getElementById("skapauto-otp-confirmation-menu");
  if (existingMenu) {
    existingMenu.remove();
  }
  const menu = document.createElement("div");
  menu.id = "skapauto-otp-confirmation-menu";
  menu.style.position = "fixed";
  menu.style.top = "10px";
  menu.style.right = "10px";
  menu.style.backgroundColor = "#ced7e1";
  menu.style.borderRadius = "0.5rem";
  menu.style.padding = "16px";
  menu.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
  menu.style.zIndex = "9999";
  menu.style.maxWidth = "300px";
  menu.style.fontFamily = "'Work Sans', sans-serif";
  menu.style.transition = "transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out";
  const title = document.createElement("div");
  title.textContent = "Confirmer l'autofill OTP";
  title.style.fontFamily = "'Raleway', sans-serif";
  title.style.fontWeight = "bold";
  title.style.marginBottom = "10px";
  title.style.borderBottom = "1px solid #1d1b21";
  title.style.paddingBottom = "5px";
  title.style.color = "#1d1b21";
  menu.appendChild(title);
  const info = document.createElement("div");
  info.style.marginBottom = "10px";
  info.style.padding = "5px";
  const usernameSpan = document.createElement("div");
  usernameSpan.textContent = `Nom d'utilisateur: ${credential.username}`;
  usernameSpan.style.fontWeight = "bold";
  usernameSpan.style.color = "#1d1b21";
  info.appendChild(usernameSpan);
  const serviceSpan = document.createElement("div");
  serviceSpan.textContent = `Service: ${credential.url}`;
  serviceSpan.style.color = "#474b4f";
  serviceSpan.style.fontSize = "0.9em";
  info.appendChild(serviceSpan);
  menu.appendChild(info);
  const buttonContainer = document.createElement("div");
  buttonContainer.style.display = "flex";
  buttonContainer.style.justifyContent = "space-between";
  buttonContainer.style.gap = "10px";
  buttonContainer.style.marginTop = "16px";
  const acceptButton = document.createElement("div");
  acceptButton.textContent = "Accepter";
  acceptButton.style.flex = "1";
  acceptButton.style.textAlign = "center";
  acceptButton.style.padding = "8px";
  acceptButton.style.backgroundColor = "#a7f3ae";
  acceptButton.style.color = "#1d1b21";
  acceptButton.style.borderRadius = "0.375rem";
  acceptButton.style.cursor = "pointer";
  acceptButton.style.transition = "all 0.2s ease-in-out";
  acceptButton.addEventListener("mouseover", () => {
    acceptButton.style.opacity = "0.9";
    acceptButton.style.transform = "translateY(-1px)";
  });
  acceptButton.addEventListener("mouseout", () => {
    acceptButton.style.opacity = "1";
    acceptButton.style.transform = "translateY(0)";
  });
  acceptButton.addEventListener("click", async () => {
    const otpCode = await generateTOTPCode(credential.otp);
    if (otpCode) {
      fillOTPField(otpCode);
    } else {
      console.error("Impossible de générer le code OTP");
    }
    menu.remove();
  });
  const cancelButton = document.createElement("div");
  cancelButton.textContent = "Annuler";
  cancelButton.style.flex = "1";
  cancelButton.style.textAlign = "center";
  cancelButton.style.padding = "8px";
  cancelButton.style.backgroundColor = "#f2c3c2";
  cancelButton.style.color = "#1d1b21";
  cancelButton.style.borderRadius = "0.375rem";
  cancelButton.style.cursor = "pointer";
  cancelButton.style.transition = "all 0.2s ease-in-out";
  cancelButton.addEventListener("mouseover", () => {
    cancelButton.style.opacity = "0.9";
    cancelButton.style.transform = "translateY(-1px)";
  });
  cancelButton.addEventListener("mouseout", () => {
    cancelButton.style.opacity = "1";
    cancelButton.style.transform = "translateY(0)";
  });
  cancelButton.addEventListener("click", () => {
    menu.remove();
  });
  buttonContainer.appendChild(acceptButton);
  buttonContainer.appendChild(cancelButton);
  menu.appendChild(buttonContainer);
  document.body.appendChild(menu);
  menu.addEventListener("mouseover", () => {
    menu.style.transform = "translateY(-2px)";
    menu.style.boxShadow = "0 6px 8px rgba(0, 0, 0, 0.15)";
  });
  menu.addEventListener("mouseout", () => {
    menu.style.transform = "translateY(0)";
    menu.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
  });
  setTimeout(() => {
    if (document.getElementById("skapauto-otp-confirmation-menu")) {
      document.getElementById("skapauto-otp-confirmation-menu").remove();
    }
  }, 30000);
}
async function autoFillOTP() {
  const credentials = await getMatchingCredentials();
  if (credentials.length === 0) {
    console.log("Aucun identifiant correspondant trouvé pour OTP");
    return;
  }
  const credentialsWithOTP = credentials.filter((cred) => cred.otp);
  if (credentialsWithOTP.length === 0) {
    console.log("Aucun identifiant avec OTP trouvé");
    return;
  }
  if (credentialsWithOTP.length === 1) {
    console.log("Un seul identifiant avec OTP trouvé, affichage du menu de confirmation");
    showOTPConfirmationMenu(credentialsWithOTP[0]);
    return;
  }
  console.log("Plusieurs identifiants avec OTP trouvés, affichage du menu de sélection");
  showOTPSelectionMenu(credentialsWithOTP);
}
function showOTPSelectionMenu(credentials) {
  const existingMenu = document.getElementById("skapauto-otp-menu");
  if (existingMenu) {
    existingMenu.remove();
  }
  const menu = document.createElement("div");
  menu.id = "skapauto-otp-menu";
  menu.style.position = "fixed";
  menu.style.top = "10px";
  menu.style.right = "10px";
  menu.style.backgroundColor = "#ced7e1";
  menu.style.borderRadius = "0.5rem";
  menu.style.padding = "16px";
  menu.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
  menu.style.zIndex = "9999";
  menu.style.maxWidth = "300px";
  menu.style.fontFamily = "'Work Sans', sans-serif";
  menu.style.transition = "transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out";
  const title = document.createElement("div");
  title.textContent = "Choisir un compte pour OTP";
  title.style.fontFamily = "'Raleway', sans-serif";
  title.style.fontWeight = "bold";
  title.style.marginBottom = "10px";
  title.style.borderBottom = "1px solid #1d1b21";
  title.style.paddingBottom = "5px";
  title.style.color = "#1d1b21";
  menu.appendChild(title);
  credentials.forEach((credential, index) => {
    const option = document.createElement("div");
    option.style.padding = "8px";
    option.style.cursor = "pointer";
    option.style.borderBottom = index < credentials.length - 1 ? "1px solid #1d1b21" : "none";
    option.style.transition = "all 0.2s ease-in-out";
    const infoContainer = document.createElement("div");
    const serviceContainer = document.createElement("div");
    serviceContainer.style.display = "flex";
    serviceContainer.style.alignItems = "center";
    serviceContainer.style.marginBottom = "4px";
    if (credential.favicon) {
      const favicon = document.createElement("img");
      favicon.src = getFaviconUrl(credential.url || "");
      favicon.style.width = "16px";
      favicon.style.height = "16px";
      favicon.style.marginRight = "8px";
      serviceContainer.appendChild(favicon);
    }
    const serviceName = document.createElement("span");
    serviceName.textContent = credential.url || "Identifiant";
    serviceName.style.fontWeight = "bold";
    serviceName.style.color = "#1d1b21";
    serviceContainer.appendChild(serviceName);
    infoContainer.appendChild(serviceContainer);
    const username = document.createElement("div");
    username.textContent = credential.username;
    username.style.fontSize = "0.9em";
    username.style.color = "#474b4f";
    infoContainer.appendChild(username);
    option.appendChild(infoContainer);
    option.addEventListener("mouseover", () => {
      option.style.backgroundColor = "#f0f0f0";
      option.style.transform = "translateX(5px)";
    });
    option.addEventListener("mouseout", () => {
      option.style.backgroundColor = "transparent";
      option.style.transform = "translateX(0)";
    });
    option.addEventListener("click", () => {
      showOTPConfirmationMenu(credential);
      menu.remove();
    });
    menu.appendChild(option);
  });
  const closeButton = document.createElement("div");
  closeButton.textContent = "Fermer";
  closeButton.style.textAlign = "center";
  closeButton.style.marginTop = "16px";
  closeButton.style.padding = "8px";
  closeButton.style.backgroundColor = "#f2c3c2";
  closeButton.style.color = "#1d1b21";
  closeButton.style.borderRadius = "0.375rem";
  closeButton.style.cursor = "pointer";
  closeButton.style.transition = "all 0.2s ease-in-out";
  closeButton.addEventListener("mouseover", () => {
    closeButton.style.opacity = "0.9";
    closeButton.style.transform = "translateY(-1px)";
  });
  closeButton.addEventListener("mouseout", () => {
    closeButton.style.opacity = "1";
    closeButton.style.transform = "translateY(0)";
  });
  closeButton.addEventListener("click", () => {
    menu.remove();
  });
  menu.appendChild(closeButton);
  document.body.appendChild(menu);
  menu.addEventListener("mouseover", () => {
    menu.style.transform = "translateY(-2px)";
    menu.style.boxShadow = "0 6px 8px rgba(0, 0, 0, 0.15)";
  });
  menu.addEventListener("mouseout", () => {
    menu.style.transform = "translateY(0)";
    menu.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
  });
  setTimeout(() => {
    if (document.getElementById("skapauto-otp-menu")) {
      document.getElementById("skapauto-otp-menu").remove();
    }
  }, 30000);
}
function fillOTPField(otp) {
  const fields = detectAutofillFields();
  console.log("Champs OTP identifiés:", fields.filter((f) => f.type === "otp"));
  if (fields.some((f) => f.type === "otp")) {
    const otpField = fields.find((f) => f.type === "otp")?.element;
    otpField.value = otp;
    otpField.dispatchEvent(new Event("input", { bubbles: true }));
    otpField.dispatchEvent(new Event("change", { bubbles: true }));
    console.log("Champ OTP rempli avec:", otp);
    setTimeout(() => {
      const form = otpField.closest("form");
      if (form) {
        const submitButton = form.querySelector('button[type="submit"], input[type="submit"]');
        if (submitButton) {
          submitButton.click();
        }
      }
    }, 500);
  } else {
    console.log("Aucun champ OTP trouvé");
  }
}
async function generateTOTPCode(otpUri) {
  try {
    console.log("Génération du code TOTP à partir de l'URI:", otpUri);
    if (!otpUri.startsWith("otpauth://")) {
      console.error("URI OTP invalide:", otpUri);
      return null;
    }
    const params = parseTOTPUri(otpUri);
    if (!params) {
      console.error("Impossible de parser l'URI OTP");
      return null;
    }
    const code = await calculateTOTP(params);
    console.log("Code TOTP généré:", code);
    return code;
  } catch (error) {
    console.error("Erreur lors de la génération du code TOTP:", error);
    return null;
  }
}
function getFaviconUrl(domain) {
  let cleanDomain = domain;
  if (cleanDomain.includes("://")) {
    cleanDomain = cleanDomain.split("://")[1];
  }
  if (cleanDomain.includes("/")) {
    cleanDomain = cleanDomain.split("/")[0];
  }
  return `https://www.google.com/s2/favicons?domain=${cleanDomain}&sz=32`;
}
function parseTOTPUri(uri) {
  try {
    const url = new URL(uri);
    if (url.protocol !== "otpauth:" || url.host !== "totp") {
      console.error("URI non TOTP:", uri);
      return null;
    }
    const params = new URLSearchParams(url.search);
    const secret = params.get("secret");
    if (!secret) {
      console.error("Secret manquant dans l'URI OTP");
      return null;
    }
    const algorithm = params.get("algorithm") || "SHA1";
    const digits = parseInt(params.get("digits") || "6");
    const period = parseInt(params.get("period") || "30");
    return {
      secret,
      algorithm,
      digits,
      period
    };
  } catch (error) {
    console.error("Erreur lors du parsing de l'URI OTP:", error);
    return null;
  }
}
async function calculateTOTP(params) {
  return new Promise((resolve, reject) => {
    browser.runtime.sendMessage({
      action: "generateTOTP",
      params
    }).then((response) => {
      if (response && response.success && response.code) {
        resolve(response.code);
      } else {
        reject(new Error(response?.message || "Erreur lors de la génération du code TOTP"));
      }
    });
  });
}
function setupFormSubmissionDetection() {
  document.addEventListener("submit", async (event) => {
    const fields = detectAutofillFields();
    if (fields.some((f) => f.type === "password") && (fields.some((f) => f.type === "name") || fields.some((f) => f.type === "email"))) {
      const passwordValue = fields.find((f) => f.type === "password")?.element.value;
      const usernameValue = fields.some((f) => f.type === "name") ? fields.find((f) => f.type === "name")?.element.value : fields.some((f) => f.type === "email") ? fields.find((f) => f.type === "email")?.element.value : "";
      if (passwordValue && usernameValue) {
        const existingCredentials = await getMatchingCredentials();
        const credentialExists = existingCredentials.some((cred) => cred.username === usernameValue && cred.password === passwordValue);
        if (!credentialExists) {
          setTimeout(() => {
            showSaveCredentialsModal(usernameValue, passwordValue);
          }, 500);
        }
      }
    }
  });
  document.addEventListener("click", async (event) => {
    const target = event.target;
    console.log(target.tagName);
    if (target.tagName === "BUTTON" || target.tagName === "INPUT" && (target.getAttribute("type") === "submit" || target.getAttribute("type") === "button") || target.tagName === "BUTTON" && target.getAttribute("type") === "submit") {
      const fields = detectAutofillFields();
      if (fields.some((f) => f.type === "password") && (fields.some((f) => f.type === "name") || fields.some((f) => f.type === "email"))) {
        const passwordValue = fields.find((f) => f.type === "password")?.element.value;
        const usernameValue = fields.some((f) => f.type === "name") ? fields.find((f) => f.type === "name")?.element.value : fields.some((f) => f.type === "email") ? fields.find((f) => f.type === "email")?.element.value : "";
        if (passwordValue && usernameValue) {
          const existingCredentials = await getMatchingCredentials();
          const credentialExists = existingCredentials.some((cred) => cred.username === usernameValue && cred.password === passwordValue);
          if (!credentialExists) {
            setTimeout(() => {
              showSaveCredentialsModal(usernameValue, passwordValue);
            }, 500);
          }
        }
      }
    }
  });
}
function showSaveCredentialsModal(username, password) {
  const existingModal = document.getElementById("skapauto-save-credentials-modal");
  if (existingModal) {
    existingModal.remove();
  }
  const modal = document.createElement("div");
  modal.id = "skapauto-save-credentials-modal";
  modal.style.position = "fixed";
  modal.style.top = "10px";
  modal.style.right = "10px";
  modal.style.backgroundColor = "#ced7e1";
  modal.style.borderRadius = "0.5rem";
  modal.style.padding = "16px";
  modal.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
  modal.style.zIndex = "9999";
  modal.style.maxWidth = "300px";
  modal.style.fontFamily = "'Work Sans', sans-serif";
  modal.style.transition = "transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out, opacity 0.3s ease-in-out";
  const title = document.createElement("div");
  title.textContent = "Enregistrer les identifiants";
  title.style.fontFamily = "'Raleway', sans-serif";
  title.style.fontWeight = "bold";
  title.style.marginBottom = "10px";
  title.style.borderBottom = "1px solid #1d1b21";
  title.style.paddingBottom = "5px";
  title.style.color = "#1d1b21";
  modal.appendChild(title);
  const info = document.createElement("div");
  info.style.marginBottom = "10px";
  info.style.padding = "5px";
  const usernameSpan = document.createElement("div");
  usernameSpan.textContent = `Utilisateur: ${username}`;
  usernameSpan.style.fontWeight = "bold";
  usernameSpan.style.color = "#1d1b21";
  info.appendChild(usernameSpan);
  const passwordSpan = document.createElement("div");
  passwordSpan.textContent = `Mot de passe: ${"•".repeat(password.length)}`;
  passwordSpan.style.color = "#474b4f";
  passwordSpan.style.fontSize = "0.9em";
  info.appendChild(passwordSpan);
  const serviceSpan = document.createElement("div");
  serviceSpan.textContent = `Service: ${window.location.hostname}`;
  serviceSpan.style.color = "#474b4f";
  serviceSpan.style.fontSize = "0.9em";
  info.appendChild(serviceSpan);
  modal.appendChild(info);
  const buttonContainer = document.createElement("div");
  buttonContainer.style.display = "flex";
  buttonContainer.style.justifyContent = "space-between";
  const saveButton = document.createElement("div");
  saveButton.textContent = "Enregistrer";
  saveButton.style.flex = "1";
  saveButton.style.textAlign = "center";
  saveButton.style.padding = "8px";
  saveButton.style.backgroundColor = "#a7f3ae";
  saveButton.style.color = "#1d1b21";
  saveButton.style.borderRadius = "0.375rem";
  saveButton.style.cursor = "pointer";
  saveButton.style.transition = "all 0.2s ease-in-out";
  saveButton.addEventListener("mouseover", () => {
    saveButton.style.opacity = "0.9";
    saveButton.style.transform = "translateY(-1px)";
  });
  saveButton.addEventListener("mouseout", () => {
    saveButton.style.opacity = "1";
    saveButton.style.transform = "translateY(0)";
  });
  saveButton.addEventListener("click", () => {
    const newCredential = {
      username,
      password,
      url: window.location.hostname,
      description: document.title || window.location.hostname,
      favicon: getFaviconUrl(window.location.hostname)
    };
    browser.runtime.sendMessage({
      action: "saveNewCredential",
      credential: newCredential
    }).then((response) => {
      if (response && response.success) {
        modal.style.opacity = "0";
        setTimeout(() => {
          modal.remove();
          showNotification("Identifiants enregistrés avec succès!", "success");
        }, 300);
      } else {
        showNotification("Erreur lors de l'enregistrement des identifiants.", "error");
      }
    });
  });
  const cancelButton = document.createElement("div");
  cancelButton.textContent = "Annuler";
  cancelButton.style.flex = "1";
  cancelButton.style.textAlign = "center";
  cancelButton.style.padding = "8px";
  cancelButton.style.backgroundColor = "#f2c3c2";
  cancelButton.style.color = "#1d1b21";
  cancelButton.style.borderRadius = "0.375rem";
  cancelButton.style.cursor = "pointer";
  cancelButton.style.transition = "all 0.2s ease-in-out";
  cancelButton.addEventListener("mouseover", () => {
    cancelButton.style.opacity = "0.9";
    cancelButton.style.transform = "translateY(-1px)";
  });
  cancelButton.addEventListener("mouseout", () => {
    cancelButton.style.opacity = "1";
    cancelButton.style.transform = "translateY(0)";
  });
  cancelButton.addEventListener("click", () => {
    modal.style.opacity = "0";
    setTimeout(() => {
      modal.remove();
    }, 300);
  });
  buttonContainer.appendChild(saveButton);
  buttonContainer.appendChild(cancelButton);
  modal.appendChild(buttonContainer);
  document.body.appendChild(modal);
  modal.addEventListener("mouseover", () => {
    modal.style.transform = "translateY(-2px)";
    modal.style.boxShadow = "0 6px 8px rgba(0, 0, 0, 0.15)";
  });
  modal.addEventListener("mouseout", () => {
    modal.style.transform = "translateY(0)";
    modal.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
  });
  setTimeout(() => {
    if (document.getElementById("skapauto-save-credentials-modal")) {
      const modalElement = document.getElementById("skapauto-save-credentials-modal");
      modalElement.style.opacity = "0";
      setTimeout(() => {
        modalElement.remove();
      }, 300);
    }
  }, 30000);
}
function showNotification(message, type) {
  const notification = document.createElement("div");
  notification.style.position = "fixed";
  notification.style.bottom = "20px";
  notification.style.right = "20px";
  notification.style.zIndex = "10000";
  notification.style.padding = "12px 16px";
  notification.style.borderRadius = "4px";
  notification.style.fontFamily = "Arial, sans-serif";
  notification.style.fontSize = "14px";
  notification.style.boxShadow = "0 2px 10px rgba(0, 0, 0, 0.1)";
  notification.style.transition = "all 0.3s ease-in-out";
  notification.style.opacity = "0";
  notification.style.transform = "translateY(20px)";
  if (type === "success") {
    notification.style.backgroundColor = "#4caf50";
    notification.style.color = "white";
  } else if (type === "error") {
    notification.style.backgroundColor = "#f44336";
    notification.style.color = "white";
  } else {
    notification.style.backgroundColor = "#2196f3";
    notification.style.color = "white";
  }
  notification.textContent = message;
  document.body.appendChild(notification);
  setTimeout(() => {
    notification.style.opacity = "1";
    notification.style.transform = "translateY(0)";
    setTimeout(() => {
      notification.style.opacity = "0";
      notification.style.transform = "translateY(20px)";
      setTimeout(() => {
        if (document.body.contains(notification)) {
          notification.remove();
        }
      }, 300);
    }, 3000);
  }, 10);
}
